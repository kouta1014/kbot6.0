import subprocess
inp = input()
res = subprocess.check_output(inp)
print(res)