# -*- coding:utf-8 -*-
from linepy import*
line = LINE()
import json, time, random, tempfile, os, sys, urllib, threading, codecs, datetime
from datetime import datetime


# reload(sys)

# sys.setdefaultencoding('utf-8')



try:

    f = open('client.json', 'r')

    token = f.read()

    client = LineClient(authToken=token)

    f.close()

except:

    client = LineClient()

    f = open('client.json', 'w')

    f.write(client.authToken)

    f.close()



poll = LinePoll(client)

# channel = LineChannel(client)

profile = client.getProfile()



helps = """#help
《help》ヘルプを表示します。

#contact
《mid》midを表示します。

《mid:@メンション》メンションしたユーザーのmidを表示します。

《gid》gidを表示します。

《me》自分の連絡先を送信します。

#savegroup
《pi:on》招待を禁止します。

《pi:off》招待禁止をオフにします。

《np:on》グループ名の変更禁止をします。

《np.off》Nprotectをオフにします。

《gp:on》グループ画像の変更禁止をします。

《gp:off》Gprotectをオフにします。

#url
《url on》招待URLをオンにします。

《url off》招待URLをオフにします。

《url》招待URLを生成します。

《url:》gidから招待URLを作成します。
《murl》自分の追加URLを出します。
《inv:対象のmid》mid先を招待します。

#settings
《連絡先 on》連絡先情報をオンにします。

《連絡先 off》連絡先情報をオフにします。

《追加 on》友達自動追加をオンにします。

《追加 off》友達自動追加をオフにします。

《追加メッセージ on》追加メッセージをオンにします。

《追加メッセージ off》追加メッセージをオフにします。

《追加メッセージ:》追加メッセージを変更します。

《参加 on》グループ自動参加をオンにします。

《参加 off》グループ自動参加をオフにします。

《参加メッセージ on》参加メッセージをオンにします。

《参加メッセージ off》参加メッセージをオフにします。

《参加メッセージ:》参加のメッセージを変更します。

《強制 on》強制自動退出をオンにします。

《強制 off》強制自動退出をオフにします。

《共有 on》ノートアルバムの情報をオンにします。

《共有 off》ノートアルバムの情報をオフにします。

#check
《check》設定内容を確認します。

#list
《adb》連絡先でブラックリストに追加します。

《delb》連絡先でブラックリストから削除します。

《adbm:@メンション》メンションでブラックリストに追加します。

《delbm:@メンション》メンションでブラックリストから削除します。

《abc》ブラックリストユーザーを確認します。

《bc》グループ内にいるブラックリストユーザーを確認します。

《bk》グループ内にいるブラックリストユーザーを退会させます。

#kick
《NK:》グループから指定した名前のユーザーを退会させます。

《MK:》メンションしたユーザーを退会させます。

#system
《speed》処理速度を計測します。



《end》システムを終了します。

author:Taisei
movedby Taisei
ㅌCp's Group
2018.169"""



stop = {

    'PI': {},  # 画像保護

    'PN': {},  # 名前保護

    'PK': {},  # 蹴り保護

    'PU': {},  # URL保護

    'PP': {},  # 招待保護

    'aam': "",

    'ajm': "",

    'contact': False,

    'aaf': False,

    'aafm': False,

    'aj': False,

    'ajfm': False,

    'arl': False,

    'noto': False,

    'db': False,

    'wb': False,

    'blc': True,

    'bls': {}

}



f = codecs.open('PP.json', 'r', 'utf-8')

stop["PP"] = json.load(f)

f = codecs.open('PN.json', 'r', 'utf-8')

stop["PN"] = json.load(f)

f = codecs.open('PI.json', 'r', 'utf-8')

stop["PI"] = json.load(f)

f = codecs.open('black.json', 'r', 'utf-8')

stop["bls"] = json.load(f)



gname = {}

gname = stop["PN"]



while True:

    try:

        ops = poll.singleTrace(count=50)

        if ops != None:

            for op in ops:



                if op.type == 5:

                    try:

                        if stop["aaf"] == True:

                            client.findAndAddContactsByMid(op.param1)

                        if stop["aafm"] == True:

                            client.sendMessage(op.param1, stop["aam"])

                        if stop["aj"] == True:

                            client.findAndAddContactsByMid(op.param1)

                        if stop["ajfm"] == True:

                            client.sendMessage(op.param1, stop["ajm"])

                    except:

                        pass



                if op.type == 11:

                    if op.param3 == "1":

                        if op.param1 in stop['PN']:

                            G = client.getGroup(op.param1)

                            G.name = gname[op.param1]

                            client.updateGroup(G)

                            client.sendMessage(op.param1, 'Nprotect中のグループ名変更は禁止されています。')



                    if op.param3 == "2":

                        if op.param1 in stop['PI']:

                            client.updateGroupPicture(op.param1, op.param1 + '.png')

                            client.sendMessage(op.param1, 'Gprotect中のグループ画像変更は禁止されています。')



                if op.type == 13:

                    if profile.mid in op.param3:

                        if stop["aj"] == True:

                            client.acceptGroupInvitation(op.param1)

                            client.sendMessage(op.param1, stop["ajm"])

                        else:

                            pass

                # if op.param1 in stop["PP"]:

                #       Inviter = op.param3.replace(" ",',')

                #       InviterX = Inviter.split(",")

                #       client.cancelGroupInvitation(op.param1, InviterX)

                #       client.sendMessage(op.param1,"protect中の招待は禁止されています。")

                # else:

                #       Inviter = op.param3.replace(" ",',')

                #       InviterX = Inviter.split(",")

                #       matched_list = []

                #       for tag in stop["bls"]:

                #               matched_list+=filter(lambda str: str == tag, InviterX)

                #       if matched_list == []:

                #               pass

                #       else:

                #               client.cancelGroupInvitation(op.param1, matched_list)

                #               client.sendMessage(op.param1,"ブラックリストユーザーが招待された為ブラックリストユーザーの招待をキャンセルしました。")



                if op.type == 19:

                    if stop['blc'] == True:

                        if op.param2 in profile.mid:

                            pass

                        else:

                            stop["bls"][op.param2] = True

                            f = codecs.open('black.json', 'w', 'utf-8')

                            json.dump(stop["bls"], f, sort_keys=True, indent=4, ensure_ascii=False)



                if op.type == 22:

                    if stop["arl"] == True:

                        client.leaveRoom(op.param1)



                if op.type == 25:

                    msg = op.message

                    try:

                        if msg.contentType == 0:

                            ##############################################

                            if msg.text in ["help", "ヘルプ", "へるぷ"]:

                                client.sendMessage(msg.to, helps)

                            ##############################################

                            if msg.text == "mid":

                                client.sendMessage(msg.to, msg._from)

                            ##############################################

                            if "mid:" in msg.text:

                                if msg.contentMetadata is not None:

                                    targets = []

                                    key = eval(msg.contentMetadata["MENTION"])

                                    key["MENTIONEES"][0]["M"]

                                    for x in key["MENTIONEES"]:

                                        targets.append(x["M"])

                                        for mid in targets:

                                            txt = mid

                                            client.sendMessage(msg.to, txt)

                            ##############################################

                            if msg.text == "gid":

                                client.sendMessage(msg.to, msg.to)

                            ##############################################

                            if msg.text == "me":

                                # contact = client.getContact(mid)

                                client.sendContact(msg.to, msg._from)

                            ##############################################

                            if "murl" == msg.text:

                                ids = client.reissueUserTicket(0, 3)

                                client.sendMessage(msg.to, "http://line.me/ti/p/%s" % ids)

                            ##############################################

                            if "inv:" in msg.text:

                                key = msg.text[-33:]

                                client.findAndAddContactsByMid(key)

                                client.inviteIntoGroup(msg.to, [key])

                                contact = client.getContact(key)

                                client.sendMessage(msg.to, "" + contact.displayName + "さんを招待しました。")

                            ##############################################

                            if "mtoc:" in msg.text:

                                key = msg.text[-33:]

                                client.sendMessage(msg.to, text=None, contentMetadata={'mid': key}, contentType=13)

                                contact = client.getContact(key)

                                client.sendMessage(msg.to, contact.displayName + "さんの連絡先です。")

                            ##############################################

                            if msg.text == "ip:on":

                                if msg.to in stop['PP']:

                                    client.sendMessage(msg.to, "既にオンです。")

                                else:

                                    client.sendMessage(msg.to, "protect on！")

                                    stop['PP'][msg.to] = msg._from

                                    f = codecs.open('PP.json', 'w', 'utf-8')

                                    json.dump(stop["PP"], f, sort_keys=True, indent=4, ensure_ascii=False)

                            ##############################################

                            if msg.text == "ip:off":

                                if msg.to in stop['PP']:

                                    client.sendMessage(msg.to, "protect off！")

                                    del stop['PP'][msg.to]

                                    f = codecs.open('PP.json', 'w', 'utf-8')

                                    json.dump(stop["PP"], f, sort_keys=True, indent=4, ensure_ascii=False)

                                else:

                                    client.sendMessage(msg.to, "既にオフです。")

                            ##############################################

                            if msg.text == "np:on":

                                if msg.to in stop['PN']:

                                    client.sendMessage(msg.to, '既にオンです。')

                                else:

                                    stop['PN'][msg.to] = client.getGroup(msg.to).name

                                    f = codecs.open('PN.json', 'w', 'utf-8')

                                    json.dump(stop["PN"], f, sort_keys=True, indent=4, ensure_ascii=False)

                                    client.sendMessage(msg.to, 'Nprotect on！')

                            ##############################################

                            if msg.text == "np:off":

                                if msg.to in stop['PN']:

                                    client.sendMessage(msg.to, 'Nprotect off！')

                                    del stop['PN'][msg.to]

                                    f = codecs.open('PN.json', 'w', 'utf-8')

                                    json.dump(stop["PN"], f, sort_keys=True, indent=4, ensure_ascii=False)

                                else:

                                    client.sendMessage(msg.to, '既にオフです。')

                            ##############################################

                            if msg.text == "gp:on":

                                if msg.to in stop['PI']:

                                    client.sendMessage(msg.to, '既にオンです。')

                                else:

                                    client.sendMessage(msg.to, 'Gprotect on！')

                                    group = client.getGroup(msg.to)

                                    url = "http://dl.profile.line-cdn.net/" + group.pictureStatus

                                    urllib.urlretrieve(url, msg.to + ".png")

                                    stop['PI'][msg.to] = True

                                    f = codecs.open('PI.json', 'w', 'utf-8')

                                    json.dump(stop["PI"], f, sort_keys=True, indent=4, ensure_ascii=False)

                            ##############################################

                            if msg.text == "gp:off":

                                if msg.to in stop['PI']:

                                    client.sendMessage(msg.to, 'Gprotect off！')

                                    os.remove(msg.to + '.png')

                                    del stop['PI'][msg.to]

                                    f = codecs.open('PI.json', 'w', 'utf-8')

                                    json.dump(stop["PI"], f, sort_keys=True, indent=4, ensure_ascii=False)

                                else:

                                    client.sendMessage(msg.to, '既にオフです。')

                            ##############################################

                            if "連絡先 on" == msg.text:

                                if stop["contact"] == True:

                                    client.sendMessage(msg.to, "既にオンです")

                                else:

                                    stop["contact"] = True

                                    client.sendMessage(msg.to, "連絡先をオンにしました")

                            ##############################################

                            if "連絡先 off" == msg.text:

                                if stop["contact"] == False:

                                    client.sendMessage(msg.to, "既にオフです")

                                else:

                                    stop["contact"] = False

                                    client.sendMessage(msg.to, "連絡先をオフにしました")

                            ##############################################

                            if "追加 on" == msg.text:

                                if stop["aaf"] == True:

                                    client.sendMessage(msg.to, "既にオンです")

                                else:

                                    stop["aaf"] = True

                                    client.sendMessage(msg.to, "自動追加をオンにしました")

                            ##############################################

                            if "追加 off" == msg.text:

                                if stop["aaf"] == False:

                                    client.sendMessage(msg.to, "既にオフです")

                                else:

                                    stop["aaf"] = False

                                    client.sendMessage(msg.to, "自動追加をオフにしました")

                            ##############################################

                            if "追加メッセージ:" in msg.text:

                                text = msg.text.replace("追加メッセージ:", "")

                                if text in ["", " ", "\n", None]:

                                    client.sendMessage(msg.to, "変更できない文字列です。")

                                else:

                                    stop["aam"] = text

                                    client.sendMessage(msg.to, "[%s]\nに変更しました" % text)

                            ##############################################

                            if "追加メッセージ on" == msg.text:

                                if stop["aafm"] == True:

                                    client.sendMessage(msg.to, "既にオンです")

                                else:

                                    stop["aafm"] = True

                                    client.sendMessage(msg.to, "追加メッセージをオンにしました")

                            ##############################################

                            if "追加メッセージ off" == msg.text:

                                if stop["aafm"] == False:

                                    client.sendMessage(msg.to, "既にオフです")

                                else:

                                    stop["aafm"] = False

                                    client.sendMessage(msg.to, "追加メッセージをオフにしました")

                            ##############################################

                            if "参加 on" == msg.text:

                                if stop["aj"] == True:

                                    client.sendMessage(msg.to, "既にオンです")

                                else:

                                    stop["aj"] = True

                                    client.sendMessage(msg.to, "自動参加を許可しました")

                            ##############################################

                            if "参加 off" == msg.text:

                                if stop["aj"] == False:

                                    client.sendMessage(msg.to, "既にオフです")

                                else:

                                    stop["aj"] = False

                                    client.sendMessage(msg.to, "自動参加を拒否しました")

                            ##############################################

                            if "参加メッセージ:" in msg.text:

                                text = msg.text.replace("参加メッセージ:", "")

                                if text in ["", " ", "\n", None]:

                                    client.sendMessage(msg.to, "変更できない文字列です。")

                                else:

                                    stop["ajm"] = text

                                    client.sendMessage(msg.to, "[%s]\nに変更しました" % text)

                            #############################################

                            if "参加メッセージ on" == msg.text:

                                if stop["ajfm"] == True:

                                    client.sendMessage(msg.to, "既にオンです")

                                else:

                                    stop["ajfm"] = True

                                    client.sendMessage(msg.to, "参加メッセージをオンにしました")

                            #############################################

                            if "参加メッセージ off" == msg.text:

                                if stop["ajfm"] == False:

                                    client.sendMessage(msg.to, "既にオフです")

                                else:

                                    stop["ajfm"] = False

                                    client.sendMessage(msg.to, "参加メッセージをオフにしました")

                            #############################################

                            if "強制 on" == msg.text:

                                if stop["arl"] == True:

                                    client.sendMessage(msg.to, "既にオンです")

                                else:

                                    stop["arl"] = True

                                    client.sendMessage(msg.to, "自動強制退会をオンにしました")

                            #############################################

                            if "強制 off" == msg.text:

                                if stop["arl"] == False:

                                    client.sendMessage(msg.to, "既にオフです")

                                else:

                                    stop["arl"] = False

                                    client.sendMessage(msg.to, "自動強制退会をオフしました")

                            #############################################

                            if "共有 on" == msg.text:

                                if stop["noto"] == True:

                                    client.sendMessage(msg.to, "既にオンです")

                                else:

                                    stop["noto"] = True

                                    client.sendMessage(msg.to, "共有をオンにしました")

                            #############################################

                            if "共有 off" == msg.text:

                                if stop["noto"] == False:

                                    client.sendMessage(msg.to, "既にオフです")

                                else:

                                    stop["noto"] = False

                                    client.sendMessage(msg.to, "共有をオフにしました")

                            #############################################

                            if "check" == msg.text:

                                mtn = ""

                                mtn += "追加メッセージ : \n\n%s\n\n" % stop['aam']

                                mtn += "参加メッセージ : \n\n%s\n\n" % stop['ajm']

                                if stop['aj'] == False:

                                    mtn += "自動参加 :off\n"

                                else:

                                    mtn += "自動参加 :on\n"

                                if stop['aaf'] == False:

                                    mtn += "自動追加 :off\n"

                                else:

                                    mtn += "自動追加 :on\n"

                                if stop['arl'] == False:

                                    mtn += "強制 :off\n"

                                else:

                                    mtn += "強制 :on\n"

                                if stop['noto'] == False:

                                    mtn += "共有 :off\n"

                                else:

                                    mtn += "共有 :on\n"

                                if stop['contact'] == False:

                                    mtn += "連絡先 :off\n"

                                else:

                                    mtn += "連絡先 :on\n"

                                if stop['ajfm'] == False:

                                    mtn += "参加メッセージ :off\n"

                                else:

                                    mtn += "参加メッセージ :on\n"

                                if stop['aafm'] == False:

                                    mtn += "追加メッセージ :off"

                                else:

                                    mtn += "追加メッセージ :on"

                                client.sendMessage(msg.to, mtn)

                            #############################################

                            if msg.text == "speed":

                                start = time.time()

                                client.sendMessage(msg.to, "loading...")

                                elapsed_time = time.time() - start

                                client.sendMessage(msg.to, "result\n>>%ssec" % (elapsed_time))

                            ##############################################

                            if msg.text == 'end':

                                f = codecs.open('PP.json', 'w', 'utf-8')

                                json.dump(stop["PP"], f, sort_keys=True, indent=4, ensure_ascii=False)

                                f = codecs.open('PN.json', 'w', 'utf-8')

                                json.dump(stop["PN"], f, sort_keys=True, indent=4, ensure_ascii=False)

                                f = codecs.open('PI.json', 'w', 'utf-8')

                                json.dump(stop["PI"], f, sort_keys=True, indent=4, ensure_ascii=False)

                                f = codecs.open('black.json', 'w', 'utf-8')

                                json.dump(stop["bls"], f, sort_keys=True, indent=4, ensure_ascii=False)

                                client.sendMessage(msg.to, '半botを終了します。')

                                sys.exit(0)

                            ##############################################

                            if "url:" in msg.text:

                                gid = msg.text.replace("url:", "")

                                gurl = client.reissueGroupTicket(gid)

                                client.sendMessage(msg.to, "line://ti/g/" + gurl)

                            ##############################################

                            if msg.text == "url":

                                g = client.getGroup(msg.to)

                                if g.preventJoinByTicket == False:

                                    client.sendMessage(msg.to,

                                                       "参加可能状態です\n\nline://ti/g/" + client._client.reissueGroupTicket(

                                                           msg.to))

                                else:

                                    client.sendMessage(msg.to,

                                                       "参加拒否状態です\n\nline://ti/g/" + client._client.reissueGroupTicket(

                                                           msg.to))

                            ##############################################

                            if msg.text == "url on":

                                g = client.getGroup(msg.to)

                                if g.preventJoinByTicket == False:

                                    client.sendMessage(msg.to, '既にオンです。')

                                else:

                                    g.preventJoinByTicket = False

                                    client.updateGroup(g)

                                    client.sendMessage(msg.to, 'url on！')

                            ##############################################

                            if msg.text == "url off":

                                g = client.getGroup(msg.to)

                                if g.preventJoinByTicket == True:

                                    client.sendMessage(msg.to, '既にオフです。')

                                else:

                                    g.preventJoinByTicket = True

                                    client.updateGroup(g)

                                    client.sendMessage(msg.to, 'url off！')

                            ##############################################

                            if "adb" == msg.text:

                                if stop['blc'] == True:

                                    client.sendMessage(msg.to, "アカウントを送信してください。")

                                    stop["wb"] = True

                                else:

                                    client.sendMessage(msg.to, "ブラックリスト機能をオンにしてください")

                            if "adbm:" in msg.text:

                                if msg.contentMetadata is not None:

                                    targets = []

                                    key = eval(msg.contentMetadata["MENTION"])

                                    key["MENTIONEES"][0]["M"]

                                    for x in key["MENTIONEES"]:

                                        targets.append(x["M"])

                                    for target in targets:

                                        if target in stop["bls"]:

                                            client.sendMessage(msg.to, "既に登録されています。")

                                        else:

                                            stop["bls"][target] = True

                                    client.sendMessage(msg.to, "black in！")

                                    f = codecs.open('black.json', 'w', 'utf-8')

                                    json.dump(stop["bls"], f, sort_keys=True, indent=4, ensure_ascii=False)

                                    f.close()

                            ##############################################

                            if "delb" == msg.text:

                                if stop['blc'] == True:

                                    client.sendMessage(msg.to, "アカウントを送信してください。")

                                    stop["db"] = True

                                else:

                                    client.sendMessage(msg.to, "ブラックリスト機能をオンにしてください")

                            if "delbm:" in msg.text:

                                if msg.contentMetadata is not None:

                                    targets = []

                                    key = eval(msg.contentMetadata["MENTION"])

                                    key["MENTIONEES"][0]["M"]

                                    for x in key["MENTIONEES"]:

                                        targets.append(x["M"])

                                    for target in targets:

                                        if target in stop["bls"]:

                                            del stop["bls"][target]

                                        else:

                                            client.sendMessage(msg.to, "登録されてません。")

                                    client.sendMessage(msg.to, "black out！")

                                    f = codecs.open('black.json', 'w', 'utf-8')

                                    json.dump(stop["bls"], f, sort_keys=True, indent=4, ensure_ascii=False)

                                    f.close()

                            ##############################################

                            if "abc" == msg.text:

                                if stop["bls"] == {}:

                                    client.sendMessage(msg.to, "ブラックリストにしている人はいないよ")

                                else:

                                    client.sendMessage(msg.to, "以下がブラックリストです。")

                                    mc = ""

                                    for mi_d in stop["bls"]:

                                        try:

                                            mc += "・" + client.getContact(mi_d).displayName + "\n"

                                        except Exception as error:

                                            client.sendMessage(msg.to, str(error))

                                    client.sendMessage(msg.to, mc)

                            ##############################################

                            if "bc" == msg.text:

                                group = client.getGroup(msg.to)

                                gMembMids = [contact.mid for contact in group.members]

                                matched_list = []

                                for tag in stop["bls"]:

                                    matched_list += filter(lambda str: str == tag, gMembMids)

                                cocoa = ""

                                for mm in matched_list:

                                    try:

                                        cocoa += client.getContact(mm).displayName + "\n"

                                    except Exception as error:

                                        try:

                                            client.sendMessage(msg.to, str(error))

                                        except:

                                            pass

                                if cocoa == "":

                                    client.sendMessage(msg.to, "ブラックリストに入っているユーザーいません。")

                                else:

                                    client.sendMessage(msg.to, cocoa + "がブラックリストです。")

                            ##############################################

                            if "bk" == msg.text:

                                group = client.getGroup(msg.to)

                                gMembMids = [contact.mid for contact in group.members]

                                matched_list = []

                                for tag in stop["bls"]:

                                    matched_list += filter(lambda str: str == tag, gMembMids)

                                if matched_list == []:

                                    client.sendMessage(msg.to, "ブラックリストユーザーはいません。")

                                for jj in matched_list:

                                    try:

                                        client.kickoutFromGroup(msg.to, [jj])

                                    except:

                                        client.kickoutFromGroup(msg.to, [jj])

                                client.sendMessage(msg.to, "kick完了。")

                            ##############################################

                            if "NK:" in msg.text:

                                name = msg.text.replace("NK:", '')

                                gs = client.getGroup(msg.to)

                                targets = []

                                for g in gs.members:

                                    if name in g.displayName:

                                        targets.append(g.mid)

                                if targets == []:

                                    client.sendMessage(msg.to, "Not Found.")

                                else:

                                    for target in targets:

                                        try:

                                            client.kickoutFromGroup(msg.to, [target])

                                        except:

                                            client.sendMessage(msg.to, 'Error')

                            ##############################################

                            if "MK:" in msg.text:

                                if msg.contentMetadata is not None:

                                    targets = []

                                    key = eval(msg.contentMetadata["MENTION"])

                                    key["MENTIONEES"][0]["M"]

                                    for x in key["MENTIONEES"]:

                                        targets.append(x["M"])

                                    for target in targets:

                                        try:

                                            client.kickoutFromGroup(gid, [target])

                                        except:

                                            client.sendMessage(gid, "Error")

                                else:

                                    pass



                        if msg.contentType == 13:

                            if stop['contact'] == True:

                                contact = client.getContact(msg.contentMetadata["mid"])

                                client.sendMessage(msg.to, "[displayName]:\n" + msg.contentMetadata[

                                    "displayName"] + "\n[mid]:\n" + msg.contentMetadata[

                                                       "mid"] + "\n[statusMessage]:\n" + contact.statusMessage + "\n[pictureStatus]:\nhttp://dl.profile.line-cdn.net/" + contact.pictureStatus)

                            if stop['blc'] == True:

                                if stop["wb"] == True:

                                    if msg.contentMetadata["mid"] in stop["bls"]:

                                        client.sendMessage(msg.to, "既に登録されています。")

                                        stop["wb"] = False

                                    else:

                                        stop["bls"][msg.contentMetadata["mid"]] = True

                                        stop["wb"] = False

                                        client.sendMessage(msg.to, "black in！")

                                        f = codecs.open('black.json', 'w', 'utf-8')

                                        json.dump(stop["bls"], f, sort_keys=True, indent=4, ensure_ascii=False)

                                if stop["db"] == True:

                                    if msg.contentMetadata["mid"] in stop["bls"]:

                                        del stop["bls"][msg.contentMetadata["mid"]]

                                        client.sendMessage(msg.to, "black out！")

                                        stop["db"] = False

                                        f = codecs.open('black.json', 'w', 'utf-8')

                                        json.dump(stop["bls"], f, sort_keys=True, indent=4, ensure_ascii=False)

                                    else:

                                        stop["db"] = False

                                        client.sendMessage(msg.to, "登録されてません。")



                        if msg.contentType == 16:

                            if stop['noto'] == True:

                                if 'text' not in msg.contentMetadata:

                                    if 'mediaOid' in msg.contentMetadata:

                                        Object = msg.contentMetadata['mediaOid'].replace("svc=myhome|sid=h|", "")

                                        if msg.contentMetadata['mediaType'] == 'V':

                                            if msg.contentMetadata['serviceType'] == 'GB':

                                                client.sendMessage(msg.to, client.getContact(

                                                    msg._from).displayName + "さんがノートに投稿しました！\n\n[postURL]\n" +

                                                                   msg.contentMetadata[

                                                                       'postEndUrl'] + "\n[ObjectURL]\nhttps://obs-us.line-apps.com/myhome/h/download.nhn?tid=612w&oid=" +

                                                                   msg.contentMetadata[

                                                                       'mediaOid'] + "\n[MediaURL]\nhttps://obs-us.line-apps.com/myhome/h/download.nhn?oid=" +

                                                                   msg.contentMetadata['mediaOid'])

                                            else:

                                                client.sendMessage(msg.to,

                                                                   client.getContact(msg._from).displayName + "さんが" +

                                                                   msg.contentMetadata[

                                                                       'serviceName'] + "さんの投稿を共有しました！\n\n[postURL]\n" +

                                                                   msg.contentMetadata[

                                                                       'postEndUrl'] + "\n[ObjectURL]\nhttps://obs-us.line-apps.com/myhome/h/download.nhn?tid=612w&" + Object + "\n[MediaURL]\nhttps://obs-us.line-apps.com/myhome/h/download.nhn?" + Object)

                                        else:

                                            if msg.contentMetadata['serviceType'] == 'GB':

                                                client.sendMessage(msg.to, client.getContact(

                                                    msg._from).displayName + "さんがノートに投稿しました！\n\n[postURL]\n" +

                                                                   msg.contentMetadata[

                                                                       'postEndUrl'] + "\n[ObjectURL]\nhttps://obs-us.line-apps.com/myhome/h/download.nhn?oid=" +

                                                                   msg.contentMetadata['mediaOid'])

                                            else:

                                                client.sendMessage(msg.to,

                                                                   client.getContact(msg._from).displayName + "さんが" +

                                                                   msg.contentMetadata[

                                                                       'serviceName'] + "さんの投稿を共有しました！\n\n[postURL]\n" +

                                                                   msg.contentMetadata[

                                                                       'postEndUrl'] + "\n[ObjectURL]\nhttps://obs-us.line-apps.com/myhome/h/download.nhn?" + Object)

                                    elif 'stickerId' in msg.contentMetadata:

                                        if msg.contentMetadata['serviceType'] == 'GB':

                                            client.sendMessage(msg.to, client.getContact(

                                                msg._from).displayName + "さんがノートに投稿しました！\n\n[postURL]\n" +

                                                               msg.contentMetadata[

                                                                   'postEndUrl'] + "\n[Package]\nhttp://line.me/R/shop/detail/" +

                                                               msg.contentMetadata['packageId'])

                                        else:

                                            client.sendMessage(msg.to,

                                                               client.getContact(msg._from).displayName + "さんが" +

                                                               msg.contentMetadata[

                                                                   'serviceName'] + "さんの投稿を共有しました！\n\n[postURL]\n" +

                                                               msg.contentMetadata[

                                                                   'postEndUrl'] + "\n[Package]\nhttp://line.me/R/shop/detail/" +

                                                               msg.contentMetadata['packageId'])

                                    else:

                                        if msg.contentMetadata['serviceType'] == 'GB':

                                            client.sendMessage(msg.to, client.getContact(

                                                msg._from).displayName + "さんがノートに投稿しました！\n\n[postURL]\n" +

                                                               msg.contentMetadata['postEndUrl'])

                                        else:

                                            client.sendMessage(msg.to,

                                                               client.getContact(msg._from).displayName + "さんが" +

                                                               msg.contentMetadata[

                                                                   'serviceName'] + "さんの投稿を共有しました！\n\n[postURL]\n" +

                                                               msg.contentMetadata['postEndUrl'])

                                else:

                                    if 'mediaOid' in msg.contentMetadata:

                                        Object = msg.contentMetadata['mediaOid'].replace("svc=myhome|sid=h|", "")

                                        if msg.contentMetadata['mediaType'] == 'V':

                                            if msg.contentMetadata['serviceType'] == 'GB':

                                                client.sendMessage(msg.to, client.getContact(

                                                    msg._from).displayName + "さんがノートに投稿しました！\n\n[postURL]\n" +

                                                                   msg.contentMetadata['postEndUrl'] + "\n[text]\n" +

                                                                   msg.contentMetadata[

                                                                       'text'] + "\n[ObjectURL]\nhttps://obs-us.line-apps.com/myhome/h/download.nhn?tid=612w&oid=" +

                                                                   msg.contentMetadata[

                                                                       'mediaOid'] + "\n[MediaURL]\nhttps://obs-us.line-apps.com/myhome/h/download.nhn?oid=" +

                                                                   msg.contentMetadata['mediaOid'])

                                            else:

                                                client.sendMessage(msg.to,

                                                                   client.getContact(msg._from).displayName + "さんが" +

                                                                   msg.contentMetadata[

                                                                       'serviceName'] + "さんの投稿を共有しました！\n\n[postURL]\n" +

                                                                   msg.contentMetadata['postEndUrl'] + "\n[text]\n" +

                                                                   msg.contentMetadata[

                                                                       'text'] + "\n[ObjectURL]\nhttps://obs-us.line-apps.com/myhome/h/download.nhn?tid=612w&" + Object + "\n[MediaURL]\nhttps://obs-us.line-apps.com/myhome/h/download.nhn?" + Object)

                                        else:

                                            if msg.contentMetadata['serviceType'] == 'GB':

                                                client.sendMessage(msg.to, client.getContact(

                                                    msg._from).displayName + "さんがノートに投稿しました！\n\n[postURL]\n" +

                                                                   msg.contentMetadata['postEndUrl'] + "\n[text]\n" +

                                                                   msg.contentMetadata[

                                                                       'text'] + "\n[ObjectURL]\nhttps://obs-us.line-apps.com/myhome/h/download.nhn?oid=" +

                                                                   msg.contentMetadata['mediaOid'])

                                            else:

                                                client.sendMessage(msg.to,

                                                                   client.getContact(msg._from).displayName + "さんが" +

                                                                   msg.contentMetadata[

                                                                       'serviceName'] + "さんの投稿を共有しました！\n\n[postURL]\n" +

                                                                   msg.contentMetadata['postEndUrl'] + "\n[text]\n" +

                                                                   msg.contentMetadata[

                                                                       'text'] + "\n[ObjectURL]\nhttps://obs-us.line-apps.com/myhome/h/download.nhn?" + Object)

                                    elif 'stickerId' in msg.contentMetadata:

                                        if msg.contentMetadata['serviceType'] == 'GB':

                                            client.sendMessage(msg.to, client.getContact(

                                                msg._from).displayName + "さんがノートに投稿しました！\n\n[postURL]\n" +

                                                               msg.contentMetadata['postEndUrl'] + "\n[text]\n" +

                                                               msg.contentMetadata[

                                                                   'text'] + "\n[Package]\nhttp://line.me/R/shop/detail/" +

                                                               msg.contentMetadata['packageId'])

                                        else:

                                            client.sendMessage(msg.to,

                                                               client.getContact(msg._from).displayName + "さんが" +

                                                               msg.contentMetadata[

                                                                   'serviceName'] + "さんの投稿を共有しました！\n\n[postURL]\n" +

                                                               msg.contentMetadata['postEndUrl'] + "\n[text]\n" +

                                                               msg.contentMetadata[

                                                                   'text'] + "\n[Package]\nhttp://line.me/R/shop/detail/" +

                                                               msg.contentMetadata['packageId'])

                                    else:

                                        if msg.contentMetadata['serviceType'] == 'GB':

                                            client.sendMessage(msg.to, client.getContact(

                                                msg._from).displayName + "さんがノートに投稿しました！\n\n[postURL]\n" +

                                                               msg.contentMetadata['postEndUrl'] + "\n[text]\n" +

                                                               msg.contentMetadata['text'])

                                        else:

                                            client.sendMessage(msg.to,

                                                               client.getContact(msg._from).displayName + "さんが" +

                                                               msg.contentMetadata[

                                                                   'serviceName'] + "さんの投稿を共有しました！\n\n[postURL]\n" +

                                                               msg.contentMetadata['postEndUrl'] + "\n[text]\n" +

                                                               msg.contentMetadata['text'])



                    except Exception as e:

                        client.log("[SEND_MESSAGE] ERROR : " + str(e))

                poll.setRevision(op.revision)



    except Exception as e:

        client.log("[SINGLE_TRACE] ERROR : " + str(e))

