import base64
inp = "ちんこ"
einp = base64.b64encode(inp)
print(einp)