# -*- coding: UTf-8 -*-
import getch

class Block:
    def move(self):
        while(True):
            key - ord(getch.getch())
            if(key== 3):
                print("bye!!!")
                break;
            print("key input:" + str(key))

hero = block()
block.move
