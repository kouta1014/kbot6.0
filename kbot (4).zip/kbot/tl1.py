from linepy import *
client = LINE('koutamanto@icloud.com','kouta1014')
client.log("Auth Token :"+str(client.authToken))

oepoll = OEPoll(client)

def SEND_MESSAGE(op):
	msg = op.message

	text = msg.text
	to = msg.to
	try:
		if text.lower() == 'tl':
			sendMessageToMyHome("test message(auto)")
	except Exception as e:
		client.log("[SEND_MESSAGE]ERROR :"+ str(e))
oepoll.addOpInterruptWithDict({
	OpType.SEND_MESSAGE: SEND_MESSAGE,

})
while True:
	oepoll.trace()
	
