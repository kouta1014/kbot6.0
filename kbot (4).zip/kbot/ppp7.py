  # -*- coding: utf-8 -*-
from linepy import *
import time, random ,sys, re, string, os, json, codecs, threading, string, requests, glob, subprocess, six, ast, pytz, urllib, timeit , psutil , shutil
from datetime import datetime
from time import sleep
import subprocess
from humanfriendly import format_timespan, format_size, format_number, format_length

botStart = time.time()

client = LINE ('pahe782@risu.be','kouta1014')
Kicker1 = LINE("kicker1@prin.be","you1209")
Kicker2 = LINE("kicker3@prin.be","you1209")
Kicker3 = LINE("kicker2@prin.be","you1209")
Kicker4 = LINE("kicker4@prin.be","you1209")
Kicker5 = LINE("kicker5@prin.be","you1209")
Kicker6 = LINE("kicker6@prin.be","you1209")
Kicker7 = LINE("kicker7@prin.be","you1209")
Kicker8 = LINE("kicker8@prin.be","you1209")
Kicker9 = LINE("kicker9@prin.be","you1209")
KAC=[Kicker1,Kicker2,Kicker3,Kicker4,Kicker5,Kicker6,Kicker7,Kicker8,Kicker9]
i=0

botMids = [Kicker1.getProfile().mid, Kicker2.getProfile().mid, Kicker3.getProfile().mid, Kicker4.getProfile().mid, Kicker5.getProfile().mid,Kicker6.getProfile().mid, Kicker7.getProfile().mid, Kicker8.getProfile().mid, Kicker9.getProfile().mid]
profile, setting, tracer = client.getProfile(), client.getSettings(), OEPoll(client)
profile_B,setting_B = Kicker1.getProfile(),Kicker1.getSettings()
profile_C,setting_C = Kicker2.getProfile(),Kicker2.getSettings()
profile_D,setting_D = Kicker3.getProfile(),Kicker3.getSettings()
profile_E,setting_E = Kicker4.getProfile(),Kicker4.getSettings()
profile_F,setting_F = Kicker5.getProfile(),Kicker5.getSettings()
profile_G,setting_G = Kicker6.getProfile(),Kicker6.getSettings()
profile_H,setting_H = Kicker7.getProfile(),Kicker7.getSettings()
profile_I,setting_I = Kicker8.getProfile(),Kicker8.getSettings()
profile_J,setting_J = Kicker9.getProfile(),Kicker9.getSettings()


offbot, messageReq, wordsArray, waitingAnswer = [], {}, {}, {}
InviC = {}

Count={
    'kick':0,
    'invite':0,
    'cancel':0
}


wait = {
    'bye':{},
    'readPoint':{},
    'rapidFire':{},
    'readMember':{},
    'protect':{},
    'groupPicture': {},
    'PROTECTURLINVITECHANGE':{},
    'PROTECTKICK':{},
    'PROTECTGNAMECHANGE':{},
    'MessageCount':{},
    'setTime':{},
    'kick':{},
    'blacklist':{},
    'wblacklist':{},
    'wdblacklist':{},
    'wwhitelist':{},
    'wdwhitelist':{},
    'ROM':{},
   }

whitelist = {}
try:
    f=codecs.open('black.json','r','utf-8')
    wait["blacklist"] = json.load(f)
    f= codecs.open('groupPicture.json', 'r', 'utf-8')
    wait['groupPicture'] = json.load(f) 
    f=codecs.open('protect.json','r','utf-8')
    wait["protect"] = json.load(f)
    f=codecs.open('PROTECTKICK.json','r','utf-8')
    wait["PROTECTKICK"] = json.load(f)
    f=codecs.open('PROTECTURLINVITECHANGE.json','r','utf-8')
    wait["PROTECTURLINVITECHANGE"] = json.load(f)
    f=codecs.open('whitelist.json','r','utf-8')
    whitelist = json.load(f)
except:
    pass
try:
    f=codecs.open('PROTECTGNAMECHANGE.json','r','utf-8')
    wait["PROTECTGNAMECHANGE"] = json.load(f)
except:
    pass
JoinG={}
try:
    f=codecs.open('JoinG.json','r','utf-8')
    JoinG = json.load(f)
except:
    pass
Messid = {}
try:
    f=codecs.open('Messid.json','r','utf-8')
    Messid = json.load(f)
except:
    pass
InviK={}
try:
    f=codecs.open('InviK.json','r','utf-8')
    InviK = json.load(f)
except:
    pass
try:
    f = open("Cancelbot.txt","r")
    Cancelbot = []
    for x in f:
        Cancelbot.append(x.rstrip("\n"))
    f.close()
except:
	Cancelbot = []

gname = {}
gname = wait["PROTECTGNAMECHANGE"]
setTime = {}
setTime = wait["setTime"]
##print type(wait)
res = {
    'num':{},
    'us':{},
    'au':{},
    }

m_from = ""
m_to = ""
ROM={"kickt":{},"kicku":{},"now":""}
ROM["now"] = datetime.now()
admins = ('u1505299bc3e6d961c34321d34e2aa415')
def sendTemplate2(to, data):
    try:
        xyz = LiffChatContext(to)
        xyzz = LiffContext(chat=xyz)
        view = LiffViewRequest('1648648835-2wWJ9ExZ', xyzz)
        token = client.liff.issueLiffView(view)
        url = 'https://api.line.me/message/v3/share'
        headers = {
            'Content-Type': 'application/json',
            'Authorization': 'Bearer %s' % token.accessToken
        }
        data = {"messages": [{"type": "flex","altText": "Flex","contents": data}]}
        r = requests.post(url, headers=headers, data=json.dumps(data))
    except Exception as e:
        print (e)
        client.sendMessage(to,str(e))
try:
    f = open("adminG.txt","r")
    adminG = []
    for x in f:
        adminG.append(x.rstrip("\n"))
    f.close()
except:
    adminG = []
try:
    f = open("AlbumP.txt","r")
    AlbumP = []
    for x in f:
        AlbumP.append(x.rstrip("\n"))
    f.close()
except:
    AlbumP = []
try:
    f = open("ReMess.txt","r")
    ReMess = []
    for x in f:
        ReMess.append(x.rstrip("\n"))
    f.close()
except:
    ReMess = []
#最高管理者
#p1 =
["u61999b628f0bf9d3f7b874d622d4fede"]

#p1t = []
#f = open("p1.txt", "r")
#for x in f:
#    p1t.append(x.rstrip("\n"))
#f.close()
#p1 = list(set(p1t))
p1 = {
}
try:
    f=codecs.open('p1.json','r','utf-8')
    p1 = json.load(f)
except:
    mode = int(input("1:exit 2:continue :")) 
    if mode == 1:
        sys.exit(0)
    elif mode == 2:
        print("p1.json読み込みエラーだよ")
        p1t = []
        f = open("p1.txt", "r")
        for x in f:
            p1t.append(x.rstrip("\n"))
        f.close()
        p1s = list(set(p1t))
        for hi in p1s:
            p1[hi] = True
        f=codecs.open('p1.json','w','utf-8')
        json.dump(p1, f, sort_keys=True, indent=4,ensure_ascii=False)
#招待、保護、保護　オフ、kick、終了、保存、ブラック追加・削除が可能
p2 =[""]
#招待、保護、保護　オフ、kick、が可能
p3 = [""]
#招待、保護、保護　オフ、が可能
haveP = {}
haveP.update(p1)
kickers = [profile_B.mid,profile_C.mid,profile_D.mid,profile_E.mid,profile_F.mid,profile_G.mid,profile_H.mid,profile_I.mid,profile_J.mid]
bots = [profile.mid,profile_B.mid,profile_C.mid,profile_D.mid,profile_E.mid,profile_F.mid,profile_G.mid,profile_H.mid,profile_I.mid,profile_J.mid]
##print wait
client.sendMessage("u61999b628f0bf9d3f7b874d622d4fede","システムチェック完了したよ。\n\n異常はありませんでした")
client.sendMessage("u61999b628f0bf9d3f7b874d622d4fede","もう使えるよ")

#print u'実行しました。'

def restartBot():
    print ("[ INFO ] BOT RESETTED")
    python = sys.executable
    os.execl(python, python, *sys.argv)

def cms(string, commands): #/XXX, >XXX, ;XXX, ^XXX, %XXX, $XXX...
    tex = ["+","@","/",">",";","^","%","$","＾"]
    for texX in tex:
        for command in commands:
            if string ==texX + command:
                return True
    return False

def cmi(string, commands): #/XXX, >XXX, ;XXX, ^XXX, %XXX, $XXX...
    tex = ["+","@","/",">",";","^","%","$","＾"]
    for texX in tex:
        for command in commands:
            if texX + command in string:
                return True
    return False

def cmd(text, commands):
    for command in commands:
        if command in text:
            return True
    return False

def check_p_u(uh,mem):
    if uh in admins:
        return True
    elif uh in mem:
        if not mem[uh] == True:
            ttime = datetime.today()
            if datetime.strptime(mem[uh],'%Y/%m/%d') < ttime:
                return False
            else:
                return True
        else:
            return True
    return False

def download_img(url, file_name):
    r = requests.get(url, stream=True)
    if r.status_code == 200:
        with open(file_name, 'wb') as f:
            r.raw.decode_content = True
            shutil.copyfileobj(r.raw, f)


def random_string(length, seq='0123456789abcdefghijklmnopqrstuvwxyz'):
    sr = random.SystemRandom()
    return ''.join([sr.choice(seq) for i in range(length)])

def check_p(mm):
    if mm._from in admins:
        return True
    elif mm._from in p1:
        if not p1[mm._from] == True:
            ttime = datetime.today()
            if datetime.strptime(p1[mm._from],'%Y/%m/%d') < ttime:
                client.sendMessage(mm.to,"期限が切れています。")
                return False
            else:
                return True
        else:
            return True
    return False

def chooseB(pa):
    KIC = []
    if profile_B.mid == pa:
        KIC = KAC - Kicker1
    elif profile_C.mid == pa:
        KIC = KAC - Kicker2
    elif profile_D.mid == pa:
        KIC = KAC - Kicker3
    elif profile_E.mid == pa:
        KIC = KAC - Kicker4
    elif profile_F.mid == pa:
        KIC = KAC - Kicker5    
    elif profile_G.mid == pa:
        KIC = KAC - Kicker6
    elif profile_H.mid == pa:
        KIC = KAC - Kicker7
    elif profile_I.mid == pa:
        KIC = KAC - Kicker8    
    elif profile_J.mid == pa:
        KIC = KAC - Kicker9               
    
    else:
        KIC = KAC
    return random.choice(KIC)


def N_kick(op):
    try:
        if not op.param2 in (list(haveP.keys()) + whitelist[op.param1] + bots):
            if not op.param1 in list(ROM["kickt"]):
                ROM["kickt"][op.param1]=[]
            if not op.param1 in list(ROM["kicku"]):
                ROM["kicku"][op.param1]=[]
            ROM["kickt"][op.param1].append(ROM["now"])
            if not op.param2 in ROM["kicku"][op.param1]:
                ROM["kicku"][op.param1].append(op.param2)
            if  len(ROM["kickt"][op.param1]) >= 5:
                print("15秒以内で5回以上のキックを確認しました。" + op.param1)
                for u in ROM["kicku"][op.param1]:
                    client.kickoutFromGroup(op.param1,u)
                    if u in wait["blacklist"]:
                        pass
                    else:
                        wait["blacklist"][u] = True
                        f=codecs.open('black.json','w','utf-8')
                        json.dump(wait["blacklist"], f, sort_keys=True, indent=4,ensure_ascii=False)
                client.sendMessage(op.param1,"15秒以内の複数人によるキックが検知されました。")
        if op.param1 in wait["PROTECTKICK"]:
            if op.param2 in kickers:
                return
            elif op.param3 in kickers:
                wait["PROTECTURLINVITECHANGE"][op.param1] = True
                G = client.getGroup(op.param1)
                G.preventedJoinByTicket = False
                client.updateGroup(G)
                Ticket = client.reissueGroupTicket(op.param1)
                if op.param2 in (list(haveP.keys()) + whitelist[op.param1]):
                    if op.param3 == profile_B.mid:
                        Kicker1.acceptGroupInvitationByTicket(op.param1,Ticket)
                    elif op.param3 == profile_C.mid:
                        Kicker2.acceptGroupInvitationByTicket(op.param1,Ticket)
                    elif op.param3 == profile_D.mid:
                        Kicker3.acceptGroupInvitationByTicket(op.param1,Ticket)
                    elif op.param3 == profile_E.mid:
                        Kicker4.acceptGroupInvitationByTicket(op.param1,Ticket)
                    elif op.param3 == profile_F.mid:
                        Kicker5.acceptGroupInvitationByTicket(op.param1,Ticket)
                    elif op.param3 == profile_G.mid:
                        Kicker6.acceptGroupInvitationByTicket(op.param1,Ticket)
                    elif op.param3 == profile_H.mid:
                        Kicker7.acceptGroupInvitationByTicket(op.param1,Ticket)
                    elif op.param3 == profile_I.mid:
                        Kicker8.acceptGroupInvitationByTicket(op.param1,Ticket)
                    elif op.param3 == profile_J.mid:
                        Kicker9.acceptGroupInvitationByTicket(op.param1,Ticket)

                else:
                    if op.param3 == profile_B.mid:
                        Kicker1.acceptGroupInvitationByTicket(op.param1,Ticket)
                    elif op.param3 == profile_C.mid:
                        Kicker2.acceptGroupInvitationByTicket(op.param1,Ticket)
                    elif op.param3 == profile_D.mid:
                        Kicker3.acceptGroupInvitationByTicket(op.param1,Ticket)
                    elif op.param3 == profile_E.mid:
                        Kicker4.acceptGroupInvitationByTicket(op.param1,Ticket)
                    elif op.param3 == profile_F.mid:
                        Kicker5.acceptGroupInvitationByTicket(op.param1,Ticket)
                    elif op.param3 == profile_G.mid:
                        Kicker6.acceptGroupInvitationByTicket(op.param1,Ticket)
                    elif op.param3 == profile_H.mid:
                        Kicker7.acceptGroupInvitationByTicket(op.param1,Ticket)
                    elif op.param3 == profile_I.mid:
                        Kicker8.acceptGroupInvitationByTicket(op.param1,Ticket)
                    elif op.param3 == profile_J.mid:
                        Kicker9.acceptGroupInvitationByTicket(op.param1,Ticket)            
                    try:
                        bot = random.choice(KAC)
                        bot.kickoutFromGroup(op.param1,[op.param2])
                    except:
                        try:
                            bot = random.choice(KAC)
                            bot.kickoutFromGroup(op.param1,[op.param2])
                        except:
                            pass
                    print("蹴り保護が設定されているグループでキッカーが蹴られました。キック完了。%s\n\r"%op.param2)
                    Count['kick']+=1
                    print(str(Count))
                    if op.param2 in wait["blacklist"]:
                        pass
                    else:
                        wait["blacklist"][op.param2] = True
                        f=codecs.open('black.json','w','utf-8')
                        json.dump(wait["blacklist"], f, sort_keys=True, indent=4,ensure_ascii=False)
                G = client.getGroup(op.param1)
                G.preventedJoinByTicket = True
                client.updateGroup(G)
            elif op.param3 == profile.mid:
                ##print "w"
                try:
                    if op.param2 in (list(haveP.keys()) + whitelist[op.param1]):
                        G = Kicker1.getGroup(op.param1)
                        G.preventedJoinByTicket = False
                        Kicker1.updateGroup(G)
                        Ticket = Kicker1.reissueGroupTicket(op.param1)
                        client.acceptGroupInvitationByTicket(op.param1,Ticket)
                        G.preventedJoinByTicket = True
                        Kicker1.updateGroup(G)
                    else:
                        wait["PROTECTURLINVITECHANGE"][op.param1] = True
                        try:
                            client.kickoutFromGroup(op.param1,[op.param2])
                            #pass
                        except:
                            try:
                                Kicker2.kickoutFromGroup(op.param1,[op.param2])
                                #pass
                            except:
                                pass
                        G = Kicker1.getGroup(op.param1)
                        G.preventedJoinByTicket = False
                        Kicker1.updateGroup(G)
                        Ticket = Kicker1.reissueGroupTicket(op.param1)
                        client.acceptGroupInvitationByTicket(op.param1,Ticket)
                        G.preventedJoinByTicket = True
                        Kicker1.updateGroup(G)
                        print("クライアントをキックしたためユーザーをキックしました。%s\n\r"%op.param2)
                        Count['kick']+=1
                        print(str(Count))
                        if op.param2 in wait["blacklist"]:
                            pass
                        else:
                            wait["blacklist"][op.param2] = True
                            f=codecs.open('black.json','w','utf-8')
                            json.dump(wait["blacklist"], f, sort_keys=True, indent=4,ensure_ascii=False)
                except:
                    pass

            elif op.param3 in (list(haveP.keys()) + whitelist[op.param1]):
                if op.param2 in (list(haveP.keys()) + whitelist[op.param1]):
                    try:
                        bot = random.choice(KAC)
                        bot.findAndAddContactsByMid(op.param3)
                        bot.inviteIntoGroup(op.param1,[op.param3])
                    except Exception as e:
                        print (e)
                else:
                    wait["PROTECTURLINVITECHANGE"][op.param1] = True
                    client.sendMessage(op.param1, "権限保有者を退会させたため、強制退出を試みます。")
                    gname = client.getGroup(op.param1).name
                    name = client.getContact(op.param2).displayName
                    client.sendMessage("c969c250c0b79bdfcece76bc22985d47e","[報告]\n\n権限保有者を強制退会させたユーザーがいたため違反者を退会させました\n\n[グループ名]\n→[" + gname + "]\n\n[違反者]\n→[" + name + "]\n\n[違反者mid]\n→[" + op.param2 + "]")
                    try:
                        #pass
                        rabdom.choice(KAC).kickoutFromGroup(op.param1,[op.param2])
                    except:
                        try:
                            #pass
                            Kicker1.kickoutFromGroup(op.param1,[op.param2])
                            Kicker2.kickoutFromGroup(op.param1,[op.param2])
                            Kicker3.kickoutFromGroup(op.param1,[op.param2])
                            Kicker4.kickoutFromGroup(op.param1,[op.param2])
                            Kicker5.kickoutFromGroup(op.param1,[op.param2])
                            Kicker6.kickoutFromGroup(op.param1,[op.param2])
                            Kicker7.kickoutFromGroup(op.param1,[op.param2])
                            Kicker8.kickoutFromGroup(op.param1,[op.param2])
                            Kicker9.kickoutFromGroup(op.param1,[op.param2])
                        except:
                            pass
                    print("権限保有者を退会させたためキックしました。%s\n\r"%op.param2)
                    Count['kick']+=1
                    Count['invite']+=1
                    print(str(Count))
                    bot = random.choice(KAC)
                    bot.findAndAddContactsByMid(op.param3)
                    bot.inviteIntoGroup(op.param1,[op.param3])
                    if op.param2 in wait["blacklist"]:
                        pass
                    else:
                        wait["blacklist"][op.param2] = True
                        f=codecs.open('black.json','w','utf-8')
                        json.dump(wait["blacklist"], f, sort_keys=True, indent=4,ensure_ascii=False)
                    G = client.getGroup(op.param1)
                    G.preventedJoinByTicket = True
                    client.updateGroup(G)

            else:
                if op.param2 in (list(haveP.keys()) + whitelist[op.param1]):
                    pass
                else:
                    wait["PROTECTURLINVITECHANGE"][op.param1] = True
                    try:
                        bot = random.choice(KAC)
                        bot.kickoutFromGroup(op.param1,[op.param2])
                    except:
                        try:
                            bot = random.choice(KAC)
                            bot.kickoutFromGroup(op.param1,[op.param2])
                        except:
                            pass
                    print("蹴り保護が設定してあるグループでキックを、検知したためキックしました。%s\n\r"%op.param2)
                    Count['kick']+=1
                    Count['invite']+=1
                    print(str(Count))
                    Inviter = op.param3.replace("",',')
                    InviterX = Inviter.split(",")
                    Kicker1.findAndAddContactsByMid(op.param3)
                    Kicker1.inviteIntoGroup(op.param1,InviterX)
                    if op.param2 in wait["blacklist"]:
                        pass
                    else:
                        wait["blacklist"][op.param2] = True
                        f=codecs.open('black.json','w','utf-8')
                        json.dump(wait["blacklist"], f, sort_keys=True, indent=4,ensure_ascii=False)
                    G = client.getGroup(op.param1)
                    G.preventedJoinByTicket = True
                    client.updateGroup(G)
        else:
            if op.param2 in bots:
                return
            elif op.param3 in (list(haveP.keys()) + whitelist[op.param1]):
                if op.param2 in haveP:
                    return
                wait["PROTECTURLINVITECHANGE"][op.param1] = True
                client.sendMessage(msg.to, "権限保有者またはホワイトリストユーザーを退会させたため、強制退出を試みます。")
                gname = client.getGroup(op.param1).name
                name = client.getContact(op.param2).displayName
                client.sendMessage("c969c250c0b79bdfcece76bc22985d47e","[報告]\n\n権限保有者またはホワイトリストユーザーを強制退会させたユーザーがいたため違反者を退会させました\n\n[グループ名]\n→[" + gname + "]\n\n[違反者]\n→[" + name + "]\n\n[違反者mid]\n→[" + op.param2 + "]")
                try:
                    #pass
                    bot = random.choice(KAC)
                    bot.kickoutFromGroup(op.param1,[op.param2])
                    client.kickoutFromGroup(op.param1,[op.param2])
                except:
                    #pass
                        Kicker1.kickoutFromGroup(op.param1,[op.param2])
                        Kicker2.kickoutFromGroup(op.param1,[op.param2])
                        Kicker3.kickoutFromGroup(op.param1,[op.param2])
                        Kicker4.kickoutFromGroup(op.param1,[op.param2])
                        Kicker5.kickoutFromGroup(op.param1,[op.param2])
                        Kicker6.kickoutFromGroup(op.param1,[op.param2])
                        Kicker7.kickoutFromGroup(op.param1,[op.param2])
                        Kicker8.kickoutFromGroup(op.param1,[op.param2])
                        Kicker9.kickoutFromGroup(op.param1,[op.param2])
                try:            
                    bot = random.choice(KAC)
                    bot.findAndAddContactsByMid(op.param3)
                    bot.inviteIntoGroup(op.param1, [op.param3])
                except:
                    Kicker3.findAndAddContactsByMid(op.param3)
                    Kicker3.inviteIntoGroup(op.param1, [op.param3])
                print("権限保有者がキックされたのでキックしました。%s\n\r"%op.param2)
                Count['kick']+=1
                Count['invite']+=1
                print(str(Count))
                if op.param1 in res['us']:
                    del res['num'][op.param1]
                    del res['us'][op.param1]
                else:
                    pass
                wait["blacklist"][op.param2] = True
                f=codecs.open('black.json','w','utf-8')
                json.dump(wait["blacklist"], f, sort_keys=True, indent=4,ensure_ascii=False)
            elif op.param3 in kickers:
                G = client.getGroup(op.param1)
                G.preventedJoinByTicket = False
                client.updateGroup(G)
                Ticket = client.reissueGroupTicket(op.param1)
                if op.param2 in (list(haveP.keys()) + whitelist[op.param1]):
                    if op.param3 == profile_B.mid:
                        Kicker1.acceptGroupInvitationByTicket(op.param1,Ticket)
                    elif op.param3 == profile_C.mid:
                        Kicker2.acceptGroupInvitationByTicket(op.param1,Ticket)
                    elif op.param3 == profile_D.mid:
                        Kicker3.acceptGroupInvitationByTicket(op.param1,Ticket)
                    elif op.param3 == profile_E.mid:
                        Kicker4.acceptGroupInvitationByTicket(op.param1,Ticket)
                    elif op.param3 == profile_F.mid:
                        Kicker5.acceptGroupInvitationByTicket(op.param1,Ticket)
                    elif op.param3 == profile_G.mid:
                        Kicker6.acceptGroupInvitationByTicket(op.param1,Ticket)
                    elif op.param3 == profile_H.mid:
                        Kicker7.acceptGroupInvitationByTicket(op.param1,Ticket)
                    elif op.param3 == profile_I.mid:
                        Kicker8.acceptGroupInvitationByTicket(op.param1,Ticket)
                    elif op.param3 == profile_J.mid:
                        Kicker9.acceptGroupInvitationByTicket(op.param1,Ticket)                
                else:
                    wait["PROTECTURLINVITECHANGE"][op.param1] = True
                    if op.param3 == profile_B.mid:
                        Kicker1.acceptGroupInvitationByTicket(op.param1,Ticket)
                    elif op.param3 == profile_C.mid:
                        Kicker2.acceptGroupInvitationByTicket(op.param1,Ticket)
                    elif op.param3 == profile_D.mid:
                        Kicker3.acceptGroupInvitationByTicket(op.param1,Ticket)
                    elif op.param3 == profile_E.mid:
                        Kicker4.acceptGroupInvitationByTicket(op.param1,Ticket)
                    elif op.param3 == profile_F.mid:
                        Kicker5.acceptGroupInvitationByTicket(op.param1,Ticket)
                    elif op.param3 == profile_H.mid:
                        Kicker7.acceptGroupInvitationByTicket(op.param1,Ticket)
                    elif op.param3 == profile_I.mid:
                        Kicker8.acceptGroupInvitationByTicket(op.param1,Ticket)
                    elif op.param3 == profile_J.mid:
                        Kicker9.acceptGroupInvitationByTicket(op.param1,Ticket)                   
                    if op.param2 in wait["blacklist"]:
                        pass
                    else:
                        wait["blacklist"][op.param2] = True
                        f=codecs.open('black.json','w','utf-8')
                        json.dump(wait["blacklist"], f, sort_keys=True, indent=4,ensure_ascii=False)
            elif op.param3 == profile.mid:
                ##print "w"
                try:
                    if op.param2 in (list(haveP.keys()) + whitelist[op.param1]):
                        G = Kicker1.getGroup(op.param1)
                        G.preventedJoinByTicket = False
                        Kicker1.updateGroup(G)
                        Ticket = Kicker1.reissueGroupTicket(op.param1)
                        client.acceptGroupInvitationByTicket(op.param1,Ticket)
                        G.preventedJoinByTicket = True
                        Kicker1.updateGroup(G)
                    else:
                        wait["PROTECTURLINVITECHANGE"][op.param1] = True
                        try:
                            client.kickoutFromGroup(op.param1,[op.param2])
                            #pass
                        except:
                            try:
                                #pass
                                Kicker1.kickoutFromGroup(op.param1,[op.param2])
                                Kicker2.kickoutFromGroup(op.param1,[op.param2])
                                Kicker3.kickoutFromGroup(op.param1,[op.param2])
                                Kicker4.kickoutFromGroup(op.param1,[op.param2])
                                Kicker5.kickoutFromGroup(op.param1,[op.param2])
                                Kicker6.kickoutFromGroup(op.param1,[op.param2])
                                Kicker7.kickoutFromGroup(op.param1,[op.param2])
                                Kicker8.kickoutFromGroup(op.param1,[op.param2])
                                Kicker9.kickoutFromGroup(op.param1,[op.param2])
                            except:
                                pass
                        print("クライアントがキックされたのでキックしました。%s\n\r"%op.param2)
                        Count['kick']+=1
                        print(str(Count))
                        G = Kicker1.getGroup(op.param1)
                        G.preventedJoinByTicket = False
                        Kicker1.updateGroup(G)
                        Ticket = Kicker1.reissueGroupTicket(op.param1)
                        client.acceptGroupInvitationByTicket(op.param1,Ticket)
                        G.preventedJoinByTicket = True
                        Kicker1.updateGroup(G)
                        if op.param2 in wait["blacklist"]:
                            pass
                        else:
                            wait["blacklist"][op.param2] = True
                            f=codecs.open('black.json','w','utf-8')
                            json.dump(wait["blacklist"], f, sort_keys=True, indent=4,ensure_ascii=False)
                except:
                    pass
            else:
                if op.param2 in kickers:
                    return
                if op.param1 in res['us']:
                    if op.param2 == res['us'][op.param1]:
                        res['num'][op.param1] += 1
                    else:
                        del res['num'][op.param1]
                        del res['us'][op.param1]
                        res['us'][op.param1] = op.param2
                        res['num'][op.param1] = 1
                else:
                    res['us'][op.param1] = op.param2
                    res['num'][op.param1] = 1
                if op.param1 in res['num']:
                    if res['num'][op.param1] >= 3:
                        if op.param2 in (list(haveP.keys()) + bots + whitelist[op.param1]):
                            del res['num'][op.param1]
                            del res['us'][op.param1]
                        else:
                            try:
                                client.kickoutFromGroup(op.param1, [op.param2])
                                #pass
                            except:
                                #pass
                                Kicker1.kickoutFromGroup(op.param1,[op.param2])
                                Kicker2.kickoutFromGroup(op.param1,[op.param2])
                                Kicker3.kickoutFromGroup(op.param1,[op.param2])
                                Kicker4.kickoutFromGroup(op.param1,[op.param2])
                                Kicker5.kickoutFromGroup(op.param1,[op.param2])
                                Kicker6.kickoutFromGroup(op.param1,[op.param2])
                                Kicker7.kickoutFromGroup(op.param1,[op.param2])
                                Kicker8.kickoutFromGroup(op.param1,[op.param2])
                                Kicker9.kickoutFromGroup(op.param1,[op.param2])
                            client.sendMessage(op.param1, "3回連続で退会させたことを検知しました。")
                            print("3回連続でキックしたことを検知しました。キックします。%s\n\r"%op.param2)
                            Count['kick']+=1
                            print(str(Count))
                            wait["PROTECTURLINVITECHANGE"][op.param1] = True
                            G = client.getGroup(op.param1)
                            if G.preventedJoinByTicket == False:
                                G.preventedJoinByTicket = True
                                client.updateGroup(G)
                            else:
                                pass
                            if op.param2 in wait["blacklist"]:
                                pass
                            else:
                                wait["blacklist"][op.param2] = True
                                f=codecs.open('black.json','w','utf-8')
                                json.dump(wait["blacklist"], f, sort_keys=True, indent=4,ensure_ascii=False)
                            del res['num'][op.param1]
                            del res['us'][op.param1]
                    else:
                        pass
    except Exception as e:
        print (e)

tracer.addOpInterrupt(19, N_kick)

def RECEIVE_MESSAGE(op):
    msg = op.message
    global p1
    global haveP
    m_from = msg._from
    m_to = msg.to
    try:
        if not msg.to in Messid:
            Messid[msg.to]={}
        Messid[msg.to][msg.id]=msg
        try:
            f=codecs.open('Messid.json','w','utf-8')
            json.dump(Messid, f, sort_keys=True, indent=4,ensure_ascii=False)
        except:
            pass
        if 18 == msg.contentType:
            if msg.to in AlbumP and not  check_p(msg) and not msg._from in whitelist[msg.to]:
                client.sendMessage(msg.to,"アルバムの削除は禁止されています")
                client.kickoutFromGroup(msg.to,[msg._from])
                gname = client.getGroup(op.param1).name
                name = client.getContact(op.param2).displayName
                client.sendMessage("u61999b628f0bf9d3f7b874d622d4fede","[報告]\n\nアルバム保護中にアルバムを削除したユーザーがいたため違反者を退会させました\n\n[グループ名]\n→[" + gname + "]\n\n[違反者]\n→[" + name + "]\n\n[違反者mid]\n→[" + op.param2 + "]")
        if 13 == msg.contentType:
            try:
                if msg.to in wait["rapidFire"]:
                    if msg._from in admins:
                        pass
                    elif time.time() - wait["rapidFire"][msg.to] < 3:
                        pass
                    else:
                        wait["rapidFire"][msg.to] = time.time()
                else:
                    wait["rapidFire"][msg.to] = time.time()
                if msg.to in wait['readPoint']:
                    if msg._from in wait["ROM"][msg.to]:
                        del wait["ROM"][msg.to][msg._from]
                if msg.to in offbot:
                    return
                if msg._from in wait["blacklist"]:
                    return
                elif msg.to in wait["kick"]:
                    if(msg.to in wait["wblacklist"]):
                        del wait["wblacklist"][msg.to]
                    if(msg.to in wait["wdblacklist"]):
                        del wait["wdblacklist"][msg.to]
                    if check_p(msg) or msg._from in whitelist[msg.to]:
                        target = msg.contentMetadata["mid"]
                        if check_p(msg) or (target in bots):
                            client.sendMessage(msg.to,"権限保持者なので退会させることはできません。")
                            gname = client.getGroup(op.param1).name
                            name = client.getContact(op.param2).displayName
                            client.sendMessage("u61999b628f0bf9d3f7b874d622d4fede","[報告]\n\n権限保有者を強制退会させたユーザーがいたため違反者を退会させました\n\n[グループ名]\n→[" + gname + "]\n\n[違反者]\n→[" + name + "]\n\n[違反者mid]\n→["+ op.param2 + "]")
                        else:
                            try:
                                rabdom.choice(KAC).kickoutFromGroup(msg.to,[target])
                            except:
                                try:
                                    Kicker1.kickoutFromGroup(op.param1,[op.param2])
                                    Kicker2.kickoutFromGroup(op.param1,[op.param2])
                                    Kicker3.kickoutFromGroup(op.param1,[op.param2])
                                    Kicker4.kickoutFromGroup(op.param1,[op.param2])
                                    Kicker5.kickoutFromGroup(op.param1,[op.param2])
                                    Kicker6.kickoutFromGroup(op.param1,[op.param2])
                                    Kicker7.kickoutFromGroup(op.param1,[op.param2])
                                    Kicker8.kickoutFromGroup(op.param1,[op.param2])
                                    Kicker9.kickoutFromGroup(op.param1,[op.param2])
                                except:
                                    pass
                        del wait["kick"][msg.to]
                    else:
                        pass
                elif msg.to in wait["wblacklist"]:
                    if(msg.to in wait["wdblacklist"]):
                        del wait["wdblacklist"][msg.to]
                    if(msg.to in wait["kick"]):
                        del wait["kick"][msg.to]
                    if check_p(msg):
                        target = msg.contentMetadata["mid"]
                        if (target in haveP) or (target in bots):
                            client.sendMessage(msg.to,"ブラックリストに追加できないユーザーです。")
                            del wait["wblacklist"][msg.to]
                        else:
                            if target in wait["blacklist"]:
                                client.sendMessage(msg.to,"既にブラックリストに登録されています。")
                                del wait["wblacklist"][msg.to]
                            else:
                                wait["blacklist"][target] = True
                                client.sendMessage(msg.to,"ブラックリストに追加しました。")
                                del wait["wblacklist"][msg.to]
                                wait["blacklist"][target] = True
                                f=codecs.open('black.json','w','utf-8')
                                json.dump(wait["blacklist"], f, sort_keys=True, indent=4,ensure_ascii=False)
                    else:
                        client.sendMessage(msg.to,"あなたには権限がありません。")
                elif msg.to in wait["wdblacklist"]:
                    if(msg.to in wait["wblacklist"]):
                        del wait["wblacklist"][msg.to]
                    if(msg.to in wait["kick"]):
                        del wait["kick"][msg.to]
                    if check_p(msg):
                        target = msg.contentMetadata["mid"]
                        if(target in wait["blacklist"]):
                            del wait["blacklist"][target]
                            client.sendMessage(msg.to,"ブラックリストから削除しました。")
                            f=codecs.open('black.json','w','utf-8')
                            json.dump(wait["blacklist"], f, sort_keys=True, indent=4,ensure_ascii=False)
                        else:
                            client.sendMessage(msg.to,"ブラックリストに登録されていません。")
                    else:
                        client.sendMessage(msg.to,"あなたには権限がありません。")
                    del wait["wdblacklist"][msg.to]
                elif msg.to in wait["wwhitelist"]:
                    if(msg.to in wait["wdwhitelist"]):
                        del wait["wdwhitelist"][msg.to]
                    if(msg.to in wait["kick"]):
                        del wait["kick"][msg.to]
                    if check_p(msg):
                        target = msg.contentMetadata["mid"]
                        if (target in haveP) or (target in bots):
                            client.sendMessage(msg.to,"権限者はホワイトリストに登録できません。")
                            del wait["wwhitelist"][msg.to]
                        else:
                            if target in whitelist[msg.to]:
                                client.sendMessage(msg.to,"既にホワイトリストに登録されています。")
                                del wait["wwhitelist"][msg.to]
                            else:
                                whitelist[msg.to].append(target)
                                client.sendMessage(msg.to,"ホワイトリストに追加しました。")
                                del wait["wwhitelist"][msg.to]
                                f=codecs.open('whitelist.json','w','utf-8')
                                json.dump(whitelist, f, sort_keys=True, indent=4,ensure_ascii=False)
                    else:
                        client.sendMessage(msg.to,"あなたには権限がありません。")
                elif msg.to in wait["wdwhitelist"]:
                    if(msg.to in wait["wwhitelist"]):
                        del wait["wwhitelist"][msg.to]
                    if(msg.to in wait["kick"]):
                        del wait["kick"][msg.to]
                    if check_p(msg):
                        target = msg.contentMetadata["mid"]
                        if(target in whitelist[msg.to]):
                            whitelist[msg.to].remove(target)
                            client.sendMessage(msg.to,"ホワイトリストから削除しました。")
                            f=codecs.open('whitelist.json','w','utf-8')
                            json.dump(whitelist, f, sort_keys=True, indent=4,ensure_ascii=False)
                        else:
                            client.sendMessage(msg.to,"ホワイトリストに登録されていません。")
                    else:
                        client.sendMessage(msg.to,"あなたには権限がありません。")
                    del wait["wdwhitelist"][msg.to]
                elif 'displayName' in msg.contentMetadata:
                    contact = client.getContact(msg.contentMetadata["mid"])
                    if(msg.contentMetadata["mid"] in wait["blacklist"]):
                        bll = "True"
                    else:
                        bll = "False"
                    client.sendMessage(msg.to, "[displayName]:\n" + msg.contentMetadata["displayName"] + "\n[mid]:\n" + msg.contentMetadata["mid"] + "\n[statusMessage]:\n" + contact.statusMessage + "\n[pictureStatus]:\nhttp://dl.profile.line-cdn.net/" + contact.pictureStatus +"\n[ブラックリスト]:\n" + bll)
                else:
                    if(msg.contentMetadata["mid"] in wait["blacklist"]):
                        bll = "True"
                    else:
                        bll = "False"
                    contact = client.getContact(msg.contentMetadata["mid"])
                    client.sendMessage(msg.to, "[displayName]:\n" + contact.displayName + "\n[mid]:\n" + msg.contentMetadata["mid"] + "\n[statusMessage]:\n" + contact.statusMessage + "\n[pictureStatus]:\nhttp://dl.profile.line-cdn.net/" + contact.pictureStatus + "\n[ブラックリスト]:\n" + bll)
            except:
                client.sendMessage(msg.to,"ユーザーが存在しませんでした。")

        elif 16 == msg.contentType:
            if msg.to in wait["rapidFire"]:
                if msg._from in admins:
                    pass
                elif time.time() - wait["rapidFire"][msg.to] < 3:
                    return
                else:
                    wait["rapidFire"][msg.to] = time.time()
            else:
                wait["rapidFire"][msg.to] = time.time()
            if msg.to in wait['readPoint']:
                if msg._from in wait["ROM"][msg.to]:
                    del wait["ROM"][msg.to][msg._from]
            if msg.to in offbot:
                return
            if msg._from in wait["blacklist"]:
                return
            elif 'text' not in msg.contentMetadata:
                if 'mediaOid' in msg.contentMetadata:
                    Object = msg.contentMetadata['mediaOid'].replace("svc=myhome|sid=h|","")
                    if msg.contentMetadata['mediaType'] == 'V':
                        if msg.contentMetadata['serviceType'] == 'GB':
                            client.sendMessage(msg.to, client.getContact(msg._from).displayName + "さんがノートに投稿しました！\n\n[postURL]\n" + msg.contentMetadata['postEndUrl'] + "\n[ObjectURL]\nhttps://obs-us.line-apps.com/myhome/h/download.nhn?tid=612w&oid=" + msg.contentMetadata['mediaOid'] + "\n[MediaURL]\nhttps://obs-us.line-apps.com/myhome/h/download.nhn?oid=" + msg.contentMetadata['mediaOid'])
                        else:
                            client.sendMessage(msg.to, client.getContact(msg._from).displayName + "さんが" + msg.contentMetadata['serviceName'] + "さんの投稿を共有しました！\n\n[postURL]\n" + msg.contentMetadata['postEndUrl'] + "\n[ObjectURL]\nhttps://obs-us.line-apps.com/myhome/h/download.nhn?tid=612w&" + Object + "\n[MediaURL]\nhttps://obs-us.line-apps.com/myhome/h/download.nhn?" + Object)
                    else:
                        if msg.contentMetadata['serviceType'] == 'GB':
                            client.sendMessage(msg.to, client.getContact(msg._from).displayName + "さんがノートに投稿しました！\n\n[postURL]\n" + msg.contentMetadata['postEndUrl'] + "\n[ObjectURL]\nhttps://obs-us.line-apps.com/myhome/h/download.nhn?oid=" + msg.contentMetadata['mediaOid'])
                        else:
                            client.sendMessage(msg.to, client.getContact(msg._from).displayName + "さんが" + msg.contentMetadata['serviceName'] + "さんの投稿を共有しました！\n\n[postURL]\n" + msg.contentMetadata['postEndUrl'] + "\n[ObjectURL]\nhttps://obs-us.line-apps.com/myhome/h/download.nhn?" + Object)
                elif 'stickerId' in msg.contentMetadata:
                    if msg.contentMetadata['serviceType'] == 'GB':
                        client.sendMessage(msg.to, client.getContact(msg._from).displayName + "さんがノートに投稿しました！\n\n[postURL]\n" + msg.contentMetadata['postEndUrl'] + "\n[Package]\nhttp://line.me/R/shop/detail/" + msg.contentMetadata['packageId'])
                    else:
                        client.sendMessage(msg.to, client.getContact(msg._from).displayName + "さんが" + msg.contentMetadata['serviceName'] + "さんの投稿を共有しました！\n\n[postURL]\n" + msg.contentMetadata['postEndUrl'] + "\n[Package]\nhttp://line.me/R/shop/detail/" + msg.contentMetadata['packageId'])
                else:
                    if msg.contentMetadata['serviceType'] == 'GB':
                        client.sendMessage(msg.to, client.getContact(msg._from).displayName + "さんがノートに投稿しました！\n\n[postURL]\n" + msg.contentMetadata['postEndUrl'])
                    else:
                        client.sendMessage(msg.to, client.getContact(msg._from).displayName + "さんが" + msg.contentMetadata['serviceName'] + "さんの投稿を共有しました！\n\n[postURL]\n" + msg.contentMetadata['postEndUrl'])
            else:
                if 'mediaOid' in msg.contentMetadata:
                    Object = msg.contentMetadata['mediaOid'].replace("svc=myhome|sid=h|","")
                    if msg.contentMetadata['mediaType'] == 'V':
                       if msg.contentMetadata['serviceType'] == 'GB':
                            client.sendMessage(msg.to, client.getContact(msg._from).displayName + "さんがノートに投稿しました！\n\n[postURL]\n" + msg.contentMetadata['postEndUrl'] + "\n[text]\n" + msg.contentMetadata['text'] + "\n[ObjectURL]\nhttps://obs-us.line-apps.com/myhome/h/download.nhn?tid=612w&oid=" + msg.contentMetadata['mediaOid'] + "\n[MediaURL]\nhttps://obs-us.line-apps.com/myhome/h/download.nhn?oid=" + msg.contentMetadata['mediaOid'])
                       else:
                            client.sendMessage(msg.to, client.getContact(msg._from).displayName + "さんが" + msg.contentMetadata['serviceName'] + "さんの投稿を共有しました！\n\n[postURL]\n" + msg.contentMetadata['postEndUrl'] + "\n[text]\n" + msg.contentMetadata['text'] + "\n[ObjectURL]\nhttps://obs-us.line-apps.com/myhome/h/download.nhn?tid=612w&" + Object + "\n[MediaURL]\nhttps://obs-us.line-apps.com/myhome/h/download.nhn?" + Object)
                    else:
                        if msg.contentMetadata['serviceType'] == 'GB':
                            client.sendMessage(msg.to, client.getContact(msg._from).displayName + "さんがノートに投稿しました！\n\n[postURL]\n" + msg.contentMetadata['postEndUrl']+ "\n[text]\n" + msg.contentMetadata['text'] + "\n[ObjectURL]\nhttps://obs-us.line-apps.com/myhome/h/download.nhn?oid=" + msg.contentMetadata['mediaOid'])
                        else:
                            client.sendMessage(msg.to, client.getContact(msg._from).displayName + "さんが" + msg.contentMetadata['serviceName'] + "さんの投稿を共有しました！\n\n[postURL]\n" + msg.contentMetadata['postEndUrl']+ "\n[text]\n" + msg.contentMetadata['text'] + "\n[ObjectURL]\nhttps://obs-us.line-apps.com/myhome/h/download.nhn?" + Object)
                elif 'stickerId' in msg.contentMetadata:
                    if msg.contentMetadata['serviceType'] == 'GB':
                        client.sendMessage(msg.to, client.getContact(msg._from).displayName + "さんがノートに投稿しました！\n\n[postURL]\n" + msg.contentMetadata['postEndUrl'] + "\n[text]\n" + msg.contentMetadata['text'] + "\n[Package]\nhttp://line.me/R/shop/detail/" + msg.contentMetadata['packageId'])
                    else:
                        client.sendMessage(msg.to, client.getContact(msg._from).displayName + "さんが" + msg.contentMetadata['serviceName'] + "さんの投稿を共有しました！\n\n[postURL]\n" + msg.contentMetadata['postEndUrl'] + "\n[text]\n" + msg.contentMetadata['text'] + "\n[Package]\nhttp://line.me/R/shop/detail/" + msg.contentMetadata['packageId'])
                else:
                    if msg.contentMetadata['serviceType'] == 'GB':
                        client.sendMessage(msg.to, client.getContact(msg._from).displayName + "さんがノートに投稿しました！\n\n[postURL]\n" + msg.contentMetadata['postEndUrl'] + "\n[text]\n" + msg.contentMetadata['text'])
                    else:
                        client.sendMessage(msg.to, client.getContact(msg._from).displayName + "さんが" + msg.contentMetadata['serviceName'] + "さんの投稿を共有しました！\n\n[postURL]\n" + msg.contentMetadata['postEndUrl'] + "\n[text]\n" + msg.contentMetadata['text'])

        elif 0 == msg.contentType:
            if msg.to in wait["rapidFire"]:
                if msg._from in admins:
                    pass
                elif time.time() - wait["rapidFire"][msg.to] < 3:
                    return
                else:
                    wait["rapidFire"][msg.to] = time.time()
            else:
                wait["rapidFire"][msg.to] = time.time()
            if msg._from in wait["blacklist"]:
                return
            if msg.to in wait['readPoint']:
                if msg._from in wait["ROM"][msg.to]:
                    del wait["ROM"][msg.to][msg._from]
                    ##print "送信されたのでROM削除->" + msg._from
            if cms(msg.text, ["sleep"]):
                if msg.to not in offbot:
                    client.sendMessage(msg.to, "ミュートにしました。コマンドに反応しません。")
                    offbot.append(msg.to)
                else:
                   client.sendMessage(msg.to, "すでにミュートです。")
            elif cms(msg.text, ["get up"]):
                if msg.to in offbot:
                    client.sendMessage(msg.to, "ミュートを解除し、コマンドに反応するようになりました。")
                    offbot.remove(msg.to)
                else:
                    client.sendMessage(msg.to, "コマンドに反応します。")
            if msg.to in offbot:
                return
            elif cmd(msg.text, ["Y","y","いーよ","おk","N","やだ","n","だめ"]):
                if msg._from == wait['bye'][msg.to]:
                    if cmd(msg.text, ["Y","いいよ","y","おk","いーよ"]):
                       client.sendMessage(msg.to, "退会します。")
                       client.leaveGroup(msg.to)
                       Kicker1.leaveGroup(msg.to)
                       Kicker2.leaveGroup(msg.to)
                       Kicker3.leaveGroup(msg.to)
                       Kicker4.leaveGroup(msg.to)
                       Kicker5.leaveGroup(msg.to)
                       Kicker6.leaveGroup(msg.to)
                       Kicker7.leaveGroup(msg.to)
                       Kicker8.leaveGroup(msg.to)
                       Kicker9.leaveGroup(msg.to)
                       del wait['bye'][msg.to]
                    elif cmd(msg.text, ["N","n","だめ","やだ"]):
                        client.sendMessage(msg.to, "退会をキャンセルします。")
                        del wait['bye'][msg.to]
                else:
                    pass
            elif cms(msg.text,["グループ登録"]):
                if not msg.to in adminG and msg._from in admins:
                    try:
                        adminG.append(msg.to)
                        f = open("adminG.txt", 'w')
                        for x in adminG:
                            f.write(str(x) + "\n")
                        f.close()
                        client.sendMessage(msg.to,"完了")
                    except:
                        client.sendMessage(msg.to,"ERROR")
                else:
                    client.sendMessage(msg.to,"既に登録されているか、権限が足りません。")
            elif "/全グル送信:" in msg.text:
               if msg._from in admins:
                       string = msg.text.replace("/全グル送信:", "")
                       gru=client.getGroupIdsJoined()
                       for gid in gru:
                        client.sendMessage(gid, string)
                        time.sleep(0.2)
            elif cmi(msg.text,["名前変更"]):
                if msg._from in admins:
                    mg = msg.text.replace("/名前変更 ","")
                    if "/client名前変更" in mg:
                        cont = client
                        ms = mg.replace("/client名前変更 ","")
                    elif "/kicker1名前変更" in mg:
                        cont = Kicker1
                        ms = mg.replace("/kicker1名前変更 ","")
                    elif "/kicker2名前変更" in mg:
                        cont = Kicker2
                        ms = mg.replace("/kicker2名前変更 ","")
                    elif "/kicker3名前変更" in mg:
                        cont = Kicker3
                        ms = mg.replace("/kicker3名前変更 ","")
                    elif "/kicker4名前変更" in mg:
                        cont = Kicker4
                        ms = mg.replace("/kicker4名前変更 ","")
                    elif "/kicker5名前変更" in mg:
                        cont = Kicker5
                        ms = mg.replace("/kicker5名前変更 ","")
                    elif "/kicker6名前変更" in mg:
                        cont = Kicker6
                        ms = mg.replace("/kicker6名前変更 ","")
                    elif "/kicker7名前変更" in mg:
                        cont = Kicker7
                        ms = mg.replace("/kicker7名前変更 ","")
                    elif "/kicker8名前変更" in mg:
                        cont = Kicker8
                        ms = mg.replace("/kicker8名前変更 ","")
                    elif "/kicker9名前変更" in mg:
                        cont = Kicker9
                        ms = mg.replace("/kicker9名前変更 ","")                    
                    else:
                        return
                    profile = cont.getProfile()
                    profile.displayName = ms
                    cont.updateProfile(profile)
                    cont.sendMessage(msg.to,"変更完了")
            elif cmi(msg.text,["debug"]):
                if cmd(msg.text[-4:],["-権限者"]):
                    if msg._from in admins:
                        client.sendMessage(msg.to,str(haveP))
            elif cmi(msg.text, ["解析"]):
                if cmd(msg.text[-2:], ["-a","-A"]):
                    if msg._from in admins:
                        All = client.getGroupIdsJoined()
                        MemIn,MemInv = 0, 0
                        for var in range(0, len(All)):
                            try:
                                Gid = random.choice(All)
                                All.remove(Gid)
                                group = client.getGroup(Gid)
                                MemIn = (MemIn) + (len(group.members))
                                if group.invitee is not None:
                                    MemInv = MemInv + (len(group.invitee))
                                else:
                                    pass
                            except:
                                pass
                        client.sendMessage(msg.to, client.getProfile().displayName + "が現在参加しているグループ数: " + str(len(client.getGroupIdsJoined())) + "\n招待されているグループ数: " + str(len(client.getGroupIdsInvited())) + "\n参加中のグループにいるメンバーは総計" + str(MemIn) + "人\n招待中の人数は" + str(MemInv) + "人です。")
                        client.sendMessage(msg.to, client.getProfile().displayName + "は\nkick:" + str(Count['kick']) + "回\ncancel:" + str(Count['cancel']) + "回\n招待:" + str(Count['invite']) + "回\nしています。")
                elif cmd(msg.text[-2:],["-w"]):
                    if msg._from in admins:
                        All = client.getGroupIdsJoined()
                        for id in All:
                            try:
                                whitelist[id] = []
                            except:
                                pass
                        f=codecs.open('whitelist.json','w','utf-8')
                        json.dump(whitelist, f, sort_keys=True, indent=4,ensure_ascii=False)
                        client.sendMessage(msg.to,"完了")
                elif cmd(msg.text[-2:],["-l"]):
                    if msg._from in admins:
                        temp1 = []
                        p1 = temp1
                        p1 = []
                        p1 = list(set(temp1))
                        temp1 = []
                        haveP = temp1
                        haveP = []
                        haveP = list(set(temp1))
                        f = open('p1.txt', 'w')
                        for x in p1:
                            f.write(str(x) + "\n")
                        f.close()
                        client.sendMessage(msg.to,"完了")
                elif cmd(msg.text[-2:],["-j"]):
                    if msg._from in admins:
                        gid = client.getGroupIdsJoined()
                        g = {}
                        for i in gid:
                            group = client.getGroup(i)
                            client.sendMessage(msg.to,"現在" + group.name + "を、解析中です。")
                            gMembMids = [contact.mid for contact in group.members]
                            matched_list = []
                            for tag in list(p1):
                                matched_list += filter(lambda str: str == tag, gMembMids)
                            g[group.name]=[]
                            for nh in matched_list:
                                tp=client.getContact(nh)
                                g[group.name].append(tp.displayName)
                        f=codecs.open('p1list.json','w','utf-8')
                        json.dump(g, f, sort_keys=True, indent=4,ensure_ascii=False)
                        client.sendMessage(msg.to, "終了")
                else:
                    pass        
            elif cms(msg.text, ["シャットダウン@"]):
                if msg._from in admins:
                    f=codecs.open('black.json','w','utf-8')
                    json.dump(wait["blacklist"], f, sort_keys=True, indent=4,ensure_ascii=False)
                    client.sendMessage(msg.to, "設定ファイルを保存しました")
                    client.sendMessage(msg.to, "保護システムをシャットダウンします")
                    sys.exit(0)
                else:
                    client.sendMessage(msg.to, "申し訳ございません。あなたは権限を所持していないので、命令を実行することができません。")
            elif cms(msg.text, ["restart@"]):
                if msg._from in admins:
                    client.sendMessage(msg.to, "restart now…")
                    time.sleep(5)
                    client.sendMessage(msg.to, "restart ok")
                    restartBot()        
                    f=codecs.open('black.json','w','utf-8')
                    json.dump(wait["blacklist"], f, sort_keys=True, indent=4,ensure_ascii=False)
                    client.sendMessage(msg.to, "再起動中...")
                    time.sleep(5)
                    client.sendMessage(msg.to, "再起動しました")
                    restartBot()
                   # client.sendMessage(msg.to, "再起動は現在動作しません")        
            elif cms(msg.text,["save"]):
                if msg._from in admins:
                    f=codecs.open('whitelist.json','w','utf-8')
                    json.dump(whitelist, f, sort_keys=True, indent=4,ensure_ascii=False)
                    f=codecs.open('black.json','w','utf-8')
                    json.dump(wait["blacklist"], f, sort_keys=True, indent=4,ensure_ascii=False)
                    f=codecs.open('protect.json','w','utf-8')
                    json.dump(wait["protect"], f, sort_keys=True, indent=4,ensure_ascii=False)
                    f=codecs.open('PROTECTKICK.json','w','utf-8')
                    json.dump(wait["PROTECTKICK"], f, sort_keys=True, indent=4,ensure_ascii=False)
                    f=codecs.open('PROTECTURLINVITECHANGE.json','w','utf-8')
                    json.dump(wait["PROTECTURLINVITECHANGE"], f, sort_keys=True, indent=4,ensure_ascii=False)
                    client.sendMessage(msg.to, "設定ファイルの保存が完了しました")
                else:
                    client.sendMessage(msg.to, "申し訳ございません。あなたは権限を所持していないためコマンドを実行できません。")
            elif cms(msg.text, ["退会"]):
                if check_p(msg):
                    client.sendMessage(msg.to, "このグループから退会\n(y/n)")
                    wait['bye'][msg.to] = msg._from
                    ##print wait
                else:
                    client.sendMessage(msg.to,"申し訳ございません。あなたは権限を所持していないので、命令を実行することができません。")
            elif cms(msg.text, ["既読ポイント設定"]):
                client.sendMessage(msg.to, "既読ポイントを設定しました。\n確認したい場合は「既読確認」と送信してください。")
                try:
                    del wait['readPoint'][msg.to]
                    del wait['readMember'][msg.to]
                except:
                    pass
                wait['readPoint'][msg.to] = msg.id
                wait['readMember'][msg.to] = ""
                wait['setTime'][msg.to] = datetime.today().strftime('%Y-%m-%d %H:%M:%S')
                wait['ROM'][msg.to] = {}
                ##print wait

            elif cms(msg.text, ["既読確認"]):
                if msg.to in wait['readPoint']:
                    if wait["ROM"][msg.to].items() == []:
                        chiya = ""
                    else:
                        chiya = ""
                        for rom in wait["ROM"][msg.to].items():
                            ##print rom
                            chiya += rom[1] + "\n"

                    client.sendMessage(msg.to, "既読を付けた人は%s\nです！\n\n既読無視している人は\n%sです！\n\n既読ポイント作成日時:\n[%s]\n\n\n既読無視している人とは、既読ポイント作成時以降、既読しているのにも関わらず一度も発言していない人を表示しています。" % (wait['readMember'][msg.to],chiya,setTime[msg.to]))
                else:
                    client.sendMessage(msg.to, "既読ポイントが設定されていません。\n「既読ポイント設定」と送信していただければ既読ポイントが作成されます。")

            elif cms(msg.text,["ブラックリスト追加"]):
                if check_p(msg):
                    client.sendMessage(msg.to,"ブラックリストに追加する連絡先を送信してください。")
                    wait["wblacklist"][msg.to] = True
                else:
                    client.sendMessage(msg.to,"あなたには権限がありません。")
            elif cms(msg.text,["ブラックリスト削除"]):
                if msg._from in admins:
                    client.sendMessage(msg.to,"ブラックリストから削除する連絡先を送信してください。")
                    wait["wdblacklist"][msg.to] = True
                else:
                    client.sendMessage(msg.to,"あなたには権限がありません。")
            elif cms(msg.text,["メンバーチェック"]):
                group = client.getGroup(msg.to)
                gMembMids = [contact.mid for contact in group.members]
                matched_list = []
                for tag in wait["blacklist"]:
                    matched_list+=filter(lambda str: str == tag, gMembMids)
                cocoa = ""
                for mm in matched_list:
                    try:
                        cocoa += client.getContact(mm).displayName + "\n"
                    except Exception as error:
                        try:
                            client.sendMessage(msg.to,str(error))
                        except:
                            pass
                if cocoa == "":
                    client.sendMessage(msg.to,"ブラックリストに入っているユーザーはいません。")
                else:
                    client.sendMessage(msg.to,cocoa + "がブラックリストです。")
            elif cms(msg.text, ["mid"]):
                client.sendMessage(msg.to, msg._from)
            elif cmi(msg.text,["mmid:"]):
                client.sendContact(msg.to,msg.text[6:])
            elif cms(msg.text, ["gid"]):
                client.sendMessage(msg.to, msg.to)
            elif cms(msg.text, ["招待保護"]):
                if check_p(msg):
                    if not msg.to in wait['protect']:
                        client.sendMessage(msg.to, "招待保護をオンにしたため注意してください。")
                        wait['protect'][msg.to] = msg._from
                        f=codecs.open('protect.json','w','utf-8')
                        json.dump(wait["protect"], f, sort_keys=True, indent=4,ensure_ascii=False)
                    else:
                        client.sendMessage(msg.to,"すでに招待保護はオンです。")
                else:
                    name = client.getContact(msg._from).displayName
                    client.sendMessage(msg.to, "ごめんなさい、" + name + "さんには実行する権限がありません。")
            elif cms(msg.text, ["招待保護オフ"]):
                if check_p(msg):
                    if msg.to in wait['protect']:
                        client.sendMessage(msg.to, "招待保護を解除しました。")
                        del wait['protect'][msg.to]
                        f=codecs.open('protect.json','w','utf-8')
                        json.dump(wait["protect"], f, sort_keys=True, indent=4,ensure_ascii=False)
                    else:
                        client.sendMessage(msg.to,"招待保護はオンになってないよ！")
                else:
                    name = client.getContact(msg._from).displayName
                    client.sendMessage(msg.to, "ごめんなさい、" + name + "さんには実行する権限がありません。")
            elif cms(msg.text, ["cancel","キャンセル"]):
                group = client.getGroup(msg.to)
                if group.invitee is None:
                    client.sendMessage(op.message.to, "招待中の人はいません。")
                else:
                    gInviMids = [contact.mid for contact in group.invitee]
                    print("単キャンセルが実行されました。%s人キャンセルしました。\n\r",len(group.invitee))
                    client.cancelGroupInvitation(msg.to, gInviMids)
                    client.sendMessage(msg.to, str(len(group.invitee)) + "人の招待をキャンセルしました。")
            elif cms(msg.text, ["group"]):
                try:
                    group = client.getGroup(msg.to)
                    md = "[グループ名]: " + group.name + "\n\n[gid]: " + group.id + "\n\n[アイコン画像]: \nhttp://dl.profile.line-cdn.net/" + group.pictureStatus
                    if group.preventedJoinByTicket is False: md += "\n\n招待URL: 許可中です\n"
                    else: md += "\n\n招待URL: 拒否中です\n"

                    if group.invitee is None: md += "\nメンバー数: " + str(len(group.members)) + "人\n招待中: 0人"
                    else: md += "\nメンバー数: " + str(len(group.members)) + "人\n招待中: " + str(len(group.invitee)) + "人"

                    md += "\n\nグループ作製者名:" + group.creator.displayName

                    if msg.to in wait["protect"]: md += "\n\n保護: オン"
                    else: md += "\n\n保護: オフ"

                    if msg.to in wait["PROTECTURLINVITECHANGE"]: md += "\n\n保護 URL: オン"
                    else: md += "\n\n保護 URL: オフ"

                    if msg.to in wait["groupPicture"]: md += "\n\n保護 グル画: オン"
                    else: md += "\n\n保護 グル画: オフ"

                    if msg.to in wait["PROTECTGNAMECHANGE"]: md += "\n\n保護 グループ名: オン"
                    else: md += "\n\n保護 グループ名: オフ"

                    if msg.to in wait["PROTECTKICK"]: md += "\n\n保護 蹴り: オン"
                    else: md += "\n\n保護 蹴り: オフ"

                    if msg.to in Cancelbot: md+="\n\n保護 参加: オン"
                    else:md += "\n\n保護参加: オフ"

                    if msg.to in ReMess: md+="\n\n送信取り消し復元: オン"
                    else: md+="\n\n送信取り消し復元: オフ"

                    if msg.to in JoinG: md+="\n\n参加時挨拶: オン \n[挨拶]" + str(JoinG[msg.to])
                    else: md+="\n\n参加時挨拶: オフ"
 
                    client.sendMessage(msg.to, md)
                except:
                    client.sendMessage(msg.to,"ERROR:getGroupに失敗しました。")
                    if msg.to in wait["protect"]: md = "\n\n保護: オン"
                    else: md = "\n\n;保護: オフ"

                    if msg.to in wait["PROTECTURLINVITECHANGE"]: md += "\n\n保護 URL: オン"
                    else: md += "\n\n保護 URL: オフ"

                    if msg.to in wait["PROTECTGNAMECHANGE"]: md += "\n\n保護 グループ名: オン"
                    else: md += "\n\n保護 グループ名: オフ"

                    if msg.to in wait["PROTECTKICK"]: md += "\n\n保護 蹴り: オン"
                    else: md += "\n\n保護 蹴り: オフ"

                    if msg.to in Cancelbot: md+="\n\n保護 参加: オン"
                    else:md += "\n\n保護参加: オフ"

                    if msg.to in AlbumP: md+="\n\n保護 アルバム: オン"
                    else:md += "\n\n保護 アルバム:オフ"

                    if msg.to in ReMess: md+="\n\n送信取り消し復元: オン"
                    else: md+="\n\n送信取り消し復元: オフ"

                    if msg.to in JoinG: md+="\n\n参加時挨拶: オン \n[挨拶]" + str(JoinG[msg.to])
                    else: md+="\n\n参加時挨拶: オフ"

                    client.sendMessage(msg.to, md)
            elif cms(msg.text, ["USER","user","User","ユーザー"]):
                try:
                    contact = client.getContact(msg._from)
                    client.sendMessage(msg.to, "[displayName]:\n" + contact.displayName + "\n[mid]:\n" + msg._from + "\n[statusMessage]:\n" + contact.statusMessage + "\n[pictureStatus]:\nhttp://dl.profile.line-cdn.net/" + contact.pictureStatus)
                except:
                    client.sendMessage(msg.to,"残念ですが、エラーが発生しました。")
            elif cms(msg.text, ["me"]):
                client.sendContact(msg.to,msg._from)
            elif cms(msg.text, ["動いてる？"]):
                name = client.getContact(msg._from).displayName
                client.sendMessage(msg.to,"｢" + name + "｣様\n現在動作中です")
            elif cms(msg.text, ["ちんちん"]):
                name = client.getContact(msg._from).displayName
                client.sendMessage(msg.to,"" + name + "はちんちん")
            elif cms(msg.text, ["パチリス"]):
                client.sendMessage(msg.to,"天才") 
            elif cms(msg.text, ["グル主"]):
                group = client.getGroup(msg.to)
                client.sendContact(msg.to,group.creator.mid)
            elif cms(msg.text, ["招待URL許可"]):
                group = client.getGroup(msg.to)
                if group.preventedJoinByTicket == False:
                    client.sendMessage(msg.to, "既に許可されています。")
                else:
                    if msg.to in wait["PROTECTURLINVITECHANGE"]:
                        client.sendMessage(msg.to, "招待URLの設定変更が禁止されているので作成できません。\n保護 URL オフを実行してください。")
                    else:
                        group.preventedJoinByTicket = False
                        client.updateGroup(group)
                        client.sendMessage(msg.to, "URL招待を許可しました。")
            elif cms(msg.text, ["招待URL拒否"]):
                group = client.getGroup(msg.to)
                if group.preventedJoinByTicket == True:
                    client.sendMessage(msg.to, "既に拒否されています")
                else:
                    group.preventedJoinByTicket = True
                    client.updateGroup(group)
                    client.sendMessage(msg.to, "URL招待を拒否しました")
            elif cms(msg.text, ["time","タイム","現在時刻","なう"]):
                client.sendMessage(msg.to, "現在時刻は" + datetime.today().strftime('%Y年%m月%d日 %H:%M:%S:%f') + "です。")
            elif cms(msg.text, ["招待URL生成"]):
                if msg.to in wait["PROTECTURLINVITECHANGE"]:
                    client.sendMessage(msg.to, "招待URLの設定変更が禁止されているので作成できません。\n保護URLオフを実行してください。")
                else:
                    client.sendMessage(msg.to,"\nline://ti/g/" + client.reissueGroupTicket(msg.to))
            elif cms(msg.text, ["保護名前"]):
                if msg.to in wait["PROTECTGNAMECHANGE"]:
                    client.sendMessage(msg.to, "すでにグループ名の変更は禁止されています。")
                else:
                    wait["PROTECTGNAMECHANGE"][msg.to] = client.getGroup(msg.to).name
                    f=codecs.open('PROTECTGNAMECHANGE.json','w','utf-8')
                    json.dump(wait["PROTECTGNAMECHANGE"], f, sort_keys=True, indent=4,ensure_ascii=False)
                    ##print wait
                    client.sendMessage(msg.to, "グループ名の変更を禁止しました。")
            elif cms(msg.text, ["保護名前オフ"]):
                if check_p(msg) or msg._from in whitelist[msg.to]:
                    if msg.to in wait["PROTECTGNAMECHANGE"]:
                        del wait["PROTECTGNAMECHANGE"][msg.to]
                        f=codecs.open('PROTECTGNAMECHANGE.json','w','utf-8')
                        json.dump(wait["PROTECTGNAMECHANGE"], f, sort_keys=True, indent=4,ensure_ascii=False)
                        # wait
                        client.sendMessage(msg.to, "グループ名の変更を許可しました。")
                    else:
                        client.sendMessage(msg.to, "すでにグループ名の変更は許可されています。")
                else:
                    name = client.getContact(msg._from).displayName
                    client.sendMessage(msg.to, "ごめんなさい、" + name + "さんには実行する権限がありません。")
            elif cms(msg.text, ["保護URL"]):
                if msg.to in wait["PROTECTURLINVITECHANGE"]:
                    client.sendMessage(msg.to, "すでにURL招待設定の変更は禁止されています。")
                else:
                    wait["PROTECTURLINVITECHANGE"][msg.to] = True
                    ##print wait
                    G =client.getGroup(msg.to)
                    G.preventedJoinByTicket = True
                    client.updateGroup(G)
                    client.sendMessage(msg.to, "URL招待設定の変更を禁止しました。")
                    f=codecs.open('PROTECTURLINVITECHANGE.json','w','utf-8')
                    json.dump(wait["PROTECTURLINVITECHANGE"], f, sort_keys=True, indent=4,ensure_ascii=False)
            elif cms(msg.text, ["保護URLオフ"]):
                if check_p(msg):
                    if msg.to in wait["PROTECTURLINVITECHANGE"]:
                        del wait["PROTECTURLINVITECHANGE"][msg.to]
                        ##print wait
                        client.sendMessage(msg.to, "URL招待設定の変更を許可しました。")
                        f=codecs.open('PROTECTURLINVITECHANGE.json','w','utf-8')
                        json.dump(wait["PROTECTURLINVITECHANGE"], f, sort_keys=True, indent=4,ensure_ascii=False)
                    else:
                        client.sendMessage(msg.to, "すでにURL招待設定の変更は許可されています。")
                else:
                    name = client.getContact(msg._from).displayName
                    client.sendMessage(msg.to, "ごめんなさい、" + name + "さんには実行する権限がありません。")
            elif cms(msg.text, ["保護蹴り"]):
                if check_p(msg):
                    if not msg.to in wait["PROTECTKICK"]:
                        wait["PROTECTKICK"][msg.to] = True
                        ##print wait
                        client.sendMessage(msg.to, "強制退会を禁止したため注意してください。")
                        f=codecs.open('PROTECTKICK.json','w','utf-8')
                        json.dump(wait["PROTECTKICK"], f, sort_keys=True, indent=4,ensure_ascii=False)
                    else:
                        client.sendMessage(msg.to, "すでに強制退会は禁止されています。")
                else:
                    name = client.getContact(msg._from).displayName
                    client.sendMessage(msg.to, "ごめんなさい、" + name + "さんには実行する権限がありません。")        
            elif cms(msg.text, ["helps"]):
                if check_p(msg):
                 json_ = open('help.json','r')
                 data = json.load(json_)
                 sendTemplate2(msg.to,data)

            elif cms(msg.text, ["help"]):
                if check_p(msg):
                    client.sendFile(msg.to,"help.txt")

            elif cms(msg.text, ["ver"]):
                if check_p(msg):
                    client.sendFile(msg.to,"ver.txt")
                    client.sendContact(msg.to,"u2e31cb44855c79fd35fd36cbc1b42d77")

            elif cms(msg.text, ["権限help"]):
                if check_p(msg):
                    client.sendFile(msg.to,"権限help.txt")

            elif cms(msg.text, ["権限helpp"]):
                if(msg._from in admins):
                    text = "ほご 最高権限者専用help\n\n" \
                       "[/権限追加 ＠]→メンション先ユーザーに権限をつけるよ！\n" \
                       "[/権限削除 ＠]→メンション先ユーザーの権限を削除するよ！\n" \
                       "[/期限設定 ＠]→期限を設定するよ！\n" \
                       "[/点呼]→クライアントとキッカーの動作を確認するよ！\n" \
                       "[/権限者確認]→権限者を確認するよ！\n" \
                       "[/ブラックリスト削除] →連絡先でブラックリストから削除するよ！\n" \
                       "[/ブラリス削除 [Name]] →指定した名前が入っているブラリスユーザーをすべて削除するよ！\n"\
                       "[/全グル参加]→現在クライアントがいるグループ全てをにキッカーを再入室させるよ！\n" \
                       "[/全招待拒否]→招待されてるグループ全てをキャンセルするよ！\n" \
                       "[/オールエンド]→現在参加しているグループ全て退会して保護システムを終了するよ！\n" \
                       "[/グループ登録]→権限者グルを登録するよ！\n" \
                       "[/全グル送信:text]→保護BOTが全グル送信するよ。\n" \
                       "[/debug -権限者]→権限者一覧をmid出だすよ！\n" \
                       "[/解析 -a]→現在参加参加しているグループなどの詳細を出すよ！\n" \
                       "[/解析 -w]→現在登録されている全ての独自ホワイトリストを確認するよ！\n" \
                       "[/解析 -j]今参加しているグループ全て出すよ！\n" \
                       "[/save]→設定を保存\n" \
                       "[/bots]→アカウント全てのmidを表示するよ！\n" \
                       "[/use]→cpuとメモリ使用率を表示\n" \
                       "[/シャットダウン]→すべてのグループの保護を終了\n" \
                       "[/restart]→保護システムを再起動します\n" 
                client.sendMessage(msg.to,text)     
            elif cms(msg.text, ["helpp"]):
                if check_p(msg):
                    text = "ほごのコマンド一覧\n" \
"送信する際[ ]は必要ありません。\n" \
"※(セミコロン)を:(コロン)に直して送信してください。\n" \
"現在のバージョンは[4.0.1]最終更新日.2019/04/4\n\n" \
"-権限者コマンド-\n" \
"[お知らせ] →お知らせがあったらだすよ\n" \
"[/test]→保護botのクライアントの動作確認をします\n" \
"[/処理速度]→保護の処理速度を表示します\n" \
"[/helpp] →コマンド表をテキスト形式で表示するよ！\n" \
"[/help] →コマンド表をファイル形式で表示するよ！\n" \
"[/ver] →アップデート内容をファイル形式で表示するよ！\n" \
"[/mid] →自分のmidを表示するよ！\n" \
"[/gid] →グループidを表示するよ！\n" \
"[/time] →現在時間を表示するよ！\n" \
"[/me] →実行ユーザーの連絡先を表示するよ！\n" \
"[/user] →実行ユーザーの詳細を表示するよ！\n" \
"[/group] →グループの詳細情報を表示するよ！\n" \
"[/グル主]→グルの作成者の連絡先を表示するよ！\n" \
"[/招待URL生成] →招待URLを生成するよ！\n" \
"[/招待URL許可] →URL参加を許可するよ！\n" \
"[/招待URL拒否] →URL参加を拒否するよ！\n" \
"[/招待保護] →グループへの招待を禁止します\n" \
"[/保護URL] →URL取得をブロックするよ！\n" \
"[/保護名前] →グループ名を固定するよ！\n" \
"[/保護画像] →グループアイコンの変更をブロックするよ！\n" \
"[/保護蹴り] →強制退会を禁止するよ！\n" \
"[/sleep] →コマンドに反応しないよ！\n" \
"[/get up] →コマンドに反応するよ！\n" \
"[/既読ポイント設定]→既読ポイントを設定するよ！\n" \
"[/既読確認]→既読者を確認するよ！\n" \
"[/mmid:]:の後にmidを入力するとその連絡先を表示するよ！\n" \
"[/MK;] →:の後にメンションしたユーザーを退会させるよ！\n" \
"[/復元オン]→ 送信取り消し内容を表示するよ！\n" \
"[/復元オフ]→ 送信取り消し内容を表示しないよ！\n" \
"[/参加挨拶オン]→ 参加時の挨拶をオンにします\n" \
"[/参加挨拶オフ]→ 参加時の挨拶をオフにします\n" \
"[/参加挨拶設定 [Mess]]→ 参加時の挨拶の変更をします\n" \
"[/退会] →保護BOTをグループから退会させるよ！\n" \
"[/キック] →連絡先をはるとそのユーザーを退会させるよ！\n" \
"[/招待保護オフ] →グループ招待を許可するよ！\n" \
"[/保護URLオフ] →URL保護をオフにするよ！\n" \
"[/保護名前オフ] →グループ名の変更を許可するよ！\n" \
"[/保護画像オフ] →グループアイコンの変更を許可するよ！\n" \
"[/保護蹴りオフ] →連続じゃない強制退会を許可するよ！\n" \
"[/保護参加] →招待後10秒以内に参加した人をけるよ！\n" \
"[/保護参加オフ] →招待による10秒以内の参加を許可するよ！\n" \
"[/保護アルバムオン]→ アルバム削除を禁止するよ！\n" \
"[/保護アルバムオフ]→ アルバム削除を許可するよ！\n" \
"[/ブラックリスト追加] →連絡先でブラリスに追加するよ！\n" \
"[/ブラックリスト追加 ＠] →メンションしたユーザーをブラリスに追加するよ！\n" \
"[/ブラックリスト確認] →ブラリスに登録されている人を全員表示します\n" \
"[/ブラリスばいばい] →ブラリスをグループからばいばいするよ！\n" \
"[/メンバーチェック] →グループ内のブラリスに登録されている人を確認するよ！\n" \
"[/ホワイトリスト追加 ＠] →メンション先ユーザーを独自ホワイトに追加するよ！\n" \
"[/ホワイトリスト削除 ＠] →メンション先ユーザーを独自ホワイトから削除するよ！\n" \
"[/ホワリス追加] →連絡先でホワイトリストに追加します\n" \
"[/ホワリス削除] →連絡先でホワイトリストから削除します\n" \
"[/ホワイトリスト確認] →独自ホワイトリストを確認するよ！\n" \
"[/ホワイトリスト初期化] →独自ホワイトリストを初期化するよ！\n" \
"[/キッカー]→不足しているキッカーを参加させるよ！\n" \
"以下のコマンドは最高権限者のみ可能です\n" \
"[/権限help] →最高権限者専用のコマンドをテキスト形式で表示するよ！\n"
                    client.sendMessage(msg.to,text)      
                    client.sendMessage(msg.to,"[お知らせ]のコマンドをついかしたよ")                       
            if "/MK:" in msg.text:
                if check_p(msg):
                    targets = []
                    key = eval(msg.contentMetadata["MENTION"])
                    key["MENTIONEES"][0]["M"]
                    for x in key["MENTIONEES"]:
                        targets.append(x["M"])
                    for target in targets:
                        try:
                         for x in KAC:
                            x.kickoutFromGroup(msg.to,[target])
                        except:
                            client.sendMessage(msg.to,"蹴り規制です。")
            elif "/ホワイトリスト追加 " in msg.text:
                if check_p(msg):
                    targets = []
                    key = eval(msg.contentMetadata["MENTION"])
                    key["MENTIONEES"][0]["M"]
                    for x in key["MENTIONEES"]:
                        if x["M"] in whitelist[msg.to]:
                             client.sendMessage(msg.to,"%sは既にホワイトリストです。"%(client.getContact(x["M"]).displayName))
                        else:
                            whitelist[msg.to].append(x["M"])
                            client.sendMessage(msg.to,"追加しました。")   
                    f=codecs.open('whitelist.json','w','utf-8')
                    json.dump(whitelist, f, sort_keys=True, indent=4,ensure_ascii=False)
                    client.sendMessage(msg.to,"完了")
                else:
                    client.sendMessage(msg.to,"あなたには実行する権限がありません。")
            elif "/ホワイトリスト削除 " in msg.text:
                if check_p(msg):
                    targets = []
                    key = eval(msg.contentMetadata["MENTION"])
                    key["MENTIONEES"][0]["M"]
                    for x in key["MENTIONEES"]:
                        if x["M"] in whitelist[msg.to]:
                            whitelist[msg.to].remove(x["M"])
                            client.sendMessage(msg.to,"削除しました。")
                        else:
                            client.sendMessage(msg.to,"%sはホワイトリストユーザーではありません。"%(client.getContact(x["M"]).displayName))
                    f=codecs.open('whitelist.json','w','utf-8')
                    json.dump(whitelist, f, sort_keys=True, indent=4,ensure_ascii=False)
                    client.sendMessage(msg.to,"完了")
                else:
                    client.sendMessage(msg.to,"あなたには実行する権限がありません。")
            elif cms(msg.text,["ホワリス追加"]):
                if check_p(msg):
                    client.sendMessage(msg.to,"ホワイトリストから追加する連絡先を送信してください。")
                    wait["wwhitelist"][msg.to] = False
                else:
                    client.sendMessage(msg.to,"あなたには権限がありません。")
            elif cms(msg.text,["ホワリス削除"]):
                if check_p(msg):
                    client.sendMessage(msg.to,"ホワイトリストから削除する連絡先を送信してください。")
                    wait["wdwhitelist"][msg.to] = True
                else:
                    client.sendMessage(msg.to,"あなたには権限がありません。")
            elif cms(msg.text,["ホワイトリスト確認"]):
                if check_p(msg) or msg._from in whitelist[msg.to]:
                    if whitelist[msg.to] == []:
                        client.sendMessage(msg.to,"ホワイトリストにしている人はいません。")
                    else:
                        client.sendMessage(msg.to,"以下がホワイトリストです。")
                        mc = ""
                        for mi_d in whitelist[msg.to]:
                            try:
                                mc += "・" + client.getContact(mi_d).displayName + "\n"
                            except Exception as error:
                                #client.sendMessage(msg.to,str(error))
                                mc += "・Removed Contact\n"
                        client.sendMessage(msg.to,mc)
            elif cms(msg.text,["ホワイトリスト初期化"]):
                if check_p(msg):
                    whitelist[msg.to] = []
                    client.sendMessage(msg.to,"独自ホワイトリストの初期化が完了しました。")
                else:
                    client.sendMessage(msg.to,"あなたには権限がありません。")
            elif cms(msg.text, ["点呼"]):
                if(msg._from in admins):
                    try:
                        client.sendMessage(msg.to,"client.:No trouble")
                    except:
                        pass
                    try:
                        Kicker1.sendMessage(msg.to,"kicker1:No trouble")
                    except:
                        pass
                    try:
                        Kicker2.sendMessage(msg.to,"kicker2:No trouble")
                    except:
                        pass
                    try:
                        Kicker3.sendMessage(msg.to,"kicker3:No trouble")
                    except:
                        pass
                    try:
                        Kicker4.sendMessage(msg.to,"kicker4:No trouble")
                    except:
                        pass
                    try:
                        Kicker5.sendMessage(msg.to,"kicker5:No trouble")
                    except:    
                        pass
                    try:
                        Kicker6.sendMessage(msg.to,"kicker6:No trouble")
                    except:
                        pass
                    try:
                        Kicker7.sendMessage(msg.to,"kicker7:No trouble")
                    except:
                        pass    
                    try:
                        Kicker8.sendMessage(msg.to,"kicker8:No trouble")
                    except:    
                        pass
                    try:
                        Kicker9.sendMessage(msg.to,"kicker9:No trouble")    
                    except:
                        pass

            elif cms(msg.text, ["テスト","test"]):
                if check_p(msg):
                        client.sendMessage(msg.to,"正常に稼働中だよ")
            elif cms(msg.text, ["お知らせ"]):
                if check_p(msg):
                        with open('os.txt','r') as f:
                                txt = f.read()
                        client.sendMessage(msg.to,str(txt))
            elif cms(msg.text, ["ホワリあああああス追加"]):
                if check_p(msg):
                        client.sendMessage(msg.to,"めんてなんすちゅう")   
            elif cms(msg.text, ["ブラッああクリスト追加"]):
                if check_p(msg):
                        client.sendMessage(msg.to,"めんてなんすちゅう")     
                                         
            elif cms(msg.text, ["保護画像"]):
                if check_p(msg):                        
                     if msg.to in wait['groupPicture']:
                          client.sendMessage(msg.to, "グループ画像の保護機能はすでに有効になっています。")
                     else:
                           imageName = random_string(10) + ".png"
                           download_img("http://dl.profile.line-cdn.net/" + client.getGroup(msg.to).pictureStatus, imageName)
                           wait['groupPicture'][msg.to] = imageName 
                           f = codecs.open('./groupPicture.json', 'w', 'utf-8')
                           json.dump(wait['groupPicture'], f, sort_keys=True, indent=4, ensure_ascii=False)
                           client.sendMessage(msg.to, "グループ画像の保護機能を有効にしました。")
               
            elif cms(msg.text, ["保護画像オフ"]):
                if check_p(msg):
                    if msg.to in wait['groupPicture']:
                    	imagePath = "./" + wait['groupPicture'][msg.to]
                    	os.remove(imagePath)
                    	del wait['groupPicture'][msg.to]
                    	f = codecs.open('./groupPicture.json', 'w', 'utf-8')
                    	json.dump(wait['groupPicture'], f, sort_keys=True, indent=4, ensure_ascii=False)	
                    	client.sendMessage(msg.to, "グループ画像の保護機能を解除しました。")
                    else:
                    	client.sendMessage(msg.to, "グループ画像の保護機能はすでに無効になっています。")
                 
            elif cms(msg.text, ["保護蹴りオフ"]):
                if check_p(msg):
                    if msg.to in wait["PROTECTKICK"]:
                        del wait["PROTECTKICK"][msg.to]
                        ##print wait
                        client.sendMessage(msg.to, "連続でない強制退会を許可しました。")
                        f=codecs.open('PROTECTKICK.json','w','utf-8')
                        json.dump(wait["PROTECTKICK"], f, sort_keys=True, indent=4,ensure_ascii=False)
                    else:
                        client.sendMessage(msg.to, "すでに連続でない強制退会は許可されています。")
                else:
                    name = client.getContact(msg._from).displayName
                    client.sendMessage(msg.to, "ごめんなさい、" + name + "さんには実行する権限がありません。")
            elif cms(msg.text,["保護参加"]):
                if check_p(msg):
                    if msg.to in Cancelbot:
                        client.sendMessage(msg.to,"既にオンです")
                    else:
                        Cancelbot.append(msg.to)
                        f = open("Cancelbot.txt", 'w')
                        for x in Cancelbot:
                            f.write(str(x) + "\n")
                        f.close()
                        client.sendMessage(msg.to,"オンにしました。招待後10秒以内の参加はBOT参加と判定されキックされます。")
            elif cms(msg.text,["保護参加オフ"]):
                if check_p(msg):
                    if not msg.to in Cancelbot:
                        client.sendMessage(msg.to,"既にオフです")
                    else:
                        Cancelbot.remove(msg.to)
                        f = open("Cancelbot.txt", 'w')
                        for x in Cancelbot:
                            f.write(str(x) + "\n")
                        f.close()
                        client.sendMessage(msg.to,"オフにしました。")
            elif cms(msg.text,["保護アルバムオン"]):
                if check_p(msg):
                    if msg.to in AlbumP:
                        client.sendMessage(msg.to,"既にオンです")
                    else:
                        AlbumP.append(msg.to)
                        f = open("AlbumP.txt", 'w')
                        for x in AlbumP:
                            f.write(str(x) + "\n")
                        f.close()
                        client.sendMessage(msg.to,"オンにしました。")
            elif cms(msg.text,["保護アルバムオフ"]):
                if check_p(msg):
                    if not msg.to in AlbumP:
                        client.sendMessage(msg.to,"既にオフです")
                    else:
                        AlbumP.remove(msg.to)
                        f = open("AlbumP.txt", 'w')
                        for x in AlbumP:
                            f.write(str(x) + "\n")
                        f.close()
                        client.sendMessage(msg.to,"オフにしました。")
            elif cms(msg.text,["復元オン"]):
                if check_p(msg):
                    if msg.to in ReMess:
                        client.sendMessage(msg.to,"既にオンです")
                    else:
                        ReMess.append(msg.to)
                        f = open("ReMess.txt", 'w')
                        for x in ReMess:
                            f.write(str(x) + "\n")
                        f.close()
                        client.sendMessage(msg.to,"オンにしました。")
            elif cms(msg.text,["復元オフ"]):
                if check_p(msg):
                    if not msg.to in ReMess:
                        client.sendMessage(msg.to,"既にオフです")
                    else:
                        ReMess.remove(msg.to)
                        f = open("ReMess.txt", 'w')
                        for x in ReMess:
                            f.write(str(x) + "\n")
                        f.close()
                        client.sendMessage(msg.to,"オフにしました。")
            elif cms(msg.text,["参加挨拶オン"]):
                if check_p(msg) or msg._from in whitelist[msg.to]:
                    if msg.to in JoinG:
                        client.sendMessage(msg.to,"既にオンです")
                    else:
                        JoinG[msg.to] = ""
                        f=codecs.open('JoinG.json','w','utf-8')
                        json.dump(JoinG, f, sort_keys=True, indent=4,ensure_ascii=False)
                        client.sendMessage(msg.to,"オンにしました。")
            elif cms(msg.text,["参加挨拶オフ"]):
                if check_p(msg) or msg._from in whitelist[msg.to]:
                    if not msg.to in JoinG:
                        client.sendMessage(msg.to,"既にオフです")
                    else:
                        del(JoinG[msg.to])
                        f=codecs.open('JoinG.json','w','utf-8')
                        json.dump(JoinG, f, sort_keys=True, indent=4,ensure_ascii=False)
                        client.sendMessage(msg.to,"オフにしました。")
            elif cmi(msg.text,["参加挨拶設定 "]):
                if check_p(msg) or msg._from in whitelist[msg.to]:
                    if not msg.to in JoinG:
                        client.sendMessage(msg.to,"参加挨拶がオフになっているため設定できません。")
                    else:
                        JoinG[msg.to] = msg.text.replace("/参加挨拶設定 ","")
                        f=codecs.open('JoinG.json','w','utf-8')
                        json.dump(JoinG, f, sort_keys=True, indent=4,ensure_ascii=False)
                        client.sendMessage(msg.to,"設定完了")
            elif cms(msg.text,["bots"]):
                if msg._from in admins:
                    for mi in bots:
                        client.sendMessage(msg.to,mi)

            elif cms(msg.text,["キック"]):
                if check_p(msg) or msg._from in p2 or msg._from in whitelist[msg.to]:
                    wait["kick"][msg.to] = True
                    ##print wait
                    client.sendMessage(msg.to,"対象のアカウントを貼ってください。")
                else:
                    client.sendMessage(msg.to,"あなたには権限がありません")
                    
            elif cms(msg.text, ["use"]):
                if(msg._from in admins):
                    client.sendMessage(msg.to,"確認しています…")
                if check_p(msg):
                    cpu = psutil.cpu_percent(interval=1)
                    mem = psutil.virtual_memory()
                    dsk = psutil.disk_usage('/')
                    client.Reply(msg.id,msg.to,"メモリ合計:"+ str(mem.total) + "\n\nメモリ使用率:" + str(mem.percent) + "%" + "\n\nメモリ空き:" + str(mem.available) + "\n\nCPU使用率:" + str(cpu) + "%" + "\n\nディスク合計:" + str(dsk.total) + "\n\nディスク使用量:" + str(dsk.used) + "\n\nディスク空き:" + str(dsk.free))
                    
            elif cms(msg.text,["オールエンド@"]):
                if(msg._from in admins):
                    client.sendMessage(msg.to,"現在参加しているグループからすべて退会し\n保護システムをシャットダウンします")
                    f=codecs.open('black.json','w','utf-8')
                    json.dump(wait["blacklist"], f, sort_keys=True, indent=4,ensure_ascii=False)
                    for gid in client.getGroupIdsJoined():    
                        client.leaveGroup(gid)
                        Kicker1.leaveGroup(gid)
                        Kicker2.leaveGroup(gid)
                        Kicker3.leaveGroup(gid)
                        Kicker4.leaveGroup(gid)
                        Kicker5.leaveGroup(gid)
                        Kicker6.leaveGroup(gid)
                        Kicker7.leaveGroup(gid)
                        Kicker8.leaveGroup(gid)
                        Kicker9.leaveGroup(gid)
                    sys.exit(0)
            elif cms(msg.text,["全グル参加"]):
                if(msg._from in admins):
                    client.sendMessage(msg.to, "現在参加しているすべてのグループにキッカーを参加させます")
                    for gid in client.getGroupIdsJoined():
                        G = client.getGroup(gid)
                        G.preventedJoinByTicket = False
                        client.updateGroup(G)
                        Ticket = client.reissueGroupTicket(gid)
                        for bot in KAC:
                            bot.acceptGroupInvitationByTicket(gid,Ticket)
                        G.preventedJoinByTicket = True
                        client.updateGroup(G)
            elif cms(msg.text,["保護"]):
                if(msg._from in admins):
                    client.sendMessage(msg.to, "ほごです")
            elif cms(msg.text,["全招待拒否"]):
                if(msg._from in admins):
                    for gid in client.getGroupIdsInvited():
                        client.rejectGroupInvitation(gid)
                        #.Count['cancel']
                    print("キャンセル完了\n\r")
              
                    client.sendMessage(msg.to,"招待中のグループ全てをキャンセルしました")
            elif cms(msg.text,["キッカー"]):
                if check_p(msg) or msg._from in whitelist[msg.to]:
                    G = client.getGroup(msg.to)
                    G.preventedJoinByTicket = False
                    client.updateGroup(G)
                    Ticket = client.reissueGroupTicket(msg.to)
                    for bot in KAC:
                        bot.acceptGroupInvitationByTicket(msg.to,Ticket)
                    G.preventedJoinByTicket = True
                    client.updateGroup(G)
                    client.sendMessage(msg.to,"不足していたキッカーを参加させました")
            elif cms(msg.text,["権限"]):
                today = datetime.today()
                if msg._from in admins:
                    client.sendMessage(msg.to,"あなたは最高権限者です。")
                elif check_p(msg):
                    if p1[msg._from] == True:
                        client.sendMessage(msg.to,"あなたはどらほご半永久の権限者です。")
                    else:
                        diff = datetime.strptime(p1[msg._from], '%Y/%m/%d') - today
                        client.sendMessage(msg.to,"あなたはほごの期限付き権限者です。\nのこり" + str(diff) + str(p1[msg._from]) + "までです。")
                        client.sendMessage(msg.to,"権限が欲しかったら　https://line.me/R/ti/p/%40dnl6116i　この垢にきてください")
                elif msg._from in p2:
                    client.sendMessage(msg.to,"あなたはレベル2の権限を所持しています。")
                elif msg._from in p3:
                    client.sendMessage(msg.to,"あなたはレベル1の権限を所持しています。")
                elif msg._from in whitelist[msg.to]:
                    client.sendMessage(msg.to,"あなたはこのグループのホワイトリストユーザーです。")
                else:
                    client.sendMessage(msg.to,"あなたは権限を所持していません。")
                    client.sendMessage(msg.to,"権限の購入は下のアカウントを追加してください。\n\n https://line.me/ti/p/dPV0MVClav")
            elif "/期限設定 @" in msg.text:
                if msg._from in admins:
                    targets = []
                    key = eval(msg.contentMetadata["MENTION"])
                    key["MENTIONEES"][0]["M"]
                    tex = msg.text.split()
                    for x in key["MENTIONEES"]:
                        targets.append(x["M"])
                    for target in targets:
                        try:
                            if len(tex) == 3:
                                p1[target] = tex[2]
                                haveP[target] = tex[2]
                            else:
                                p1[target] = True
                                haveP[target] = True
                            client.sendMessage(msg.to, "success")
                        except:
                            client.sendMessage(msg.to, "Failed")
                    f=codecs.open('p1.json','w','utf-8')
                    json.dump(p1, f, sort_keys=True, indent=4,ensure_ascii=False)
                else:
                    client.sendMessage(msg.to, "実行する権限がありません。")
            elif "/権限追加 @" in msg.text:
                if msg._from in admins:
                    targets = []
                    key = eval(msg.contentMetadata["MENTION"])
                    key["MENTIONEES"][0]["M"]
                    tex = msg.text.split()
                    for x in key["MENTIONEES"]:
                        targets.append(x["M"])
                    for target in targets:
                        if (target in p1) or (target in admins):
                                client.sendMessage(msg.to, "すでに権限者に登録されてるよ！")
                        else:
                            try:
                                if len(tex) == 3:
                                    p1[target] = tex[2]
                                    haveP[target] = tex[2]
                                else:
                                    p1[target] = True
                                    haveP[target] = True
                                client.sendMessage(msg.to, "success")
                            except:
                                client.sendMessage(msg.to, "Failed")
                    f=codecs.open('p1.json','w','utf-8')
                    json.dump(p1, f, sort_keys=True, indent=4,ensure_ascii=False)
                else:
                    client.sendMessage(msg.to, "実行する権限がありません。")
            if "/権限削除 @" in msg.text:
                if msg._from in admins:
                    targets = []
                    key = eval(msg.contentMetadata["MENTION"])
                    key["MENTIONEES"][0]["M"]
                    for x in key["MENTIONEES"]:
                        targets.append(x["M"])
                    for target in targets:
                        if target in p1:
                            del p1[target]
                            f=codecs.open('p1.json','w','utf-8')
                            json.dump(p1, f, sort_keys=True, indent=4,ensure_ascii=False)
                            del haveP[target]
                            client.sendMessage(msg.to, "success")
                        else:
                            client.sendMessage(msg.to, "もともと権限を所持していないみたい。")
                else :
                    client.sendMessage(msg.to, "権限が足りないみたい")
            elif cmi(msg.text,["権限削除 "]):
                if msg._from in admins:
                    if p1 == []:
                        client.sendMessage(msg.to,"権限者はいません。")
                    else:
                        name = msg.text.replace("/権限削除 ","")
                        mc = ""
                        rm = []
                        for mi_d in p1:
                            try:
                                if name in client.getContact(mi_d).displayName:
                                    rm.append(mi_d)
                                    try:
                                        mc += "・" +client.getContact(mi_d).displayName + "\n"
                                    except Exception as error:
                                #client.sendMessage(msg.to,str(error))
                                        mc += "・Removed Contact\n"
                            except:
                                pass
                        if rm == []:
                            client.sendMessage(msg.to,"権限者に登録されていません。")
                        else:
                            for us in rm:
                                del p1[us]
                                del haveP[us]
                            f=codecs.open('p1.json','w','utf-8')
                            json.dump(p1, f, sort_keys=True, indent=4,ensure_ascii=False)
                            client.sendMessage(msg.to,"以下の権限者の権限を削除しました。\n" + mc)
            if "/ブラックリスト追加 @" in msg.text:
                if check_p(msg):
                    targets = []
                    key = eval(msg.contentMetadata["MENTION"])
                    key["MENTIONEES"][0]["M"]
                    for x in key["MENTIONEES"]:
                        targets.append(x["M"])
                    for target in targets:
                        if (target in list(haveP.keys())) or (target in bots):
                            client.sendMessage(msg.to,"ブラックリストに追加できないユーザーです。")
                            del wait["wblacklist"][msg.to]
                        else:
                            if target in wait["blacklist"]:
                                client.sendMessage(msg.to,"既にブラックリストに登録されています。")
                                del wait["wblacklist"][msg.to]
                            else:
                                wait["blacklist"][target] = True
                                client.sendMessage(msg.to,"ブラックリストに追加しました。")
                                del wait["wblacklist"][msg.to]
                                wait["blacklist"][target] = True
                            f=codecs.open('black.json','w','utf-8')
                            json.dump(wait["blacklist"], f, sort_keys=True, indent=4,ensure_ascii=False)
                else :
                    client.sendMessage(msg.to, "権限が足りないみたい")
            elif cmi(msg.text,["ブラリス削除"]):
                if msg._from in admins:
                    if wait["blacklist"] == {}:
                        client.sendMessage(msg.to,"ブラックリストにしてる人はいません。")
                    else:
                        name = msg.text.replace("/ブラリス削除 ","")
                        mc = ""
                        rm = []
                        for mi_d in wait["blacklist"]:
                            try:
                                if name in client.getContact(mi_d).displayName:
                                    rm.append(mi_d)
                                    try:
                                        mc += "・" +client.getContact(mi_d).displayName + "\n"
                                    except Exception as error:
                                #client.sendMessage(msg.to,str(error))
                                        mc += "・Removed Contact\n"
                            except:
                                pass
                        if rm == []:
                            client.sendMessage(msg.to,"ブラックリストに登録されていません。")
                        else:
                            for us in rm:
                                del wait["blacklist"][us]
                            f=codecs.open('black.json','w','utf-8')
                            json.dump(wait["blacklist"], f, sort_keys=True, indent=4,ensure_ascii=False)
                            client.sendMessage(msg.to,"以下のブラックリストユーザーを削除しました。\n" + mc)
            elif cms(msg.text,["権限者確認"]):
                if msg._from in admins:
                    if p1 == []:
                        client.sendMessage(msg.to,"権限者にしている人はいません。")
                    else:
                        client.sendMessage(msg.to,"以下が権限者リストです。")
                        mc = ""
                        for mi_d in p1:
                            try:
                                mc += "・" +client.getContact(mi_d).displayName + ":" + str(p1[mi_d]) + "まで\n"
                            except Exception as error:
                                #client.sendMessage(msg.to,str(error))
                                mc += "・Removed Contact\n"
                        client.sendMessage(msg.to,mc)
            elif cms(msg.text,["ブラックリスト確認"]):
                if check_p(msg):
                    if wait["blacklist"] == {}:
                        client.sendMessage(msg.to,"ブラックリストにしている人はいません。")
                    else:
                        client.sendMessage(msg.to,"以下がブラックリストです。")
                        mc = ""
                        for mi_d in wait["blacklist"]:
                            try:
                                mc += "・" +client.getContact(mi_d).displayName + "\n"
                            except Exception as error:
                                #client.sendMessage(msg.to,str(error))
                                mc += "・Removed Contact\n"
                        client.sendMessage(msg.to,mc)
            elif cms(msg.text,["ブラックリスト確認 -c"]):
                if msg._from in (admins):
                    if wait["blacklist"] == {}:
                        client.sendMessage(msg.to,"ブラックリストにしている人はいません。")
                    else:
                        client.sendMessage(msg.to,"以下がブラックリストです。")
                        for mi_d in wait["blacklist"]:
                            try:
                                client.sendContact(msg.to,mi_d)
                            except Exception as error:
                                #client.sendMessage(msg.to,str(error))
                                pass
            elif cms(msg.text,["ブラリスばいばい"]):
                if check_p(msg):
                    group = client.getGroup(msg.to)
                    gMembMids = [contact.mid for contact in group.members]
                    matched_list = []
                    for tag in wait["blacklist"]:
                        matched_list+=filter(lambda str: str == tag, gMembMids)
                    if matched_list == []:
                        client.sendMessage(msg.to,"ブラックリストユーザーはいませんでした。")
                        return
                    for jj in matched_list:
                        print("ブラリス排除を実行しました。%s人キックしました。\n\r"%len(matched_list))
                        try:
                            client.kickoutFromGroup(msg.to,[jj])
                            Count['kick']+=1
                        except:
                            bot = random.choice(KAC)
                            bot.kickoutFromGroup(msg.to,[jj])
                    client.sendMessage(msg.to,"ブラックリストユーザーの追い出しが完了しました。")
                    print(str(Count))
            elif cms(msg.text,["処理速度"]):
                start = time.time()
                client.sendMessage(msg.to , "Progress")
                elapsed_time = time.time() - start
                client.sendMessage(msg.to , "%ssecond" % (elapsed_time))
    except KeyboardInterrupt:
	       sys.exit(0)
    except Exception as error:
        print (error)
tracer.addOpInterrupt(26, RECEIVE_MESSAGE)

def NOTIFIED_READ_MESSAGE(op):
    ##print op
    try:
        if op.param1 in wait['readPoint']:
            Name = client.getContact(op.param2).displayName
            if Name in wait['readMember'][op.param1]:
                pass
            else:
                wait['readMember'][op.param1] += "\n・" + Name + "さん\n" + datetime.today().strftime('[%Y-%m-%d %H:%M:%S]')
                wait['ROM'][op.param1][op.param2] = "・" + Name + "さん"
        else:
            pass
    except:
        pass

tracer.addOpInterrupt(55, NOTIFIED_READ_MESSAGE)


def NOTIFIED_INVITE_INTO_GROUP(op):
    try:
        if profile.mid in op.param3:
            if check_p_u(op.param2,p1):
                try:
                    client.acceptGroupInvitation(op.param1)
                    client.findAndAddContactsByMid(profile_B.mid)
                    client.inviteIntoGroup(op.param1, profile_B.mid)
                    Kicker1.acceptGroupInvitation(op.param1)
                    time.sleep(0.2)
                    Kicker1.findAndAddContactsByMid(profile_C.mid)
                    Kicker1.inviteIntoGroup(op.param1,profile_C.mid)
                    Kicker2.acceptGroupInvitation(op.param1)
                    time.sleep(0.2)
                    Kicker2.findAndAddContactsByMid(profile_D.mid)
                    Kicker2.inviteIntoGroup(op.param1,profile_D.mid)
                    Kicker3.acceptGroupInvitation(op.param1)
                    time.sleep(0.2)
                    Kicker3.findAndAddContactsByMid(profile_E.mid)
                    Kicker3.inviteIntoGroup(op.param1,profile_E.mid)
                    Kicker4.acceptGroupInvitation(op.param1)
                    time.sleep(0.2)
                    Kicker4.findAndAddContactsByMid(profile_F.mid)
                    Kicker4.inviteIntoGroup(op.param1,profile_F.mid)
                    Kicker5.acceptGroupInvitation(op.param1)
                    time.sleep(0.2)
                    Kicker5.findAndAddContactsByMid(profile_G.mid)
                    Kicker5.inviteIntoGroup(op.param1,profile_G.mid)
                    Kicker6.acceptGroupInvitation(op.param1)
                    time.sleep(0.2)
                    Kicker6.findAndAddContactsByMid(profile_H.mid)
                    Kicker6.inviteIntoGroup(op.param1,profile_H.mid)
                    Kicker7.acceptGroupInvitation(op.param1)
                    time.sleep(0.2)
                    Kicker7.findAndAddContactsByMid(profile_I.mid)
                    Kicker7.inviteIntoGroup(op.param1,profile_I.mid)
                    Kicker8.acceptGroupInvitation(op.param1)
                    time.sleep(0.2)
                    Kicker8.findAndAddContactsByMid(profile_J.mid)
                    Kicker8.inviteIntoGroup(op.param1,profile_J.mid)
                    Kicker9.acceptGroupInvitation(op.param1)
                    time.sleep(0.2)
                    G = client.getGroup(op.param1)
                    G.preventedJoinByTicket = True
                    client.updateGroup(G)
                    name = client.getContact(op.param).displayName
                    Ntime = datetime.now().strftime("[%Y/%m/%d(%A) %H:%M:%S]")
                    name = client.getContact(op.param2).displayName
                    client.sendMessage(op.param1, "ほごだよ\n\n過去に入ってたグルの場合は\n/groupで保護が有効なっているか確認してください。\n過去に入ってない場合は初期設定で全ての保護がオフになっています。\n\n権限を購入するとこのBOTを使うことができるよ！\n\n権限の購入はこちらまで\n https://line.me/ti/p/dPV0MVClav")
                    gname = client.getGroup(op.param1).name
                    name = client.getContact(op.param2).displayName
                    client.sendMessage("u61999b628f0bf9d3f7b874d622d4fede","[報告]\n\n新規グループに参加しました\n\n[グループ名]\n→[" + gname + "]\n\n[招待者]\n→[" + name + "]\n\n[招待者mid]\n→["  + op.param2 + "]")
                    wait["rapidFire"][op.param1] = time.time()
                    if op.param1 in whitelist:
                        pass
                    else:
                        whitelist[op.param1] = []
                except:
                    client.acceptGroupInvitation(op.param1)
                    G = client.getGroup(op.param1)
                    G.preventedJoinByTicket = False
                    client.updateGroup(G)
                    Ticket = client.reissueGroupTicket(op.param1)
                    for bot in KAC:
                        bot.acceptGroupInvitationByTicket(op.param1,Ticket)
                    G.preventedJoinByTicket = True
                    client.updateGroup(G)
                    client.sendMessage(op.param1, "保護botです。\nこの保護は権限制です。\n半永久3000円です。\n他にもいろいろな物を売っているのでぜひ追加してください。\n↓購入、質問はこちら↓\n https://line.me/ti/p/dPV0MVClav")                   
                    gname = client.getGroup(op.param1).name
                    name = client.getContact(op.param2).displayName
                    client.sendMessage("u61999b628f0bf9d3f7b874d622d4fede","[報告]\n\n新規グループに参加しました\n\n[グループ名]\n→[" + gname + "]\n\n[招待者]\n→[" + name + "]\n\n[招待者mid]\n→["  + op.param2 + "]")
                    wait["rapidFire"][op.param1] = time.time()
                    if op.param1 in whitelist:
                        pass
                    else:
                        whitelist[op.param1] = []
                    ##print wait["rapidfire"]
        elif op.param1 in wait["protect"]:
            if op.param2 in kickers:
                return
            if check_p_u(op.param2,p1) or op.param2 in whitelist[op.param1]:
                return
            Inviter = op.param3.replace("",',')
            InviterX = Inviter.split(",")
            #client.cancelGroupInvitation(op.param1, InviterX)
            if not op.param1 in InviK:
                InviK[op.param1]=[]
            for X in InviterX:
                if not check_p_u(X,p1) or not X in whitelist[op.param1]:
                    InviK[op.param1].append(X)
            f=codecs.open('InviK.json','w','utf-8')
            json.dump(InviK, f, sort_keys=True, indent=4,ensure_ascii=False)
            print("招待保護中に招待したためキックしました。%s\n\r"%op.param2)
            Count['kick']+=1
            print(str(Count))
            try:
                #pass
                client.kickoutFromGroup(op.param1,[op.param2])
            except:
                #pass
                Kicker1.kickoutFromGroup(op.param1,[op.param2])
                Kicker2.kickoutFromGroup(op.param1,[op.param2])
                Kicker3.kickoutFromGroup(op.param1,[op.param2])
                Kicker4.kickoutFromGroup(op.param1,[op.param2])
                Kicker5.kickoutFromGroup(op.param1,[op.param2])
                Kicker6.kickoutFromGroup(op.param1,[op.param2])
                Kicker7.kickoutFromGroup(op.param1,[op.param2])
                Kicker8.kickoutFromGroup(op.param1,[op.param2])
                Kicker9.kickoutFromGroup(op.param1,[op.param2])
            client.sendMessage(op.param1,"保護中に招待をしたため、招待者の強制退出を試みました。")
            gname = client.getGroup(op.param1).name
            name = client.getContact(op.param2).displayName
            client.sendMessage("u61999b628f0bf9d3f7b874d622d4fede","[報告]\n\n招待保護中に招待したユーザーがいたため違反者を退会させました\n\n[グループ名]\n→[" + gname + "]\n\n[違反者]\n→[" + name + "]\n\n[違反者mid]\n→[" + op.param2 + "]")
        else:
            if op.param3 in list(haveP.keys()) or not op.param1 in Cancelbot:
                pass
            else:
                if not op.param1 in list(InviC.keys()):
                    InviC[op.param1]={}
                else:
                    pass
                nowte = datetime.now()
                InviC[op.param1][op.param3] = nowte
            Inviter = op.param3.replace("",',')
            InviterX = Inviter.split(",")
            matched_list = []
            for tag in wait["blacklist"]:
                matched_list+=filter(lambda str: str == tag, InviterX)
            if matched_list == []:
                pass
            else:

                #client.cancelGroupInvitation(op.param1, matched_list)
                if check_p_u(op.param2,p1) or op.param2 in (bots+whitelist[op.param1]):
                    print("ブラックリストユーザーの招待を検知しましたが、実行者が権限者です。")
                    randam.choice(KAC).cancelGroupInvitation(op.param1,op.param2)
                    client.sendMessage(op.param1,"ブラックリストユーザーが招待されたのでキャンセルしました。")
                print("ブラックリストユーザーの招待を検知したためキックしました。%s\n\r%s\n\r" %(matched_list,op.param2))
                try:
                    Count['kick']+=1
                    #Count['cancel']+=1
                    print(str(Count))
                    #pass
                    client.kickoutFromGroup(op.param1,[op.param2])
                except:
                    #pass
                    Kicker1.kickoutFromGroup(op.param1,[op.param2])
                    Kicker2.kickoutFromGroup(op.param1,[op.param2])
                    Kicker3.kickoutFromGroup(op.param1,[op.param2])
                    Kicker4.kickoutFromGroup(op.param1,[op.param2])
                    Kicker5.kickoutFromGroup(op.param1,[op.param2])
                    Kicker6.kickoutFromGroup(op.param1,[op.param2])
                    Kicker7.kickoutFromGroup(op.param1,[op.param2])
                    Kicker8.kickoutFromGroup(op.param1,[op.param2])
                    Kicker9.kickoutFromGroup(op.param1,[op.param2])
                client.sendMessage(op.param1,"ブラックリストユーザーが招待されたので招待者の強制退出を試みました。")
                gname = client.getGroup(op.param1).name
                name = client.getContact(op.param2).displayName
                client.sendMessage("u61999b628f0bf9d3f7b874d622d4fede","[報告]\n\nブラックリストユーザーを招待したアホがいたため違反者を退会させました\n\n[グループ名]\n→[" + gname + "]\n\n[違反者]\n→[" + name + "]\n\n[違反者mid]\n→[" + op.param2 + "]")
    except Exception as e:
        print (e)
tracer.addOpInterrupt(13, NOTIFIED_INVITE_INTO_GROUP)




def NOTIFIED_UPDATE_GROUP(op):
    try:
        ##print op
        """
        op.param3
        1がグループ名
        2がグループ画像
        3が
        4がurl
        """
        #wait["PROTECTGNAMECHANGE"]
        if op.param3 == "1":
            if op.param2 in bots:
                return
            if op.param1 in wait["PROTECTGNAMECHANGE"]:
                if op.param2 in (list(haveP.keys()) + whitelist[op.param1]):
                    G =client.getGroup(op.param1)
                    G.name = gname[op.param1]
                    client.updateGroup(G)
                else:
                    G = client.getGroup(op.param1)
                    G.preventedJoinByTicket = True
                    G.name = gname[op.param1]
                    client.updateGroup(G)
                    if op.param2 in wait["blacklist"]:
                        pass
                    else:
                        wait["blacklist"][op.param2] = True
                        f=codecs.open('black.json','w','utf-8')
                        json.dump(wait["blacklist"], f, sort_keys=True, indent=4,ensure_ascii=False)

        elif op.param3 == "2":
            if op.param2 in bots:
                return        	
            if op.param1 in wait['groupPicture']:
                if op.param2 in botMids:
                    pass
                else:
                    imagePath = "./" + wait['groupPicture'][op.param1]
                    client.updateGroupPicture(op.param1, imagePath)                                     
                        
        elif op.param3 == "4":
            if op.param2 in bots:
                return
            if op.param1 in wait["PROTECTURLINVITECHANGE"]:
                if (op.param2 in list(haveP.keys())):
                    G = Kicker1.getGroup(op.param1)
                    G.preventedJoinByTicket = True
                    Kicker1.updateGroup(G)
                else:
                    print("招待URL変更を検知したためキックしました。%s\n\r"%op.param2)
                    Count['kick']+=1
                    print(str(Count))
                    G = client.getGroup(op.param1)
                    if G.preventedJoinByTicket == True:
                        pass
                    else:
                        try:
                            #pass
                            client.kickoutFromGroup(op.param1,[op.param2])
                        except:
                            #pass
                            Kicker3.kickoutFromGroup(op.param1,[op.param2])
                        G.preventedJoinByTicket = True
                        client.updateGroup(G)
                        if op.param2 in wait["blacklist"]:
                            pass
                        else:
                            wait["blacklist"][op.param2] = True
                            f=codecs.open('black.json','w','utf-8')
                            json.dump(wait["blacklist"], f, sort_keys=True, indent=4,ensure_ascii=False)
    except Exception as e:
        print (e)

tracer.addOpInterrupt(11,NOTIFIED_UPDATE_GROUP)

#def NOTIFIED_CANCEL_INVITATION_GROUP(op):
    ##print op
#tracer.addOpInterrupt(32,NOTIFIED_CANCEL_INVITATION_GROUP)

def NOTIFIED_ACCEPT_GROUP_INVITATION(op):
    ##print op
    try:
        if op.param1 in InviK:
            if op.param2 in InviK[op.param1]:
                try:
                    client.kickoutFromGroup(op.param1,[op.param2])
                except:
                    KickerK.kickoutFromGroup(op.param1,[op.param2])
                InviK[op.param1].remove(op.param2)
                f=codecs.open('InviK.json','w','utf-8')
                json.dump(InviK, f, sort_keys=True, indent=4,ensure_ascii=False)
                client.sendMessage(op.param1,"招待保護中に招待されたユーザーのためキックしました")
                gname = client.getGroup(op.param1).name
                name = client.getContact(op.param2).displayName
                client.sendMessage("u61999b628f0bf9d3f7b874d622d4fede","[報告]\n\n招待保護中に招待されたユーザーなので退会させました\n\n[グループ名]\n→[" + gname + "]\n\n[違反者]\n→[" + name + "]\n\n[違反者mid]\n→[" + op.param2 + "]")
        #if op.param2 in wait["blacklist"]:
            #if op.param2 in bots:
                #return
            #print("ブラックリストユーザーの参加を感知したためキックしました。%s\n\r"%op.param2)
           # client.sendMessage(op.param2, "ブラックリストユーザーの参加を検知したため退会させました")
           # gname = client.getGroup(op.param1).name
          #  name = client.getContact(op.param2).displayName
          #  client.sendMessage("u61999b628f0bf9d3f7b874d622d4fede","[報告]\n\nブラックリストユーザーが参加したため退会させました\n\n[グループ名]\n→[" + gname + "]\n\n[ブラリスの人]\n→[" + name + "]\n\n[mid]\n→[" + op.param2 + "]")
          #  Count['kick']+=1
     #     3  print(str(Count))
          #  G = client.getGroup(op.param1)
       #  3   try:
          #      #pass
         #       client.kickoutFromGroup(op.param1,[op.param2])
         #   except:
           #     try:
          #          #pass
            #        Kicker3.kickoutFromGroup(op.param1,[op.param2])
          #      except:
         #           Kicker1.kickoutFromGroup(op.param1,[op.param2])
         #   client.sendMessage(op.param1,[op.param2],"ブラックリストユーザーの参加を検知したためキックしました。")
         #   gname = client.getGroup(op.param1).name
         #   name = client.getContact(op.param2).displayName
           # client.sendMessage("u61999b628f0bf9d3f7b874d622d4fede","[報告]\n\nブラックリストユーザーが参加したため退会させました\n\n[グループ名]\n→[" + gname + "]\n\n[違反者]\n→[" + name + "]\n\n[違反者mid]\n→[" + op.param2 + "]")
           # G.preventedJoinByTicket = True
       #     client.updateGroup(G)
        elif op.param1 in Cancelbot and op.param2 in list(InviC[op.param1]):
            if op.param2 in bots:
                return
            print("招待後5秒以内の参加を感知したためキックしました。%s\n\r"%op.param1)
            client.sendMessage(op.param1, "招待後5秒以内の参加を感知したため退会させました。")
            gname = client.getGroup(op.param1).name
            name = client.getContact(op.param2).displayName
            client.sendMessage("u61999b628f0bf9d3f7b874d622d4fede","[報告]\n\n参加が早くてかっこよかったのでキックしました\n\n[グループ名]\n→[" + gname + "]\n\n[違反者]\n→[" + name + "]\n\n[違反者mid]\n→[" + op.param2 + "]")
            Count['kick']+=1
            print(str(Count))
            G = client.getGroup(op.param1)
            try:
                #pass
                client.kickoutFromGroup(op.param1,[op.param2])
            except:
                try:
                    #pass
                    KickerK.kickoutFromGroup(op.param1,[op.param2])
                except:
                    Kicker1.kickoutFromGroup(op.param1,[op.param2])
            client.sendMessage(op.param1,"招待後5秒以内の参加は拒否されています")
            gname = client.getGroup(op.param1).name
            name = client.getContact(op.param2).displayName
            client.sendMessage("u61999b628f0bf9d3f7b874d622d4fede","[報告]\n\n参加が早かったからしかりました\n\n[グループ名]\n→[" + gname + "]\n\n[違反者]\n→[" + name + "]\n\n[違反者mid]\n→[" + op.param2 + "]")
            G.preventedJoinByTicket = True
            client.updateGroup(G)
        elif op.param1 in JoinG and not op.param2 in bots:
            con = client.getContact(op.param2)
            gu = client.getGroup(op.param1)
            try:
                client.sendMessage(op.param1,""+gu.name+"へようこそ！\n\n" + str(JoinG[op.param1]))
            except:
                client.sendMessage(op.param1,""+gu.name+"へようこそ！\n\n" + str(JoinG[op.param1]))
    except Exception as e:
        print (e)
tracer.addOpInterrupt(17,NOTIFIED_ACCEPT_GROUP_INVITATION)

def NOTIFY_REMOVE_MESSAGE(op):
    try:
        if op.param1 in ReMess:
            con= client.getContact(Messid[op.param1][op.param2]._from)
            client.sendMessage(op.param1,con.displayName+"さんが\n【"+Messid[op.param1][op.param2].text+"】\nというメッセージを削除しました！")
    except:
        pass
tracer.addOpInterrupt(65,NOTIFY_REMOVE_MESSAGE)

def Cancelbot_C():
    while True:
        gu = datetime.now()
        #print (InviC)
        for h in list(InviC):
            for g in list(InviC[h]):
                tdel = gu-InviC[h][g]
                if tdel.seconds >= 5:
                    del InviC[h][g]
        time.sleep(1)
thread2 = threading.Thread(target=Cancelbot_C)
thread2.daemon = True
thread2.start()

def Update_time():
    while True:
        ROM["now"] = datetime.now()
        time.sleep(1)
thread1 = threading.Thread(target=Update_time)
thread1.daemon = True
thread1.start()

def Kick_C():
    while True:
        #print(ROM)
        hujn = datetime.now()
        for huj in list(ROM["kickt"]):
            thub=hujn-ROM["kickt"][huj][-1]
            if len(ROM["kickt"][huj])>=5 and len(ROM["kickt"][huj])<=5:
                if not adminG==[]:
                    for Gu in adminG:
                        try:
                            us=""
                            for ku in ROM["kicku"][huj]:
                                guh = client.getContact(ku)
                                us+="・" + guh.displayName + "\n"
                            gr = client.getGroup(huj)
                            client.sendMessage(Gu,"【アラート】\n現在[" + gr.name +"] にて" + us + "が合計" + str(len(ROM["kickt"][huj])) +"回蹴っています。\n蹴り合いの可能性があります。このアラートは5回目でストップ致します。")
                        except:
                            client.sendMessage(Gu,"【アラート】\n現在、gid[" + huj + "]にて\nmid" + str(ROM["kicku"][huj]) + "が合計" + str(len(ROM["kickt"][huj])) +"回蹴っています。\n蹴り合いの可能性があります。このアラート15回目でストップ致します。")
            if len(ROM["kickt"][huj])==5:
                if not adminG == []:
                    for Gu in adminG:
                        for uh in ROM["kicku"][huj]:
                            client.sendContact(Gu,uh)
            if thub.seconds >= 5:
                del(ROM["kickt"][huj])
                del(ROM["kicku"][huj])
               

        time.sleep(0.5)
thread3 = threading.Thread(target=Kick_C)
thread3.daemon = True
thread3.start()

while True:
    tracer.trace()