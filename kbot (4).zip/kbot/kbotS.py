from Linephu.linepy import *
import time, random, sys, json, codecs, threading, glob, re, string, os, requests, subprocess, six, ast, pytz, urllib, urllib.parse, timeit
from time import sleep
from humanfriendly import format_timespan, format_size, format_number, format_length
client = LINE('nokonoko101466@gmail.com','kouta1014')
oepoll = OEPoll(client)
def RECEIVE_MESSAGE(op):
	msg = op.message

	text = msg.text
	msg_id = msg.id
	sender = msg._from
	receiver = msg.to
	contact = client.getContact(sender)
	txt = '[%s] %s' % (contact.displayName, text)
	client.log(txt)
	if text.lower() == 'URL発行':
		try:
			client.Reply(msg.id,msg.to,"wait....")
			cmd = 'py kbot6.0-1.py'
			subprocess.Popen(cmd.split())
			sleep(1)
			with open('login.txt','r') as f:
				txt = f.read()
			client.Reply(msg.id,msg.to,str(txt))
		except Exception as e:
			print(e)
			cl.sendMessage(msg.to, str(e))
	elif text.lower() == 'gurl':
		g = client.getGroup(to)
		if g.preventedJoinByTicket == True:
			g.preventedJoinByTicket = False
			client.updateGroup(g)
			gurl = client.reissueGroupTicket(to)
			client.sendMessage(to,"line://ti/g/" + gurl)
			print("line://ti/g/" + gurl)
	elif text.lower() == 'help':
		client.sendMessage(to,"""
これはLITE版です、招待して使用できます
～機能～
help→このメッセージを送信します
gurl→グループのURlを生成します
連絡先→製品版の販売者の連絡先を送信します
helpR→製品版のヘルプメッセージヘルプメッセージを送信します
""")
	elif text.lower() == 'helpR':
		helpmessage = helpMessage()
		client.sendMessage(to,str(helpmessage))
oepoll.addOpInterruptWithDict({
	OpType.RECEIVE_MESSAGE: RECEIVE_MESSAGE, 

})

while True:
	oepoll.trace()