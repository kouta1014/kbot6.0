from linepy import *
client = LINE('koutamanto@icloud.com','kouta1014')
client.log("Auth Token :"+str(client.authToken))

oepoll = OEPoll(client)

def RECEIVE_MESSAGE(op):
  msg = op.message

  text = msg.text
  msg_id = msg.id
  to = msg.to
  sender = msg._from

  try:
    if text.lower() == 'hello':
          client.sendMessage(to,"hello! nice to meet you!")
  except Exception as e:
    client.log("[RECEIVE_MESSAGE] ERROR : " + str(e))       
  
oepoll.addOpInterruptWithDict({

    OpType.RECEIVE_MESSAGE: RECEIVE_MESSAGE,

})

while True:
  oepoll.trace()