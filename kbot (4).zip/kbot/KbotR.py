#Copyright (C) 2019 Kouta All Rights Reserved.
import base64
from Linephu.linepy import *
import random
import os
import time
from thrift.protocol import TCompactProtocol
from thrift.transport import THttpClient
from ttypes import Message
from ttypes import LoginRequest
import json, requests, LineService
import datetime
import subprocess

ver = "4.3"
LoginArt = """
====[login now...]===
O  O  OOO    OOO   OOOOO
O O   O  O  O   O    O  
OO    OOO   O   O    O
O O   O  O  O   O    O
O  O  OOO    OOO     O

====[kbot ver.4.3]=====

"""
logo = """
[kbot ver.4.3]
O    O
O  O
OO
O  O
O    O

OOOOO
O    O
OOOOO
O    O
OOOOO

 OOO
O   O
O   O
O   O
 OOO 

OOOOO
  O
  O
  O
  O
"""

newpassword=0
password = 0
password = input("password?:")
if password == "114514":
	print("パスワード合致、ログインします")
	print(LoginArt)
	client = LINE('nokonoko101466@gmail.com','kouta1014')
	client.log("Auth Token :"+str(client.authToken))
	oepoll = OEPoll(client)
elif password != "114514":
	print("パスワードが違います、再試行してください")
fightermids = []
infnity = 0;
def RECEIVE_MESSAGE(op):
	msg = op.message

	text = msg.text
	to = msg.to
	me = "u1505299bc3e6d961c34321d34e2aa415"
	mids = client.getAllContactIds()
	sender = msg._from
	try:
		if text.lower() == 'test':
			client.sendMessage(to,"正常に作動しています")
		elif text.lower() == 'うらる許可':
			group = client.getGroup(msg.to)
			group.preventedJoinByTicket = False
			client.updateGroup(group)
			client.sendMessage(msg.to,"URLを許可しました。")
		elif text.lower() == 'うらる拒否':
			group = client.getGroup(msg.to)
			group.preventedJoinByTicket = True
			client.updateGroup(group)
			client.sendMessage(msg.to,"URLを拒否しました。")
		elif text.lower() == 'gurl':
			gurl = client.reissueGroupTicket(to)
			client.sendMessage(to,"[グループ参加URL:]" + gurl)
	except Exception as e:
		client.log("[SEND_MESSAGE]ERROR :"+ str(e))

oepoll.addOpInterruptWithDict({
	OpType.RECEIVE_MESSAGE: RECEIVE_MESSAGE,

})

while True:
	oepoll.trace()