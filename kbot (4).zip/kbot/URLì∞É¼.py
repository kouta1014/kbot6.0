import os
wincount = 0
while wincount != 4:
	cmd = "start py 乗っ取りうらる.py"
	os.system(cmd)
	wincount = wincount + 1