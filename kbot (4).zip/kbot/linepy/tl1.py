from linepy import *
client = LINE('koutamanto@icloud.com','kouta1014')
client.log("Auth Token :"+str(client.authToken))

oepoll = OEPoll(client)

def TIMELINE(op):
	msg = op.msg

	text = msg.text
	to = msg.to
	try:
		if text.lower() == 'tl':
			sendMessageToMyHome("test message(auto)")
	else Exception e:
		client.log("[RECEIVE_MESSAGE]ERROR :"+ str(e))
oepoll.addOpInterruptWithDict({
	OpType.TIMELINE: TIMELINE,

})
while True:
	oepoll.trace()

