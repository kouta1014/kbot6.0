from linepy import *
import random
import os
newpassword=0
password = 0
password = input("password?:")
if password == "114514":
	print("パスワード合致、ログインします")
	client = LINE('nokonoko101466@gmail.com','kouta1014')
	client.log("Auth Token :"+str(client.authToken))
	oepoll = OEPoll(client)
	ki = LINE('ganyonyo27@eay.jp','kouta1014')
	client.log("Auth Token :"+str(client.authToken))
	oepoll1 = OEPoll(ki)
	ki2 = LINE('koutasabu068@gmail.com','kouta1014')
	client.log("Auth Token :"+str(client.authToken))
	oepoll2 = OEPoll(ki2)
	ki3 = LINE('ziregaha@ponp.be','kouta1014')
	client.log("Auth Token :"+str(client.authToken))
	oepoll3 = OEPoll(ki3)
	ki4 = LINE('pahe782@risu.be','kouta1014')
	client.log("Auth Token :"+str(client.authToken))
	oepoll4 = OEPoll(ki4)
elif password != "114514":
	print("パスワードが違います、再試行してください")

infnity = 0;
def OMMC():
	OMMC = """いっきっきの～き～w＼ｱｲｱｲｱｲ／ いっきっきの～き～w＼ｱｲｱｲｱｲ／
いっきっきの～き～w(ｵﾏﾝｺ?)＼ｱｲｱｲｱｲ／ いっきっきの～き～w(ｵﾁﾝｺ?)＼ｱｲｱｲｱｲ／
いっきっきの～き～w(ｵﾏﾝｺ?) いっきっきの～き～w(ｵﾁﾝｺ?)
ｱﾚ？ｱﾚ？ｱﾚ？wｱﾚｪ？(ゆっくんにしては味わってる)(もうヤバい)
ゆかり？呑んでなくない？ｳｫｳ ｳｫｳ⤴ ゆかり？呑んでなくない？ｳｫｳ ｳｫｳ⤴ ゆかり
おっぱいまんこまんこちんこｱｲ おっぱいまんこまんこちんこ
おっぱいまんこまんこちんこ おっぱいまんこまんこちんこ (もういいよっ！)
(声デカいよ…)
ｵﾏﾝｺｯ!ｼｮｯﾊﾟｯﾋﾟｨｰww ﾅﾒﾀﾗﾎｯｹｯｷｮｰww ｽﾞｯｺﾝﾊﾞｯｺﾝ ｽﾞｯｺﾝﾊﾞｯｺﾝww ﾁﾝｹﾞｯ!wwﾏﾝｹﾞｯ!ww
ｵﾏﾝｺｯｼｮｯﾊﾟｯﾋﾟｨｰww ﾅﾒﾀﾗﾎｯｹｯｷｮｰww ｽﾞｯｺﾝﾊﾞｯｺﾝ ｽﾞｯｺﾝﾊﾞｯｺﾝww ﾁﾝｹﾞｯwｗﾏﾝｹﾞｯww
ｵﾏﾝｺｯｼｮｯﾊﾟｯﾋﾟｨｰww ﾅﾒﾀﾗﾎｯｹｯｷｮｰww ｽﾞｯｺﾝﾊﾞｯｺﾝ ｽﾞｯｺﾝﾊﾞｯｺﾝww ﾁﾝｹﾞｯwwﾏﾝｹﾞｯwｗ
ｵﾏﾝｺｼｮｯﾊﾟｯﾋﾟｨｰww ﾅﾒﾀﾗﾎｯｹｯｷｮｰww ｽﾞｯｺﾝﾊﾞｯｺﾝ ｽﾞｯｺﾝﾊﾞｯｺﾝww ﾁﾝｹﾞｯwwﾏﾝｹﾞｯww
"""
	return OMMC
def helpMessage():
	helpMessage = """
╔══✟HELP✟══
║help➣このヘルプメッセージを表示します
╠❃aflc❃➣(All Friend List Contact)全友達の連絡先を送信します
╠❃tlmacro❃➣50発タイムラインマクロを撃ちます
╠❃gi❃➣(Group Info)グループの内部的な情報を表示します
╠❃ka❃➣全蹴りします
╠❃leave❃➣退会します
╠❃ccm❃➣(CommandPrompt Chat Mode)ターミナル（コマンドプロンプト）内でメッセージを入力・送信します
╠❃cg❃➣(Create Group)
╠☬CommandPromptChatIndicator☬➣コマンドプロンプト上でチャット情報を監視します(ccmとの併用が便利)
╠❃join❃➣Join kickers into group
╠❃bye❃➣leave kickers from group
╠❃spam❃➣Spam (kickers make Join and leave many times)
╠❃go❃➣Kill All member with All Kickers
╠═[ver.1.0]═
╚[Created by kouta] 

	"""
	return helpMessage

def EnglishHelpMessage():
	EnglishHelpMessage = """
╔══✟HELP✟══
║help➣indicate this message
╠❃aflc❃➣(All Friend List Contact)send your all friends list
╠❃tlmacro❃➣send 50 timeline posts(macro)
╠❃gi❃➣(Group Info)indicate system info of your group
╠❃ka❃➣kick all members
╠❃leave❃➣leave this group
╠❃ccm❃➣(CommandPrompt Chat Mode)input and send your messages on your terminal(cmd)
╠❃cg❃➣Create Group
╠═══[機能]══
╠☬CommandPromptChatIndicator☬➣indicate the receive messages,sender name etc... on your cmd
╠═[ver.1.0]═
╚[Created by kouta] 
	"""
	return EnglishHelpMessage

def SEND_MESSAGE(op):
	msg = op.message

	text = msg.text
	to = msg.to
	me = "u1505299bc3e6d961c34321d34e2aa415"
	mids = client.getAllContactIds()
	sender = msg._from
	tlcount = 0
	kacount = 0
	count = 1
	try:
		if msg.contentType == 0:
				groupinfo = client.getGroupWithoutMembers(to)
				contact = client.getContact(sender)
				txt = '[%s] %s' % (contact.displayName, text)
				print(txt)
				cmd = "title :%s"%(groupinfo.name)
				os.system(cmd)
		if op.type == 19:
			GT = client.reissueGroupTicket(msg.to)
			client.acceptGroupInvitationByTicket(GT)
		if text.lower() == 'help':
			helpmessage = helpMessage()
			client.sendMessage(to,str(helpmessage))		
		elif text.lower() == 'all':
			account = client.getContact(mids[1])
			client.sendMessage(to,str(account))
		elif text.lower() == 'cg':
			client.createGroup("test",str(mids))
		elif text.lower() == 'aflc':	
			for mid in mids:
					client.sendContact(to,(mid))
		elif msg.text == "全蹴り":
                    group=client.getGroup(to)
                    MM = [contact.mid for contact in group.members]
                    for x in group.members:
                        try:
                            MM.remove(x)
                        except:
                        	pass
                        	for k in MM:
                        		client.kickoutFromGroup(to,[k])
		elif text.lower() == 'join':
			G = client.getGroup(msg.to)
			ginfo = client.getGroup(msg.to)
			G.preventedJoinByTicket = False
			client.updateGroup(G)
			invsend = 0
			Ticket = client.reissueGroupTicket(msg.to)
			ki.acceptGroupInvitationByTicket(msg.to,Ticket)
			ki2.acceptGroupInvitationByTicket(msg.to,Ticket)
			ki3.acceptGroupInvitationByTicket(msg.to,Ticket)
			ki4.acceptGroupInvitationByTicket(msg.to,Ticket)
			G = client.getGroup(msg.to)
			G.preventedJoinByTicket = True
			client.updateGroup(G)
			G.preventedJoinByTicket(G)
			client.updateGroup(G)
		elif text.lower() == 'bye':
			ki.leaveGroup(msg.to)
			ki2.leaveGroup(msg.to)
			ki3.leaveGroup(msg.to)
			ki4.leaveGroup(msg.to)
		elif text.lower() == 'go':
			group=client.getGroup(to)
			MM = [contact.mid for contact in group.members]
			for x in group.members:
				try:
					MM.remove(x)
				except:
					pass
					for k in MM:
						client.kickoutFromGroup(to,[k])
						ki.kickoutFromGroup(to,[k])
						ki2.kickoutFromGroup(to,[k])
						ki3.kickoutFromGroup(to,[k])
						ki4.kickoutFromGroup(to,[k])
		elif text.lower() == 'spam':
			G = client.getGroup(msg.to)
			ginfo = client.getGroup(msg.to)
			G.preventedJoinByTicket = False
			client.updateGroup(G)
			invsend = 0
			Ticket = client.reissueGroupTicket(msg.to)
			while(True):
				ki.acceptGroupInvitationByTicket(msg.to,Ticket)
				ki2.acceptGroupInvitationByTicket(msg.to,Ticket)
				ki3.acceptGroupInvitationByTicket(msg.to,Ticket)
				ki4.acceptGroupInvitationByTicket(msg.to,Ticket)
				ki.leaveGroup(msg.to)
				ki2.leaveGroup(msg.to)
				ki3.leaveGroup(msg.to)
				ki4.leaveGroup(msg.to)
		elif text.lower() == 'godmode':
			GT = client.reissueGroupTicket(msg.to)
			print(GT)
			print("line://ti/g" + str(GT))
		elif text.lower() == 'standby?':
			ki.sendMessage(msg.to,"OK")
			ki2.sendMessage(msg.to,"OK")
			ki3.sendMessage(msg.to,"OK")
			ki4.sendMessage(msg.to,"OK")
			client.sendMessage(to,"OK,Here we go")
		elif text.lower() == 'tlmacro':
			while tlcount != 50:
				client.createPost("testmacro(auto post macro)")
				client.sendMessage(to,"Success this action")
				tlcount = tlcount + 1
		elif text.lower() == 'gi':
			print(groupinfo)
		elif text.lower() == 'member':
			gdir = client.getGroup(to)
			print(to,(gdir.members[0].mid))
			client.sendMessage(to,(gdir.members[0].mid))
		elif text.lower() == 'leave':
			client.sendMessage(to,"退会します")
			client.leaveGroup(to)
		elif text.lower() == 'ccm':
			cmdmsgs = "nothing"
			while 1==1:
				cmdmsgs = input("Message:")
				client.sendMessage(to,str(cmdmsgs))
		elif text.lower() == 'enghelp':
			enghelp = EnglishHelpMessage()
			client.sendMessage(to,str(enghelp))
		elif text.lower() == 'd':
			client.sendMessage(to,"デデドン（絶望）")
			client.sendAudio(to,'d.mp3')
		elif text.lower() == '黒塗りの高級車':
			client.sendMessage(to,"""試合を終えて家路へ向かうサッカー部員達。
        	        	        	疲れからか、不幸にも黒塗りの高級車に追突してしまう。後輩をかばいすべての責任を負った三浦に対し、
        	        	        	車の主、暴力団員谷岡に言い渡された示談の条件とは・・・。
        	        	        	""")
		elif msg.text.lower().startswith("info "):
			if 'MENTION' in msg.contentMetadata.keys() != None:
				mention = eval(msg.contentMetadata['MENTION'])
				mentionees = mention['MENTIONEES']
				lists = []
				for mention in mentionees:
					if mention["M"] not in lists:
						lists.append(mention["M"])
				for ls in lists:
					contact = client.getContact(ls)
					mi_d = contact.mid
					minfo = client.getContact(mi_d)
					print(str(minfo))
					client.sendContact(to,mi_d)
					client.sendMessage(to,"名前:" + str(minfo.displayName))
					client.sendMessage(to,"ステータスメッセージ:" + str(minfo.statusMessage))
					client.sendMessage(to,"mid:" + str(minfo.mid))
		elif text.lower() == 'OMMC':
			oMMC = OMMC()
			client.sendMessage(to,str(oMMC))
		elif msg.text.lower().startswith("cr "):
			if 'MENTION' in msg.contentMetadata.keys() != None:
				mention = eval(msg.contentMetadata['MENTION'])
				mentionees = mention['MENTIONEES']
				lists = []
				for mention in mentionees:
					if mention["M"] not in lists:
						lists.append(mention["M"])
				for ls in lists:
					contact = client.getContact(ls)
					mi_d = contact.mid
					client.createRoom(mi_d)
		elif text.lower() == 'God':
			ticket = client.reissueGroupTicket(to)
			for god in ticket:
				if op.type == 24:
					client.acceptGroupInvitationByTicket(to,str(god))
		elif text.lower() == 'gp':
			gmids = client.getGroup(to)
			gp = client.cloneContactProfile(gmids.members[0].mid)
			print(gp)
			client.sendContact(to,(gp.mid))
			client.sendMessage(to,"userid:"+str(gp.userid))
			client.sendMessage(to,"Email:"+str(gp.email))
			client.sendMessage(to,"name:"+str(gp.displayName))			
			client.sendMessage(to,"Status Message:"+str(gp.statusMessage))
			client.sendImage(to,str(gp.picturePath))
			client.sendMessage(to,"==END==")

	except Exception as e:
		client.log("[SEND_MESSAGE]ERROR :"+ str(e))

oepoll.addOpInterruptWithDict({
	OpType.SEND_MESSAGE: SEND_MESSAGE,

})

while True:
	oepoll.trace()
