from Linephu.linepy import *
s = LINE()
gids = s.getGroupIdsJoined()
sgids = s.getGroups(gids)
sids = s.getAllContactIds()
for sid in sids:
	contact = s.getContact(sid)
	sname = contact.displayName
	smid = contact.mid
	status = contact.statusMessage
	print("[名前:]" + sname)
	print("[mid:]" + smid)
	print("[ステータスメッセージ:]" + status)
for sgid in sgids:
	gname = sgid.name
	sinfos = sgid.members
	for sinfo in sinfos:
		smid = sinfo.mid
		contact = s.getContact(smid)
		sname = contact.displayName
		smid = contact.mid
		status = contact.statusMessage
		print("[グループ名:]" + gname)
		print("[名前:]" + sname)
		print("[mid:]" + smid)
		print("[ステータスメッセージ:]" + status)