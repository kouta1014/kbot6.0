from linepy import *
import os
newpassword=0
password = 0
password = input("password?:")
if password == "114514":
	print("パスワード合致、ログインします")
	client = LINE('yk.20050513.t@gmail.com','yuyuyu20050513')
	client.log("Auth Token :"+str(client.authToken))
	oepoll = OEPoll(client)
elif password != "114514":
	print("パスワードが違います、再試行してください")

infnity = 0;
def helpMessage():
	helpMessage = """
╔══✟HELP✟══
║help➣このヘルプメッセージを表示します
╠❃aflc❃➣(All Friend List Contact)全友達の連絡先を送信します
╠❃tlmacro❃➣50発タイムラインマクロを撃ちます
╠❃gi❃➣(Group Info)グループの内部的な情報を表示します
╠❃ka❃➣全蹴りします
╠❃leave❃➣退会します
╠❃ccm❃➣(CommandPrompt Chat Mode)ターミナル（コマンドプロンプト）内でメッセージを入力・送信します
╠❃cg❃➣(Create Group)
╠═══[機能]══
╠☬CommandPromptChatIndicator☬➣コマンドプロンプト上でチャット情報を監視します(ccmとの併用が便利)
╠═[ver.1.0]═
╚[Created by kouta] 

	"""
	return helpMessage

def EnglishHelpMessage(op):
	EnglishHelpMessage = """
╔══✟HELP✟══
║help➣indicate this message
╠❃aflc❃➣(All Friend List Contact)send your all friends list
╠❃tlmacro❃➣send 50 timeline posts(macro)
╠❃gi❃➣(Group Info)indicate system info of your group
╠❃ka❃➣kick all members
╠❃leave❃➣leave this group
╠❃ccm❃➣(CommandPrompt Chat Mode)input and send your messages on your terminal(cmd)
╠❃cg❃➣Create Group
╠═══[機能]══
╠☬CommandPromptChatIndicator☬➣indicate the receive messages,sender name etc... on your cmd
╠═[ver.1.0]═
╚[Created by kouta] 
	"""
	return EnglishHelpMessage

def SEND_MESSAGE(op):
	msg = op.message

	text = msg.text
	to = msg.to
	me = "u1505299bc3e6d961c34321d34e2aa415"
	mids = client.getAllContactIds()
	sender = msg._from
	tlcount = 0
	kacount = 0
	count = 1
	stcount = 0
	try:
		if msg.contentType == 0:
				groupinfo = client.getGroupWithoutMembers(to)
				contact = client.getContact(sender)
				txt = '[%s] %s' % (contact.displayName, text)
				print(txt)
				cmd = "title%s"%(groupinfo.name)
				os.system(cmd)
		if text.lower() == 'help':
			helpmessage = helpMessage()
			client.sendMessage(to,str(helpmessage))		
		elif text.lower() == 'all':
			account = client.getContact(mids[1])
			client.sendMessage(to,str(account))
		elif text.lower() == 'cg':
			client.createGroup("test",str(mids))
		elif text.lower() == 'aflc':	
			for mid in mids:
					client.sendContact(to,(mid))
		elif msg.text == "全蹴り":
                    group=client.getGroup(to)
                    MM = [contact.mid for contact in group.members]
                    for x in group.members:
                        try:
                            MM.remove(x)
                        except:
                              pass
                    for k in MM:
                        client.kickoutFromGroup(to,[k])
		elif text.lower() == 'tlmacro':
			while tlcount != 50:
				client.createPost("testmacro(auto post macro)")
				client.sendMessage(to,"Success this action")
				tlcount = tlcount + 1		
		elif text.lower() == 'st':
			while stcount != 50:
				client.sendSticker(to,1,1)
				stcount = stcount + 1
			sendMessage(to,"スタ爆完了")
		elif text.lower() == 'gi':
			print(groupinfo)
		elif text.lower() == 'member':
			gdir = client.getGroup(to)
			print(to,(gdir.members[0].mid))
			client.sendMessage(to,(gdir.members[0].mid))
		elif text.lower() == 'leave':
			client.sendMessage(to,"退会します")
			client.leaveGroup(to)
		elif text.lower() == 'ccm':
			cmdmsgs = "nothing"
			while 1==1:
				cmdmsgs = input("Message:")
				client.sendMessage(to,str(cmdmsgs))
		elif text.lower() == 'enghelp':
			enghelp = EnglishHelpMessage()
			client.sendMesasge(to,str(enghelp))  

	except Exception as e:
		client.log("[SEND_MESSAGE]ERROR :"+ str(e))

oepoll.addOpInterruptWithDict({
	OpType.SEND_MESSAGE: SEND_MESSAGE,

})

while True:
	oepoll.trace()